package com.lib.liblibgo.listner;

public interface OnItemClickListenerTow {
    void onItemClick(int position,boolean isSelected);
}
