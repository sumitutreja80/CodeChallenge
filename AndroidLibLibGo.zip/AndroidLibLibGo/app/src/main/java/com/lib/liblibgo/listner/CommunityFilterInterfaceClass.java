package com.lib.liblibgo.listner;

public interface CommunityFilterInterfaceClass {
    public void callbackMethod(String catId,String city,String area,String apartment,String distance,String type,String giveaway);
}
