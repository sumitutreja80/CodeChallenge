package com.lib.liblibgo.listner;

public interface OnItemClickListenerThree {
    void onItemClick(int position,String city,String area,String apartment,String distance);
}
