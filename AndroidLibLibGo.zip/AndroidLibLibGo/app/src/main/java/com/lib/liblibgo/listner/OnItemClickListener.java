package com.lib.liblibgo.listner;

public interface OnItemClickListener {
    void onItemClick(int position);
}
