package com.lib.liblibgo.model;

public class SliderData {
    private int imgUrl;

    public SliderData(int imgUrl) {
        this.imgUrl = imgUrl;
    }

    public int getImgUrl() {
        return imgUrl;
    }

    public void setImgUrl(int imgUrl) {
        this.imgUrl = imgUrl;
    }
}
