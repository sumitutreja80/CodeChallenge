package com.lib.liblibgo.listner;

public interface CommunityLibraryClickListener {
    void onItemClick(int position);
}
