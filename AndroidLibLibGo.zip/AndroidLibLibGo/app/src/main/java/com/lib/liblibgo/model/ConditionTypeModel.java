package com.lib.liblibgo.model;

public class ConditionTypeModel {
    String condition_type="";

    public ConditionTypeModel(String condition_type) {
        this.condition_type = condition_type;
    }

    public String getCondition_type() {
        return condition_type;
    }

    public void setCondition_type(String condition_type) {
        this.condition_type = condition_type;
    }
}
