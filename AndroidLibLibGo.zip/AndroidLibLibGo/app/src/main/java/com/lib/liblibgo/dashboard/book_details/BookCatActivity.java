package com.lib.liblibgo.dashboard.book_details;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.ViewPager;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.tabs.TabLayout;
import com.karumi.dexter.Dexter;
import com.karumi.dexter.MultiplePermissionsReport;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.multi.MultiplePermissionsListener;
import com.lib.liblibgo.R;
import com.lib.liblibgo.activity.LoginWithPhoneNumber;
import com.lib.liblibgo.activity.SearchActivity;
import com.lib.liblibgo.activity.homedashboard.fragmentshome.CommonFragment;
import com.lib.liblibgo.activity.homedashboard.fragmentshome.HomeFragment;
import com.lib.liblibgo.activity.homedashboard.fragmentshome.MyLibraryFragment;
import com.lib.liblibgo.adapter.CategoryAdapter;
import com.lib.liblibgo.adapter.NearMeBookAdapter;
import com.lib.liblibgo.api.AllApiClass;
import com.lib.liblibgo.api.Holders;
import com.lib.liblibgo.common.Constants;
import com.lib.liblibgo.common.UserCurrentLocation;
import com.lib.liblibgo.common.UserDatabase;
import com.lib.liblibgo.dashboard.apartment_admin.UploadBookDetails;
import com.lib.liblibgo.dashboard.book_details.fragments.CommunityBooksFrag;
import com.lib.liblibgo.dashboard.book_details.fragments.OwnBooksFrag;
import com.lib.liblibgo.dashboard.library.CreateLibraryActivity;
import com.lib.liblibgo.dashboard.library.LibraryActivity;
import com.lib.liblibgo.dashboard.profile.fragments.IssuedListFrag;
import com.lib.liblibgo.dashboard.profile.fragments.MyOrderFragment;
import com.lib.liblibgo.dashboard.trackingbooks.TrackMyBooksActivity;
import com.lib.liblibgo.dashboard.trackingbooks.fragments.MyComBooksFragment;
import com.lib.liblibgo.dashboard.trackingbooks.fragments.MyIndBooksFragment;
import com.lib.liblibgo.dialogs.CategoriFilterDialog;
import com.lib.liblibgo.model.CategoryListData;
import com.lib.liblibgo.model.CategoryModel;
import com.lib.liblibgo.model.NearMeBookModel;
import com.lib.liblibgo.model.NearMeFilterModel;
import com.lib.liblibgo.model.subadmin.LibraryStatusModel;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class BookCatActivity extends AppCompatActivity implements TabLayout.OnTabSelectedListener{
    private TextView titleTool;
    private ImageView backTool;
    private ImageView ivSearch;
    //private RecyclerView rvCategory;
    //private ProgressBar progBar;

   /* private List<CategoryListData> catList = new ArrayList<>();
    private CategoryAdapter adapter;
    private RecyclerView rvBook;
    private ProgressBar progBarr;

    private List<NearMeBookModel.ResModelData.NewrmeBookList> bookList = new ArrayList<>();
    private NearMeBookAdapter bookAdapter;

   // private RelativeLayout rlLocation;
    private PopupWindow popupWindow;
   // private TextView tvRange;
    String apartment = "";
    String city = "";
    String area = "";
    private UserCurrentLocation location;
    private UserDatabase database;
    private RelativeLayout rlCategory;
    private RelativeLayout rlNearMe;
    private RelativeLayout rlType;
    private ImageView ivFilterCategory;
    private ImageView ivFilterNearMe;
    private ImageView ivType;
    private ImageView ivSearch;
    private FloatingActionButton fabAddBooks;
    private String bookType = "";
    private String giveAway = "";
    private LinearLayout llFilter;
    private ImageView ivFilter;
    private String userId = "";
    private String catIds = "";
    private String cityValue = "";
    private String areaValue = "";
    private String apartmentValue = "";
    private String distanceValue = "";
    private String typeValue = "";
    private String giveAwayValue = "";

    private List<CategoryListData> myCatList = new ArrayList<>();
    private List<NearMeFilterModel> myNearbyList = new ArrayList<>();

    private RelativeLayout rlLocation;
    private TextView tvRange;

    private SharedPreferences sharedpreferences;
    public static final String MyPREFERENCES = "MyPrefMyBooks";
    private SharedPreferences.Editor editor;*/

    private TabLayout tabLayout;
    private ViewPager viewPager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book_cat);

        //sharedpreferences = getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);
        //editor = sharedpreferences.edit();

        titleTool = findViewById(R.id.titleTool);
        backTool = findViewById(R.id.backTool);
        ivSearch = findViewById(R.id.ivSearch);
        setTopView(getString(R.string.categories));

        tabLayout = (TabLayout)findViewById(R.id.tab_layout);

        tabLayout.addTab(tabLayout.newTab().setText("Individual Books"));
        tabLayout.addTab(tabLayout.newTab().setText("Community Books"));
        tabLayout.setTabGravity(TabLayout.GRAVITY_FILL);

        tabLayout.setTabTextColors(
                getResources().getColor(R.color.white),
                getResources().getColor(R.color.black)
        );

        viewPager = (ViewPager)findViewById(R.id.viewPager);
        Pager adapter = new Pager(getSupportFragmentManager(), tabLayout.getTabCount());
        viewPager.setAdapter(adapter);
        TabLayout.Tab tab = tabLayout.getTabAt(1);
        tab.select();
        viewPager.setCurrentItem(1);
        tabLayout.setOnTabSelectedListener(this);
        tabLayout.setupWithViewPager(viewPager);
        //viewPager.setCurrentItem(0);
        tabLayout.getTabAt(0).setText("Individual Books");
        tabLayout.getTabAt(1).setText("Community Books");

        /*rvBook = (RecyclerView)findViewById(R.id.rvBook);
        progBarr = (ProgressBar)findViewById(R.id.progBarr);

        ivFilter = (ImageView)findViewById(R.id.ivFilter);
        llFilter = (LinearLayout)findViewById(R.id.llFilter);
        rlLocation = (RelativeLayout)findViewById(R.id.rlLocation);
        tvRange = (TextView)findViewById(R.id.tvRange);

        fabAddBooks = (FloatingActionButton)findViewById(R.id.fabAddBooks);

        database = new UserDatabase(this);

        getBooksByCategory(catIds,cityValue,areaValue,apartmentValue,distanceValue,typeValue,giveAwayValue);

        ivFilter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CategoriFilterDialog dialog =
                        CategoriFilterDialog.newInstance();
                dialog.show(getSupportFragmentManager(),
                        "cat_dialog_fragment");
            }
        });

        fabAddBooks.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Dexter.withContext(BookCatActivity.this).withPermissions(Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION,Manifest.permission.READ_EXTERNAL_STORAGE,Manifest.permission.WRITE_EXTERNAL_STORAGE,Manifest.permission.CAMERA)
                        .withListener(new MultiplePermissionsListener() {
                            @Override
                            public void onPermissionsChecked(MultiplePermissionsReport multiplePermissionsReport) {
                                if (database.getUserId().equals("")){
                                    Intent intentHome = new Intent(BookCatActivity.this,LoginWithPhoneNumber.class);
                                    startActivity(intentHome);
                                }else {
                                    isLibraryCreated();
                                }
                            }
                            @Override
                            public void onPermissionRationaleShouldBeShown(List<PermissionRequest> list, PermissionToken permissionToken) {
                                permissionToken.continuePermissionRequest();
                            }
                        }).check();
            }
        });

        getCategoryList();
        getNearByData();

        rlLocation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showLocationRangeMenu(view);
            }
        });*/

    }

    /*private void showLocationRangeMenu(View view) {
        LayoutInflater layoutInflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        final View popupView = layoutInflater.inflate(R.layout.layout_my_book_filter, null);

        String selectedItem = sharedpreferences.getString("select", "");

        popupWindow = new PopupWindow(
                popupView,
                300,
                ViewGroup.LayoutParams.WRAP_CONTENT);

        popupWindow.setBackgroundDrawable(new BitmapDrawable());
        popupWindow.setOutsideTouchable(true);

        final TextView tvAllBooks = popupView.findViewById(R.id.tvAllBooks);
        final TextView tvmyBooks = popupView.findViewById(R.id.tvmyBooks);

        if (selectedItem.equals("1")){
            tvAllBooks.setBackgroundColor(Color.parseColor("#345EA8"));
            tvAllBooks.setTextColor(Color.parseColor("#ffffff"));
        }else if (selectedItem.equals("2")){
            tvmyBooks.setBackgroundColor(Color.parseColor("#345EA8"));
            tvmyBooks.setTextColor(Color.parseColor("#ffffff"));
        }else {
            tvAllBooks.setBackgroundColor(Color.parseColor("#345EA8"));
            tvAllBooks.setTextColor(Color.parseColor("#ffffff"));
        }

        tvAllBooks.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                popupWindow.dismiss();
                editor.putString("select","1");
                editor.commit();
                tvRange.setText("All Books");
                getBooksByCategory(catIds,cityValue,areaValue,apartmentValue,distanceValue,typeValue,giveAwayValue);
                llFilter.setVisibility(View.VISIBLE);
            }
        });

        tvmyBooks.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                popupWindow.dismiss();
                editor.putString("select","2");
                editor.commit();
                tvRange.setText("My Books");
                llFilter.setVisibility(View.INVISIBLE);
                getMyBookList();
            }
        });

        popupWindow.setOnDismissListener(new PopupWindow.OnDismissListener() {
            @Override
            public void onDismiss() {
                //TODO do sth here on dismiss
                popupWindow.dismiss();
            }
        });

        popupWindow.showAsDropDown(view);

    }

    private void getMyBookList() {
        progBarr.setVisibility(View.VISIBLE);
        location = new UserCurrentLocation(this);
        Holders holders = AllApiClass.getInstance().getApi();
        Call<NearMeBookModel> resCall = holders.getMyOwnBooks(database.getUserId(),String.valueOf(location.latitude),String.valueOf(location.longitude));
        resCall.enqueue(new Callback<NearMeBookModel>() {
            @Override
            public void onResponse(Call<NearMeBookModel> call, Response<NearMeBookModel> response) {
                if (response.isSuccessful()){
                    if (response.body().getResponse().getCode().equals("1")){
                        bookList.clear();
                        bookList = new ArrayList<>();
                        rvBook.setVisibility(View.VISIBLE);
                        progBarr.setVisibility(View.GONE);
                        bookList = response.body().getResponse().getBook_list();
                        if (bookList.size() > 0){
                            bookAdapter = new NearMeBookAdapter(bookList, BookCatActivity.this);
                            GridLayoutManager manager = new GridLayoutManager(BookCatActivity.this,2);
                            // verticalManager.setReverseLayout(true);
                            // verticalManager.setStackFromEnd(true);
                            rvBook.setLayoutManager(manager);
                            rvBook.setAdapter(bookAdapter);
                            bookAdapter.notifyDataSetChanged();
                        }else {
                            rvBook.setVisibility(View.GONE);
                        }
                    }else {
                        Toast.makeText(BookCatActivity.this, ""+response.body().getResponse().getMessage(), Toast.LENGTH_SHORT).show();
                        progBarr.setVisibility(View.GONE);
                        rvBook.setVisibility(View.GONE);
                    }
                }else {
                    Toast.makeText(BookCatActivity.this, "Something went wrong !", Toast.LENGTH_SHORT).show();
                    progBarr.setVisibility(View.GONE);
                }
            }

            @Override
            public void onFailure(Call<NearMeBookModel> call, Throwable t) {
                Toast.makeText(BookCatActivity.this, ""+t.getMessage(), Toast.LENGTH_SHORT).show();
                progBarr.setVisibility(View.GONE);
            }
        });
    }

    private void getNearByData() {
        Constants.myNearbyList.add(new NearMeFilterModel("Within Community"));
        Constants.myNearbyList.add(new NearMeFilterModel("Within Area"));
        Constants.myNearbyList.add(new NearMeFilterModel("Within City"));
        Constants.myNearbyList.add(new NearMeFilterModel("Within 2km"));
        Constants.myNearbyList.add(new NearMeFilterModel("Within 5km"));
        Constants.myNearbyList.add(new NearMeFilterModel("Within 10km"));
    }

    private void getCategoryList() {
        Holders holders = AllApiClass.getInstance().getApi();
        Call<CategoryModel> resCall = holders.categoryList();
        resCall.enqueue(new Callback<CategoryModel>() {
            @Override
            public void onResponse(Call<CategoryModel> call, Response<CategoryModel> response) {
                if (response.isSuccessful()){
                    if (response.body().getResponse().getCode().equals("1")){
                        myCatList = response.body().getResponse().getApartment_list();
                        Constants.catList = myCatList;
                    }
                }
            }
            @Override
            public void onFailure(Call<CategoryModel> call, Throwable t) {

            }
        });
    }

    private void isLibraryCreated() {
        final ProgressDialog progressBar = new ProgressDialog(BookCatActivity.this);
        progressBar.setMessage("Please wait...");
        progressBar.setCancelable(false);
        progressBar.show();
        Holders holders = AllApiClass.getInstance().getApi();
        Call<LibraryStatusModel> resCall = holders.checkLibraryStatus(database.getUserId());
        resCall.enqueue(new Callback<LibraryStatusModel>() {
            @Override
            public void onResponse(Call<LibraryStatusModel> call, Response<LibraryStatusModel> response) {
                if (response.isSuccessful()){
                    progressBar.dismiss();
                    if (response.body().getResponse().getLibrary_status().equals("no")){
                        UserCurrentLocation location = new UserCurrentLocation(BookCatActivity.this);
                        Log.d("locationnn",""+location.latitude);
                        Log.d("locationnn",""+location.longitude);
                        Constants.latitude = String.valueOf(location.latitude);
                        Constants.longitude = String.valueOf(location.longitude);
                        Constants.SelectedLibraryProfileImage = "";
                        Intent intent = new Intent(BookCatActivity.this, CreateLibraryActivity.class);
                        Constants.USER_APARTMENT_NAME = response.body().getResponse().getApartment_name();
                        Constants.USER_APARTMENT_ID = response.body().getResponse().getApartment_id();
                        Constants.USER_FLAT_ID = response.body().getResponse().getFlat_id();
                        Constants.USER_FLAT_NAME = response.body().getResponse().getFlat_no();
                       // Constants.libraryType = response.body().getResponse().getLibrary_type();
                        Constants.libraryType = "";
                        Constants.isOwnLibrary = true;
                        startActivity(intent);
                    }else {
                        Intent intent = new Intent(BookCatActivity.this, UploadBookDetails.class);
                        Constants.isOwnLibrary = true;
                        //Constants.libraryType = response.body().getResponse().getLibrary_type();
                        Constants.libraryType = "";
                        intent.putExtra("name","");
                        intent.putExtra("author","");
                        intent.putExtra("isbn","");
                        intent.putExtra("publish_date","");
                        intent.putExtra("description","");
                        intent.putExtra("imgUrl","");
                        intent.putExtra("rental_price","");
                        intent.putExtra("rental_duration","");
                        intent.putExtra("book_price","");
                        intent.putExtra("category_id","");
                        intent.putExtra("category_name","");
                        intent.putExtra("shelf_id","");
                        intent.putExtra("shelf_name","");
                        intent.putExtra("book_id","");
                        intent.putExtra("mrp","");
                        intent.putExtra("quantity","");
                        intent.putExtra("sale_type","");
                        intent.putExtra("book_condition","");
                        intent.putExtra("security_money","");
                        intent.putExtra("giveaway_status","no");
                        startActivity(intent);
                    }
                }else {
                    progressBar.dismiss();
                    Toast.makeText(BookCatActivity.this, "Something went wrong !", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<LibraryStatusModel> call, Throwable t) {
                progressBar.dismiss();
                Toast.makeText(BookCatActivity.this, "Check your internet !", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void getBooksByCategory(String catIds,String cityValue,String areaValue,String apartmentValue,String distanceValue,String typeValue,String giveAwayValue) {
        progBarr.setVisibility(View.VISIBLE);
        location = new UserCurrentLocation(this);
        Holders holders = AllApiClass.getInstance().getApi();
        Call<NearMeBookModel> resCall = holders.getBooksByAllFilters(catIds,String.valueOf(location.latitude),String.valueOf(location.longitude),
                distanceValue,cityValue,areaValue,typeValue,giveAwayValue,apartmentValue,"1");
        resCall.enqueue(new Callback<NearMeBookModel>() {
            @Override
            public void onResponse(Call<NearMeBookModel> call, Response<NearMeBookModel> response) {
                if (response.isSuccessful()){
                    if (response.body().getResponse().getCode().equals("1")){
                        bookList.clear();
                        bookList = new ArrayList<>();
                        rvBook.setVisibility(View.VISIBLE);
                        progBarr.setVisibility(View.GONE);
                        bookList = response.body().getResponse().getBook_list();
                        if (bookList.size() > 0){
                            bookAdapter = new NearMeBookAdapter(bookList, BookCatActivity.this);
                            GridLayoutManager manager = new GridLayoutManager(BookCatActivity.this,2);
                            // verticalManager.setReverseLayout(true);
                            // verticalManager.setStackFromEnd(true);
                            rvBook.setLayoutManager(manager);
                            rvBook.setAdapter(bookAdapter);
                            bookAdapter.notifyDataSetChanged();
                        }else {
                            rvBook.setVisibility(View.GONE);
                        }
                    }else {
                        Toast.makeText(BookCatActivity.this, ""+response.body().getResponse().getMessage(), Toast.LENGTH_SHORT).show();
                        progBarr.setVisibility(View.GONE);
                        rvBook.setVisibility(View.GONE);
                    }
                }else {
                    Toast.makeText(BookCatActivity.this, "Something went wrong !", Toast.LENGTH_SHORT).show();
                    progBarr.setVisibility(View.GONE);
                }
            }

            @Override
            public void onFailure(Call<NearMeBookModel> call, Throwable t) {
                Toast.makeText(BookCatActivity.this, ""+t.getMessage(), Toast.LENGTH_SHORT).show();
                progBarr.setVisibility(View.GONE);
            }
        });
    }
*/
    private void setTopView(String string) {
        titleTool.setText(string);
        backTool.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
                finish();
            }
        });

        ivSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(BookCatActivity.this, SearchActivity.class);
                startActivity(intent);
            }
        });
    }

    public class Pager extends FragmentStatePagerAdapter {

        int tabCount;

        public Pager(FragmentManager fm, int tabCount) {
            super(fm);
            this.tabCount = tabCount;
        }

        @Override
        public Fragment getItem(int position) {
            //Returning the current tabs
            switch (position) {
                case 0:
                    //OwnBooksFrag tab1 = new OwnBooksFrag();
                    CommonFragment tab1 = new CommonFragment();
                    return tab1;
                case 1:
                    CommunityBooksFrag tab2 = new CommunityBooksFrag();
                    return tab2;
                default:
                    return null;
            }
        }

        //Overriden method getCount to get the number of tabs
        @Override
        public int getCount() {
            return tabCount;
        }
    }

    @Override
    public void onTabSelected(TabLayout.Tab tab) {
        viewPager.setCurrentItem(tab.getPosition());
        if (tab.getPosition() == 0){
            ivSearch.setVisibility(View.INVISIBLE);
            Constants.searchFrom = "individual";
        }else {
            Constants.searchFrom = "community";
            ivSearch.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public void onTabUnselected(TabLayout.Tab tab) {

    }

    @Override
    public void onTabReselected(TabLayout.Tab tab) {

    }

    /*public void onGoLibraryList(View view) {
        Intent intent = new Intent(BookCatActivity.this, LibraryActivity.class);
        startActivity(intent);
    }*/


    /*public void setCategoryData(String catId,String city,String area,String apartment,String distance,String type,String giveaway) {
        catIds = catId;
        cityValue = city;
        areaValue = area;
        apartmentValue = apartment;
        distanceValue = distance;
        typeValue = type;
        giveAwayValue = giveaway;
        Log.d("mySelectedValues","\nCategories :"+catIds
                +"\n"+"city : "+cityValue
                +"\n"+"pin : "+areaValue
                +"\n"+"userId : "+apartmentValue
                +"\n"+"distance : "+distanceValue
                +"\n"+"type : "+typeValue
                +"\n"+"giveaway : "+giveAwayValue
        );
        getBooksByCategory(catIds,cityValue,areaValue,apartmentValue,distanceValue,typeValue,giveAwayValue);
    }*/

    /*@Override
    protected void onDestroy() {
        Constants.selectedNearByCity = "";
        Constants.selectedNearByArea = "";
        Constants.selectedNearByApartment = "";
        Constants.selectedNearByDistance = "";

        Constants.selectedFilterValue = "";
        Constants.giveAway = "";
        super.onDestroy();
    }

    @Override
    protected void onStop() {
        editor.clear();
        editor.commit();
        super.onStop();
    }*/

    @Override
    public void onResume() {
        if (HomeFragment.flag == 1){
            Pager adapter = new Pager(getSupportFragmentManager(), tabLayout.getTabCount());
            viewPager.setAdapter(adapter);
            TabLayout.Tab tab = tabLayout.getTabAt(1);
            tab.select();
            viewPager.setCurrentItem(1);
            tabLayout.setOnTabSelectedListener(this);
            tabLayout.setupWithViewPager(viewPager);
            //viewPager.setCurrentItem(0);
            tabLayout.getTabAt(0).setText("Individual Books");
            tabLayout.getTabAt(1).setText("Community Books");
            HomeFragment.flag = 0;
        }
        super.onResume();
    }

    @Override
    protected void onDestroy() {
        Constants.selectedCategories = "";
        super.onDestroy();
    }
}