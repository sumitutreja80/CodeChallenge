package com.lib.liblibgo.model;

public class NearMeFilterModel {
    public String filter="";

    public NearMeFilterModel(String filter) {
        this.filter = filter;
    }

    public String getFilter() {
        return filter;
    }

    public void setFilter(String filter) {
        this.filter = filter;
    }
}
