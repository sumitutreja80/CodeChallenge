package com.lib.liblibgo.dashboard.profile;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.lib.liblibgo.R;

public class BookImageCropperActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book_image_cropper);

    }
}