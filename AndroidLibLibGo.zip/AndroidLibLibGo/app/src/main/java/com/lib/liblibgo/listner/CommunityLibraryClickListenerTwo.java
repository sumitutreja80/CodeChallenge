package com.lib.liblibgo.listner;

public interface CommunityLibraryClickListenerTwo {
    void onItemClick(int position);
}
