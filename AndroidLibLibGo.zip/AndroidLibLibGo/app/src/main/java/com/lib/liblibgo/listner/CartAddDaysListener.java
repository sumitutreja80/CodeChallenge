package com.lib.liblibgo.listner;

public interface CartAddDaysListener {
    void onItemClick(int position,int count,String cartRentDuration,String bookRentDuration);
}
