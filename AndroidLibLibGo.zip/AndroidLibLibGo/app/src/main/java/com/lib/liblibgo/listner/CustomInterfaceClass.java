package com.lib.liblibgo.listner;

public interface CustomInterfaceClass {
    public void callbackMethod(String date);
}
