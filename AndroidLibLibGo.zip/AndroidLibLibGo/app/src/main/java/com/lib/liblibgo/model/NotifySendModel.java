package com.lib.liblibgo.model;

public class NotifySendModel {
}
