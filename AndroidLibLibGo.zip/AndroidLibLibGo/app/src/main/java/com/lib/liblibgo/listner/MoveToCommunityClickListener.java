package com.lib.liblibgo.listner;

public interface MoveToCommunityClickListener {
    void onItemClick(int position);
}
