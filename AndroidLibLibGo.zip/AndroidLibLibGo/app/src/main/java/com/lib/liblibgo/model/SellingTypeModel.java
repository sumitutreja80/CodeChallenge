package com.lib.liblibgo.model;

public class SellingTypeModel {
    String sale_type="";

    public SellingTypeModel(String sale_type) {
        this.sale_type = sale_type;
    }

    public String getSale_type() {
        return sale_type;
    }

    public void setSale_type(String sale_type) {
        this.sale_type = sale_type;
    }
}
