//
//  tblTrackMyCommunityBookListCell.swift
//  Liblibgo
//
//  Created by apple on 25/06/22.
//

import UIKit

class tblTrackMyCommunityBookListCell: UITableViewCell {

    @IBOutlet weak var imgBookImage: UIImageView!
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var lblOwnerName: UILabel!
    @IBOutlet weak var lblStatus: UILabel!
    @IBOutlet weak var switchBook: UISwitch!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func bindData(_ data: BookList) {
        self.imgBookImage.sd_setImage(with: URL.init(string: data.imageURL ?? ""), completed: nil)
        self.lblTitle.text = data.bookName
        self.lblOwnerName.text = data.authorName
        self.lblStatus.text = data.approvalStatus ?? "0" == "1" ? "Active" : "Inactive"
        self.lblStatus.textColor = data.approvalStatus ?? "0" == "1" ? .green : .red
        self.switchBook.isOn = data.approvalStatus ?? "0" == "1"
    }
}
