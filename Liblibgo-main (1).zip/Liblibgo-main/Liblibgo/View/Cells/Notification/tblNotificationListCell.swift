//
//  tblNotificationListCell.swift
//  Liblibgo
//
//  Created by apple on 12/06/22.
//

import UIKit

class tblNotificationListCell: UITableViewCell {

    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var lblDes: UILabel!
    @IBOutlet weak var lblDate: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func bindData(_ data: NotificationList){
        self.lblTitle.text = data.title
        self.lblDes.text = data.message
        self.lblDate.text = Utill.share.getFormatedDate(stringDate: data.dated ?? "", format: "dd MMM yyyy", defaultformat: "dd-MM-yyyy")
    }
    
}
