//
//  vwCartLibrary.swift
//  Liblibgo
//
//  Created by apple on 28/05/22.
//

import UIKit

class vwCartLibrary: UIView {

    @IBOutlet weak var imgBookImage: UIImageView!
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var lblOwnerName: UILabel!
    @IBOutlet weak var lblAddedBy: UILabel!
    @IBOutlet weak var lblAvailable: UILabel!
    
    @IBOutlet weak var vwQuantity: UIView!
    @IBOutlet weak var btnQTYMinus: UIButton!
    @IBOutlet weak var txtQuantity: UITextField!
    @IBOutlet weak var btnQTYPlus: UIButton!
    
    var controller: UIViewController!
    var QTY: Int = 0
    lazy var viewModel : CartVM = {
        let viewModel = CartVM()
        return viewModel
    }()
    
    class func instanceFromNib() -> UIView {
        return UINib(nibName: "vwCartLibrary", bundle: nil).instantiate(withOwner: nil, options: nil)[0] as! UIView
    }
    
    func setDetail(obj: CartList, isFromCheckout: Bool = false){
        self.imgBookImage.sd_setImage(with: URL.init(string: obj.bookImage?.urlQueryEncoded ?? ""), placeholderImage: nil, completed: nil)
        self.lblTitle.text = obj.bookName
        self.lblOwnerName.text = "By \(obj.authorName ?? "")"
        self.lblAddedBy.text = "₹\(obj.bookPrice ?? 0)"
        if obj.cartFor == "rent" && !isFromCheckout{
            self.vwQuantity.isHidden = false
            self.txtQuantity.text = obj.cartRentDuration
            self.QTY = Int(obj.cartRentDuration ?? "0") ?? 0
            self.lblAvailable.isHidden = true
        }else{
            self.vwQuantity.isHidden = true
            self.lblAvailable.text = isFromCheckout ? "" : obj.cartFor
            self.lblAvailable.isHidden = false
        }
        self.btnQTYMinus.tag = Int(obj.cartID ?? "0") ?? 0
        self.btnQTYPlus.tag = Int(obj.cartID ?? "0") ?? 0
        
        //set max count
        self.btnQTYPlus.accessibilityIdentifier = obj.bookRentDuration
    }
    
    @IBAction func btnPlusTap(_ sender: UIButton){
        let maxCount: Int = Int(sender.accessibilityIdentifier ?? "0") ?? 0
        if self.QTY < maxCount{
            self.QTY += 1
            self.txtQuantity.text = "\(self.QTY)"
            self.viewModel.updateCartRentDuration(cartId: "\(sender.tag)", rentDuration: self.txtQuantity.text ?? "") { _ in }
        }else{
            Utill.setTost(title: nil, message: "Duration limited by lender", controller: self.controller, completion: nil)
        }
    }
    
    @IBAction func btnPlusMinus(_ sender: UIButton){
        let minCount: Int = 5
        if self.QTY > minCount{
            self.QTY -= 1
            self.txtQuantity.text = "\(self.QTY)"
            self.viewModel.updateCartRentDuration(cartId: "\(sender.tag)", rentDuration: self.txtQuantity.text ?? "") { _ in }
        }else{
            Utill.setTost(title: nil, message: "Minimum duration is \(minCount) days", controller: self.controller, completion: nil)
        }
    }
}
