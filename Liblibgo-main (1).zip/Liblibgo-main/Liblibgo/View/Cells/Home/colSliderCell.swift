//
//  colSliderCell.swift
//  Kepoci
//
//  Created by apple on 13/03/21.
//

import UIKit

class colSliderCell: UICollectionViewCell {

    @IBOutlet weak var imgSliderImage: UIImageView!
    @IBOutlet weak var imgSliderImageTrailing: NSLayoutConstraint!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.imgSliderImage.layer.cornerRadius = 6
        self.imgSliderImage.contentMode = .scaleAspectFill
    }

}
