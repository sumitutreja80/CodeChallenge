//
//  colSearchBooksCell.swift
//  Liblibgo
//
//  Created by apple on 10/06/22.
//

import UIKit

class colSearchBooksCell: UICollectionViewCell {

    @IBOutlet weak var imgBookImage: UIImageView!
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var lblDes: UILabel!
    @IBOutlet weak var lblBuy: UILabel!
    @IBOutlet weak var lblRent: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    func bindData(_ data: BookList){
        self.imgBookImage.sd_setShowActivityIndicatorView(true)
        self.imgBookImage.sd_setIndicatorStyle(.medium)
        let escapedString = data.imageURL ?? "".urlQueryEncoded
        self.imgBookImage.sd_setImage(with: URL.init(string: escapedString ?? ""), completed: nil)
        self.lblTitle.text = data.bookName
        self.lblDes.text = "By \(data.authorName ?? "")"
        if data.sellingType == "For Rent"{
            let price = data.rentalPrice ?? ""
            self.lblRent.text = "Rent/day at \(price == "0" ? "Free" : price)"
            self.lblBuy.text = "Buy at N/A"
        }else{
            let price = data.salePrice ?? ""
            self.lblBuy.text = "Buy at \(price == "0" ? "Free" : price)"
            self.lblRent.text = "Rent/day at N/A"
        }
    }

}
