//
//  tblBookOfLibraryListCell.swift
//  Liblibgo
//
//  Created by apple on 27/05/22.
//

import UIKit

class tblBookOfLibraryListCell: UITableViewCell {

    @IBOutlet weak var imgBookImage: UIImageView!
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var lblOwnerName: UILabel!
    @IBOutlet weak var lblAddedBy: UILabel!
    @IBOutlet weak var lblAvailable: UILabel!
    @IBOutlet weak var btnWhatsApp: UIButton!
    @IBOutlet weak var btnEmail: UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
