//
//  tblCommunityLibrariesself.swift
//  Liblibgo
//
//  Created by apple on 21/05/22.
//

import UIKit
import Cosmos

class tblCommunityLibrariesCell: UITableViewCell {

    @IBOutlet weak var imgLibraries: UIImageView!
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var lblDes: UILabel!
    @IBOutlet weak var lblJoinedPeople: UILabel!
    @IBOutlet weak var btnJoin: UIButton!
    @IBOutlet weak var btnEdit: UIButton!
    @IBOutlet weak var btnManageMember: UIButton!
    @IBOutlet weak var vwStar: CosmosView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func bindData(_ data: LibraryList){
        self.imgLibraries.sd_setImage(with: URL.init(string: (data.libraryImage ?? "").urlQueryEncoded ?? ""), placeholderImage: UIImage.init(named: "no_img"), completed: nil)
        self.lblTitle.text = data.libraryName
        self.lblDes.text = "Owner, \(data.libraryOwnerName ?? "")"
        self.lblJoinedPeople.text = "\(data.totalAcceptedRequests ?? 0) People Joined."
        self.lblJoinedPeople.isHidden = data.totalAcceptedRequests ?? 0 <= 0
        self.vwStar.rating = data.ratings ?? 0.0
        
        if data.userID == AppSettings.currentUser?.userID{
            self.btnJoin.isHidden = true
            self.btnEdit.isHidden = false
            self.btnManageMember.isHidden = false
            self.btnManageMember.isHidden = data.totalPendingRequests ?? 0 <= 0
            self.btnManageMember.setTitle("\(data.totalPendingRequests ?? 0)", for: .normal)
        }else{
            self.btnEdit.isHidden = true
            self.btnManageMember.isHidden = true
            self.btnJoin.isHidden = data.userID == AppSettings.currentUser?.userID || data.communityStatus ?? "" == "1"
            if data.communityStatus ?? "" == "0"{
                self.btnJoin.setTitle("Requested", for: .normal)
                self.btnJoin.backgroundColor = .lightGray
            }else{
                self.btnJoin.setTitle("Join", for: .normal)
                self.btnJoin.backgroundColor = UIColor.AppThemColor
            }
        }
    }
}
