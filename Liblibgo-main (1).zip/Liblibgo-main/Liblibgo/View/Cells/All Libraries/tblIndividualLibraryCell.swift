//
//  tblIndividualLibraryCell.swift
//  Liblibgo
//
//  Created by apple on 21/05/22.
//

import UIKit
import Cosmos

class tblIndividualLibraryCell: UITableViewCell {

    @IBOutlet weak var imgLibraries: UIImageView!
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var lblDes: UILabel!
    @IBOutlet weak var btnCall: UIButton!
    @IBOutlet weak var vwStar: CosmosView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
