//
//  tblTransactionHistoryCell.swift
//  Liblibgo
//
//  Created by apple on 19/06/22.
//

import UIKit

class tblTransactionHistoryCell: UITableViewCell {

    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var lblDate: UILabel!
    @IBOutlet weak var lblPrice: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func bindData(_ data: TransactionHistoryList){
        self.lblTitle.text = data.orderFor == "purchase" ? "You buy a book." : "You sell a book."
        self.lblDate.text = Utill.share.getFormatedDate(stringDate: data.transactionDate ?? "", format: "dd MMM yyyy", defaultformat: "yyyy-MM-dd HH:mm:ss")
        self.lblPrice.text = data.transactionType == "credit" ? "+ Rs.\(data.coins ?? "")" : "- Rs.\(data.coins ?? "")"
        self.self.lblPrice.textColor =  data.transactionType == "credit" ? UIColor.init(red: 0.0, green: 126/255, blue: 0.0, alpha: 1.0) : UIColor.red
    }
    
}
