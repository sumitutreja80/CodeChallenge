//
//  tblOrderHistoryListCell.swift
//  Liblibgo
//
//  Created by apple on 12/06/22.
//

import UIKit

class tblOrderHistoryListCell: UITableViewCell {

    @IBOutlet weak var lblOrderId: UILabel!
    @IBOutlet weak var lblDes: UILabel!
    @IBOutlet weak var lblDate: UILabel!
    @IBOutlet weak var btnViewDetail: UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func bindData(_ data: OrderList){
        self.lblOrderId.text = "Order ID - \(data.orderNumber ?? "")"
        self.lblDes.text = data.bookName
        self.lblDate.text = Utill.share.getFormatedDate(stringDate: data.orderDate ?? "", format: "dd MMM yyyy", defaultformat: "yyyy-MM-dd HH:mm:ss")
    }
}
