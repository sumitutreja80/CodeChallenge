//
//  tblCheckoutItemCell.swift
//  Liblibgo
//
//  Created by apple on 28/05/22.
//

import UIKit

class tblCheckoutItemCell: UITableViewCell {

    @IBOutlet weak var lblLibraryName: UILabel!
    @IBOutlet weak var lblTotalPrice: UILabel!
    @IBOutlet weak var lblShippingCharge: UILabel!
    @IBOutlet weak var swBookList: UIStackView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
