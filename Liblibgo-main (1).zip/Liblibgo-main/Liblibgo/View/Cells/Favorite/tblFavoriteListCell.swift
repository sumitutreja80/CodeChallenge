//
//  tblFavoriteListCell.swift
//  Liblibgo
//
//  Created by apple on 29/05/22.
//

import UIKit

class tblFavoriteListCell: UITableViewCell {

    @IBOutlet weak var imgBookImage: UIImageView!
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var lblOwnerName: UILabel!
    @IBOutlet weak var lblPrice: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
