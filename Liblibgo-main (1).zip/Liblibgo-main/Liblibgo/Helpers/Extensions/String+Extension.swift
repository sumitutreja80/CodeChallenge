//
//  String+Extension.swift
//  Liblibgo
//
//  Created by apple on 21/05/22.
//

import Foundation
import UIKit

extension String {
    
    var phoneFormatted: String {
        //"(###) ###-####"
        let input = self.normalFormatted
        var output = ""
        input.enumerated().forEach { index, c in
            if (index.isMultiple(of: 2) == false) {
                output = " "
            }
            output.append(c)
        }
        return output
    }
    
    var normalFormatted: String {
        return self.digits
    }
    
    var digits: String {
        return components(separatedBy: CharacterSet.decimalDigits.inverted)
            .joined()
    }
}
