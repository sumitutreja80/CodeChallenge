//
//  ViewController+Extension.swift
//  Liblibgo
//
//  Created by apple on 19/05/22.
//

import UIKit

typealias HandlerOk = (_ isClicked : Bool) -> Void

extension UIViewController {
    
    func popViewController() {
        self.navigationController?.popViewController(animated: true)
    }
    
    func dismissViewController() {
        self.dismiss(animated: true, completion: nil)
    }
    
    func showAlert(withMessage message: String?, preferredStyle: UIAlertController.Style = .alert, withActions actions: UIAlertAction...,title: String? = "Liblibgo") {
        if actions.count == 0{
            //Utill.showErrorMessage(message: message ?? "")
            return
        }
        let alert = UIAlertController(title: title, message: message, preferredStyle: preferredStyle)
        if actions.count == 0 {
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        } else {
            for action in actions {
                alert.addAction(action)
            }
        }
        self.present(alert, animated: true, completion: nil)
    }
    
    func showAlertYesNo(withMessage message : String, yesButtonText : String, noButtonText: String, parentController : UIViewController, isAnimate: Bool, handler : @escaping HandlerOk) {
        let alert = UIAlertController(title: AppName, message: message, preferredStyle: .alert)
        let buttonYes = UIAlertAction(title: yesButtonText, style: .default) { (_) in
            handler(true)
        }
        let buttonNo = UIAlertAction(title: noButtonText, style: .default) { (_) in
            handler(false)
        }
        alert.addAction(buttonYes)
        alert.addAction(buttonNo)
        parentController.present(alert, animated: isAnimate) {
        }
    }
    
    func topMostViewController() -> UIViewController {
        if self.presentedViewController == nil {
            return self
        }
        if let navigation = self.presentedViewController as? UINavigationController {
            return navigation.visibleViewController!.topMostViewController()
        }
        if let tab = self.presentedViewController as? UITabBarController {
            if let selectedTab = tab.selectedViewController {
                return selectedTab.topMostViewController()
            }
            return tab.topMostViewController()
        }
        return self.presentedViewController!.topMostViewController()
    }
}

extension UIViewController {
    
    static func swizzle() {
        let originalSelector1 = #selector(viewDidLoad)
        let swizzledSelector1 = #selector(swizzled_viewDidLoad)
        swizzling(UIViewController.self, originalSelector1, swizzledSelector1)
    }
    
    @objc open func swizzled_viewDidLoad() {
        if let _ = navigationController {
            if #available(iOS 14.0, *) {
                navigationItem.backButtonDisplayMode = .minimal
            } else {
                // Fallback on earlier versions
                navigationItem.backButtonTitle = ""
            }
        }
        swizzled_viewDidLoad()
    }
}

private let swizzling: (UIViewController.Type, Selector, Selector) -> Void = { forClass, originalSelector, swizzledSelector in
    if let originalMethod = class_getInstanceMethod(forClass, originalSelector), let swizzledMethod = class_getInstanceMethod(forClass, swizzledSelector) {
        let didAddMethod = class_addMethod(forClass, originalSelector, method_getImplementation(swizzledMethod), method_getTypeEncoding(swizzledMethod))
        if didAddMethod {
            class_replaceMethod(forClass, swizzledSelector, method_getImplementation(originalMethod), method_getTypeEncoding(originalMethod))
        } else {
            method_exchangeImplementations(originalMethod, swizzledMethod)
        }
    }
}

extension UIViewController {
    
    func showPopUp(withTitle title:String = AppName, message:String, options:[String], complition: @escaping ((String) -> Void)){
        
        let alert = UIAlertController(title: title, message: message, preferredStyle: options.count > 2 ? .actionSheet : .alert)
       
        let arrCancel = ["ok", "cancel", "no", "dismiss"]
        
        for option in options {
            let opt = UIAlertAction(title: option, style: arrCancel.contains(option.lowercased()) ? .cancel : .default) { (_) in
                complition(option)
            }
            
            alert.addAction(opt)
        }
        
        if UIDevice.current.userInterfaceIdiom == .pad {
            alert.popoverPresentationController?.sourceView = view
            alert.popoverPresentationController?.sourceRect = view.bounds
            alert.popoverPresentationController?.permittedArrowDirections = [.down, .up]
        }
        
        present(alert, animated: true, completion: nil)
    }
    
}

extension UIViewController {
    open override func awakeAfter(using coder: NSCoder) -> Any? {
        navigationItem.backButtonDisplayMode = .minimal // This will help us to remove text
        return super.awakeAfter(using: coder)
    }
}

extension UIApplication {

    class func getTopViewController(base: UIViewController? = UIApplication.shared.keyWindow?.rootViewController) -> UIViewController? {

        if let nav = base as? UINavigationController {
            return getTopViewController(base: nav.visibleViewController)

        } else if let tab = base as? UITabBarController, let selected = tab.selectedViewController {
            return getTopViewController(base: selected)

        } else if let presented = base?.presentedViewController {
            return getTopViewController(base: presented)
        }
        return base
    }
}
