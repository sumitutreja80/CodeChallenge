//
//  Utill.swift
//  Liblibgo
//
//  Created by apple on 22/05/22.
//

import Foundation
import NVActivityIndicatorView

class Utill: NSObject {
    
    static let share = Utill()
    
    class func openURL(strUrl: String){
        if let url = URL(string: strUrl), UIApplication.shared.canOpenURL(url) {
            if #available(iOS 10, *) {
                UIApplication.shared.open(url)
            } else {
                UIApplication.shared.openURL(url)
            }
        }
    }
    
    func getFormatedDate(stringDate: String,format: String,defaultformat: String) -> String?
    {
        let df  = DateFormatter()
        df.dateFormat = defaultformat
        df.locale = Locale.current
        df.amSymbol = "AM"
        df.pmSymbol = "PM"
        guard let date = df.date(from: stringDate) else {
            return nil
        }
        df.dateFormat = format
        return df.string(from: date)
    }
}
//MARK: Activity Indicatior
extension Utill{
    static var activityView: UIView? = nil
    static var activityIndicatorView: NVActivityIndicatorView? = nil
    static var gifImgView: UIImageView? = nil
    
    class func removeActivityIndicator() -> Void{
        activityView?.isHidden = true
        activityView?.removeFromSuperview()
        activityIndicatorView?.stopAnimating()
    }
    
    class func showActivityIndicator() {
        
        guard let window = AppDelegate.appDelegate.window else{
            return
        }
        
        if let activityView = activityView{
            window.addSubview(activityView)
            activityIndicatorView? .startAnimating()
            activityView.isHidden = false
            return
        }
        
        activityView = UIView(frame: UIScreen.main.bounds)
        activityView?.backgroundColor = .clear
        activityIndicatorView  =  NVActivityIndicatorView(frame: CGRect(x: 0, y: 0, width: 50, height: 50), type: .ballRotateChase, color: #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1), padding: 50)
        activityIndicatorView?.center = window.center
        activityView?.addSubview(activityIndicatorView!)
        window.addSubview(activityView!)
        activityIndicatorView? .startAnimating()
        activityView?.isHidden = false
    }
    
}

//MARK: Tost
extension Utill{
    
    class func setTost(title:String?, message:String?, controller: UIViewController, completion: ((_ didTap: Bool) -> Void)? = nil) {
        var style = ToastStyle()
        style.messageFont = UIFont.systemFont(ofSize: 14)
        style.messageColor = UIColor.white
        style.messageAlignment = .center
        style.backgroundColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1).withAlphaComponent(0.7)
        style.titleAlignment = .center
        controller.view.makeToast(message, duration: 3, position: .bottom, title: title, image: nil, style: style, completion: completion)
    }
}

extension Utill{
    
    func isValidEmail(text: String) -> Bool {
        let regex1 : String = "\\A[A-Za-z0-9]+([-._][a-z0-9]+)*@([a-z0-9]+(-[a-z0-9]+)*\\.)+[a-z]{2,64}\\z"
        let regex2 : String = "^(?=.{1,64}@.{4,64}$)(?=.{6,100}$).*"
        let test1 : NSPredicate = NSPredicate.init(format: "SELF MATCHES %@", regex1)
        let test2 : NSPredicate = NSPredicate.init(format: "SELF MATCHES %@", regex2)
        return test1.evaluate(with: text) &&  test2.evaluate(with: text)
    }
}

//MARK: Notification
extension Utill: UNUserNotificationCenterDelegate{
    
    func registerNotification(){
        if #available(iOS 10.0, *) {
            let center  = UNUserNotificationCenter.current()
            center.delegate = self
            center.requestAuthorization(options: [.badge, .sound, .alert]) { (granted, error) in
                guard granted else { return }
                self.getNotificationSettings()
            }
        }
        else {
            UIApplication.shared.registerUserNotificationSettings(UIUserNotificationSettings(types: [.sound, .alert, .badge], categories: nil))
            UIApplication.shared.registerForRemoteNotifications()
        }
    }
    
    func getNotificationSettings() {
        if #available(iOS 10.0, *) {
            UNUserNotificationCenter.current().getNotificationSettings { (settings) in
                //print("Notification settings: \(settings)")
                guard settings.authorizationStatus == .authorized else { return }
                DispatchQueue.main.async{
                    UIApplication.shared.registerForRemoteNotifications()
                }
            }
        }
    }
        
    @available(iOS 10.0, *)
    func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification, withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        print("User Info = ",notification.request.content.userInfo)
        completionHandler([.banner, .list, .badge, .sound])
    }
    
    //Called to let your app know which action was selected by the user for a given notification.
    @available(iOS 10.0, *)
    func userNotificationCenter(_ center: UNUserNotificationCenter, didReceive response: UNNotificationResponse, withCompletionHandler completionHandler: @escaping () -> Void) {
        print("User Info = ",response.notification.request.content.userInfo)
        completionHandler()
    }
    
    class func isNotificationEnable(callback : @escaping (_ isEnable : Bool) -> Void) -> Void{
        
        if #available(iOS 10.0, *) {
            let current = UNUserNotificationCenter.current()
            current.getNotificationSettings(completionHandler: { (settings) in
                if settings.authorizationStatus == .notDetermined {
                    callback(false)
                }
                if settings.authorizationStatus == .denied {
                    // User should enable notifications from settings & privacy
                    // show an alert or sth
                    callback(false)
                    
                }
                if settings.authorizationStatus == .authorized {
                    // It's okay, no need to request
                    callback(true)
                }
            })
        }
        else{
            let notificationType = UIApplication.shared.currentUserNotificationSettings?.types
            if notificationType?.rawValue == 0 {
                callback(false)
            } else {
                callback(true)
            }
        }
    }
}
