//
//  AppDelegate.swift
//  Liblibgo
//
//  Created by apple on 18/05/22.
//

import UIKit
import SDWebImage
import DropDown
import IQKeyboardManagerSwift
import FirebaseCore
import FirebaseMessaging
import UserNotifications

@main
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?
    static var appDelegate = UIApplication.shared.delegate as! AppDelegate
    let gcmMessageIDKey = "gcm.message_id"
    var pushDeviceToken: String = "iosTest"
    var notificationPayload : [AnyHashable : Any]?
    var launchOptions: [UIApplication.LaunchOptionsKey: Any]?
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        FirebaseApp.configure()
        Messaging.messaging().delegate = self
        IQKeyboardManager.shared.enable = true
        self.setAppearance()
        self.appearanceDropDown()
        if let keys = launchOptions?.keys {
            if keys.contains(.remoteNotification) {
                if let options = launchOptions, let remoteNotif = options[UIApplication.LaunchOptionsKey.remoteNotification] as? [String: Any]{
                    self.notificationPayload = remoteNotif
                }
            }
        }
        return true
    }
    
    fileprivate func setAppearance(){
        UITabBar.appearance().unselectedItemTintColor = UIColor.systemGray
        if #available(iOS 15, *) {
            let appearance = UINavigationBarAppearance()
            appearance.configureWithOpaqueBackground()
            appearance.backgroundColor = .AppThemColor
            appearance.shadowColor = .clear
            appearance.shadowImage = UIImage()
            appearance.titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white]
            UINavigationBar.appearance().standardAppearance = appearance
            UINavigationBar.appearance().scrollEdgeAppearance = appearance
            UINavigationBar.appearance().tintColor = .white
            
            let tabBarApperance = UITabBarAppearance()
            tabBarApperance.configureWithOpaqueBackground()
            tabBarApperance.backgroundColor = UIColor.clear
            UITabBar.appearance().scrollEdgeAppearance = tabBarApperance
            UITabBar.appearance().standardAppearance = tabBarApperance
        }else{
            UINavigationBar.appearance().barTintColor = .AppThemColor
            UINavigationBar.appearance().shadowImage = UIImage()
            UINavigationBar.appearance().setBackgroundImage(UIImage(), for: .default)
            UINavigationBar.appearance().tintColor = .white
            UINavigationBar.appearance().titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white]
            UINavigationBar.appearance().isTranslucent = false
        }
    }
    
    fileprivate func appearanceDropDown(){
        DropDown.appearance().setupCornerRadius(10)
//        DropDown.appearance().textColor = UIColor.black
//        DropDown.appearance().selectedTextColor = UIColor.white
//        DropDown.appearance().textFont = UIFont.systemFont(ofSize: 15)
//        DropDown.appearance().backgroundColor = UIColor.lightGray
//        DropDown.appearance().selectionBackgroundColor = UIColor.AppThemColor
//        DropDown.appearance().direction = .bottom
    }
    
    func GoToDashboard(){
        guard let rootVC = StoryBoards.Main.instantiateInitialViewController() else {
            return
        }
        UIApplication.shared.keyWindow?.rootViewController = rootVC
        UIApplication.shared.keyWindow?.makeKeyAndVisible()
    }

}

//MARK: Notification Methods
extension AppDelegate: MessagingDelegate{
    
    func messaging(_ messaging: Messaging, didReceiveRegistrationToken fcmToken: String?) {
        print("Firebase registration token: \(String(describing: fcmToken))")
        self.pushDeviceToken = fcmToken ?? "iosTest"
        let dataDict: [String: String] = ["token": fcmToken ?? ""]
        NotificationCenter.default.post(
            name: Notification.Name("FCMToken"),
            object: nil,
            userInfo: dataDict
        )
        // TODO: If necessary send token to application server.
        // Note: This callback is fired at each app startup and whenever a new token is generated.
    }
    
    func application(application: UIApplication,
                     didRegisterForRemoteNotificationsWithDeviceToken deviceToken: Data) {
        let tokenParts = deviceToken.map { data -> String in
            return String(format: "%02.2hhx", data)
        }
        
        let token = tokenParts.joined()
        print("Device Token: \(token)")
        Messaging.messaging().apnsToken = deviceToken
    }
}
