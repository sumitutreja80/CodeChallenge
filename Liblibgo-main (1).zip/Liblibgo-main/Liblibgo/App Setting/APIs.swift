//
//  APIs.swift
//  Liblibgo
//
//  Created by apple on 22/05/22.
//

import Foundation

struct Endpoints {
    
    static let APIKey = ""
    static let GmapKey = ""
    static let AuthAPIKey = "48047_e5da204a55741d7ccc1181ce78f2a1d4"
    static let razorpayKey = "rzp_live_xIyK82spLYOlFZ"//like key = rzp_live_xIyK82spLYOlFZ //test key = rzp_test_ab0c3Odp7tRGlJ
    static let aboutUs = "https://liblibgo.com/"
    static let tcURL = "https://liblibgo.com/terms-condition"
    static let privacyURL = "https://liblibgo.com/privacy-policy"
    static let baseURL = "https://liblibgo.com/User/", //QA = https://liblibgo.com/User/ Live = http://staging.liblibgo.com/User/
    
    Login = "login",
    verifyOtp = "verifyOtp",
    reSendOTP = "login",
    GetUserDetails = "GetUserDetails",
    UpdateProfileImage = "UpdateProfileImage",
    UpdateUserProfile = "UpdateUserProfile",
    LibraryListNearByMe = "LibraryListNearByMe",
    BannerList = "BannerList",
    ApartmentLibraryListNearByMe = "ApartmentLibraryListNearByMe",
    SentCommunityRequest = "SentCommunityRequest",
    CheckLibraryCommunityStatus = "CheckLibraryCommunityStatus",
    CheckApartmentLibraryStatus = "CheckApartmentLibraryStatus",
    MyCommunityRequestList = "MyCommunityRequestList",
    AcceptRejectCommunityRequest = "AcceptRejectCommunityRequest",
    BookListByCategoryOrLibrary = "BookListByCategoryOrLibrary",
    BookDetails = "BookDetails",
    AddToWishList = "AddToWishList",
    AddToCart = "AddToCart",
    NotifyMe = "notify_me",
    MyCartList = "MyCartList",
    RemoveCart = "RemoveCart",
    Checkout = "Checkout",
    CreateOwnLibrary = "CreateOwnLibrary",
    MyWishlist = "MyWishlist",
    CreateOrder = "CreateOrder",
    GetNotificationList = "GetNotificationList",
    MyOrders = "MyOrders",
    SearchByBookNameFilter = "SearchByBookNameFilter",
    OrderDetails = "OrderDetails",
    CategoryList = "CategoryList",
    TransactionHistory = "transaction_history",
    NotificationSettingList = "NotificationSettingList",
    ChangeNotificationSettings = "ChangeNotificationSettings",
    MyCommunityJoinedList = "MyCommunityJoinedList",
    GetOwnLibraryProfile = "GetOwnLibraryProfile",
    bookEntry = "book_entry",
    UploadBookImage = "UploadBookImage",
    EditLibraryProfile = "EditLibraryProfile",
    OwnLibraryBooks = "OwnLibraryBooks",
    BookActiveInactive = "BookActiveInactive",
    BookStackUpload = "Book_stack_upload",
    UserRegistrationByMobile = "UserRegistrationByMobile",
    PostRedeemLibcoinsRequest = "PostRedeemLibcoinsRequest",
    UpdateCartRentDuration = "UpdateCartRentDuration",
    DeleteMyAccount = "DeleteMyAccount"
}
