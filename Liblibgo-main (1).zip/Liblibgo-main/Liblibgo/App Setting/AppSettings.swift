//
//  AppSettings.swift
//  Liblibgo
//
//  Created by apple on 22/05/22.
//

import UIKit

final class AppSettings {
    
    public static let APP_NAME = "Liblibgo"
    public static var currentUser : User?
    public static var deviceId = UIDevice.current.identifierForVendor?.uuidString
    
    public static var communityId: String{
        get{
            let id = UserDefaults.standard.value(forKey: "communityId") as? String ?? ""
            return id
        }set{
            UserDefaults.standard.set(newValue, forKey: "communityId")
        }
    }
    
    public static var cartBadgeCount: Int{
        get{
            let id = UserDefaults.standard.value(forKey: "cartBadgeCount") as? Int ?? 0
            return id
        }set{
            UserDefaults.standard.set(newValue, forKey: "cartBadgeCount")
        }
    }
    
    private enum SettingKey: String {
        case displayName
        case islogin
        case Ftoken
        case loginId
    }
    
    static var currentLan = "en"
    
    public static var dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSSZZZZZ"
    
    public static var dateFormatter: DateFormatter = {
        let df = DateFormatter()
        df.dateFormat = AppSettings.dateFormat
        return df
    }()

}
