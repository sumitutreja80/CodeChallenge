//
//  ApiManager.swift
//  Liblibgo
//
//  Created by apple on 22/05/22.
//

import UIKit
import Alamofire

class ApiManager: NSObject {
    
    public var manager: Alamofire.SessionManager
    public var backgroundSessionManager: Alamofire.SessionManager
    private let queueApi = DispatchQueue(label: "com.queue.api", qos: DispatchQoS.userInitiated)
    private var header = ["Accept" : "application/json"]
    
    override init() {
        self.manager = Alamofire.SessionManager(configuration: URLSessionConfiguration.default)
        self.backgroundSessionManager = Alamofire.SessionManager(configuration: URLSessionConfiguration.background(withIdentifier: "Parth.Liblibgo"))
    }
    
    static let sharedInstance = ApiManager()
    
    func request<T :Decodable>(url: String, method : HTTPMethod = .post,  parameter : [String : Any], completion: @escaping (Swift.Result<T, ErrorType>) -> ()){
        queueApi.async {[weak self] in self?.manager.session.configuration.timeoutIntervalForRequest = 60
            print("\(Endpoints.baseURL)\(url)")
            print(parameter)
            print(method.rawValue)
            self?.manager.requestWithCacheOrLoad("\(Endpoints.baseURL)\(url)", method: method, parameters: parameter, headers: self?.header).response(completionHandler: { (responce) in
                print(responce.request?.allHTTPHeaderFields as Any)
                guard let statusCode = responce.response?.statusCode, (200...299).contains(statusCode) else {
                    let errorType: ErrorType
                    switch responce.response?.statusCode {
                    case 401, 403:
                        self?.manager.adapter = nil
                        self?.backgroundSessionManager.adapter = nil
                        AppSettings.currentUser?.clearFromDefault()
                        if let vc = UIApplication.getTopViewController(){
                            vc.showPopUp(message: "Session time out.\nPlease login again!", options: [Messages.BTN_OK]) { (_) in
                                AppDelegate.appDelegate.GoToDashboard()
                            }
                        }
                        errorType = .notFound
                        return
                    case 404:
                        errorType = .notFound
                    case 422:
                        errorType = .validationError
                    case 417:
                        errorType = .wrongOTP
                    case 500:
                        errorType = .serverError
                    default:
                        errorType = .defaultError
                    }
                    
                    /*if let d = responce.data {
                        self?.displayErrorMessage(result: d)
                    }else{
                        //showMessage(text: errorType.localizedDescription)
                        if let topVC = UIApplication.getTopViewController(){
                            topVC.showPopUp(message: errorType.localizedDescription, options: [Messages.BTN_OK]) { _ in }
                        }
                    }*/
                    completion(Swift.Result.failure(errorType))
                    return
                }
                
                guard let data = responce.data else{
                    completion(Swift.Result.failure(.defaultError))
                    return
                }
                let decoder = JSONDecoder()
                do{
                    let responseData = try decoder.decode(T.self, from: data)
                    completion(Swift.Result.success(responseData))
                }catch let DecodingError.dataCorrupted(context) {
                    print(context)
                    completion(.failure(.parseResponseFail))
                } catch let DecodingError.keyNotFound(key, context) {
                    print("Key '\(key)' not found:", context.debugDescription)
                    print("codingPath:", context.codingPath)
                    completion(.failure(.parseResponseFail))
                } catch let DecodingError.valueNotFound(value, context) {
                    print("Value '\(value)' not found:", context.debugDescription)
                    print("codingPath:", context.codingPath)
                    completion(.failure(.parseResponseFail))
                } catch let DecodingError.typeMismatch(type, context)  {
                    print("Type '\(type)' mismatch:", context.debugDescription)
                    print("codingPath:", context.codingPath)
                    completion(.failure(.parseResponseFail))
                }catch _{
                    completion(.failure(.parseResponseFail))
                }
            })
        }
    }
    
    func uploadRequest<T :Decodable>(url: String, method : HTTPMethod,  parameter : [String : Any], arrImage : [(String, UIImage)], arrVideo : [(String, URL)]? = nil, arrAudio : [(String, URL)]? = nil, completion: @escaping (Swift.Result<T, Error>) -> ()){
            
            ApiManager.sharedInstance.backgroundSessionManager.upload(multipartFormData: { (multipartFormData) in
                
                for (_,image) in arrImage.enumerated()
                {
                    multipartFormData.append(image.1.jpegData(compressionQuality: 0.5)!, withName: "\(image.0)", fileName: "image_\(self.currentTimeInMilliSeconds()).jpeg", mimeType: "image/jpeg")
                }
                
                if arrVideo != nil
                {
                    for (_,urll) in arrVideo!.enumerated()
                    {
                        multipartFormData.append(urll.1, withName: urll.0, fileName: "video_\(self.currentTimeInMilliSeconds()).mp4", mimeType: "video/mp4")
                    }
                }
                
                if arrAudio != nil
                {
                    for (_,urll) in arrAudio!.enumerated()
                    {
                        var strURL = ""
                        if urll.1.absoluteString.contains("file://"){
                            strURL = urll.1.absoluteString + ".m4a"
                        }else{
                            strURL = "file://" + urll.1.absoluteString
                        }
                        guard let newURL:URL = URL.init(string: strURL) else {return}
                        guard let audioFile: Data = try? Data (contentsOf: newURL) else {return}
                        //multipartFormData.append(urll.1, withName: urll.0, fileName: "audio.m4a", mimeType: "audio/m4a")
                        print(audioFile)
                        multipartFormData.append(audioFile, withName: urll.0, fileName: "audio\(self.currentTimeInMilliSeconds()).m4a", mimeType: "audio/m4a")
                    }
                }
                
                let param = parameter
                print("\(Endpoints.baseURL)\(url)")
                print(param)
                
                for (key, value) in param
                {
                    if value is String {
                        multipartFormData.append((value as AnyObject).data(using: String.Encoding.utf8.rawValue)!, withName: key)
                    }
                    else if value is Bool{
                        multipartFormData.append((value as AnyObject).description.data(using: String.Encoding(rawValue: String.Encoding.utf8.rawValue))!, withName: key)
                    }
                    else if value is Int{
                        multipartFormData.append((value as AnyObject).description.data(using: String.Encoding(rawValue: String.Encoding.utf8.rawValue))!, withName: key)
                    }
                    else if let val = value as? [String]{
                        val.forEach { (str) in
                            multipartFormData.append((str as AnyObject).data(using: String.Encoding.utf8.rawValue)!, withName: key)
                        }
                    }
                }
            }, to: "\(Endpoints.baseURL)\(url)", headers: self.header)
            { (result) in
                switch result{
                case .success(let upload, _, _):
                    upload.uploadProgress(queue: .init(label: "com.liblibgo")) { (progress) in
                        print("Upload Progress: \(progress.fractionCompleted)")
                    }
                    print("Estimate Time Upload \(String(describing: upload.uploadProgress.estimatedTimeRemaining))")
                    print("Estimate Time Upload \(String(describing: upload.progress.estimatedTimeRemaining))")
                    print("Upload Progress: \(upload.progress.fractionCompleted)")
                    upload.responseJSON { [weak self] responce in
                        print(responce.request?.allHTTPHeaderFields as Any)
                        guard let statusCode = responce.response?.statusCode, (200...299).contains(statusCode) else {
                            let errorType: ErrorType
                            switch responce.response?.statusCode {
                            case 401, 403:
                                self?.manager.adapter = nil
                                self?.backgroundSessionManager.adapter = nil
                                if let vc = UIApplication.getTopViewController(){
                                    vc.showPopUp(message: "Session time out.\nPlease login again!", options: [Messages.BTN_OK]) { (_) in
                                        AppDelegate.appDelegate.GoToDashboard()
                                    }
                                }
                                errorType = .notFound
                                return
                            case 404:
                                errorType = .notFound
                            case 422:
                                errorType = .validationError
                            case 417:
                                errorType = .wrongOTP
                            case 500:
                                errorType = .serverError
                            default:
                                errorType = .defaultError
                            }
                            
                            /*if let d = responce.data {
                                self?.displayErrorMessage(result: d)
                            }else{
                                //showMessage(text: errorType.localizedDescription)
                                if let topVC = UIApplication.getTopViewController(){
                                    topVC.showPopUp(message: errorType.localizedDescription, options: [Messages.BTN_OK]) { _ in }
                                }
                            }*/
                            completion(Swift.Result.failure(errorType))
                            return
                        }
                        
                        guard let data = responce.data else{
                            completion(.failure(responce.error!))
                            return
                        }
                        
                        let decoder = JSONDecoder()
                        do{
                            let responseData = try decoder.decode(T.self, from: data)
                            completion(Swift.Result.success(responseData))
                        }catch let DecodingError.dataCorrupted(context) {
                            print(context)
                        } catch let DecodingError.keyNotFound(key, context) {
                            print("Key '\(key)' not found:", context.debugDescription)
                            print("codingPath:", context.codingPath)
                        } catch let DecodingError.valueNotFound(value, context) {
                            print("Value '\(value)' not found:", context.debugDescription)
                            print("codingPath:", context.codingPath)
                        } catch let DecodingError.typeMismatch(type, context)  {
                            print("Type '\(type)' mismatch:", context.debugDescription)
                            print("codingPath:", context.codingPath)
                        }catch let error{
                            completion(.failure(error))
                        }
                    }
                case .failure(let encodingError):
                    completion(.failure(encodingError))
                }
            }
        }

    
    /*private func displayErrorMessage(result: Data){
        do {
            let response = try JSONDecoder().decode(GeneralResponse.self, from: result)
            //showMessage(text: response.error!)
            if let topVC = UIApplication.getTopViewController(){
                topVC.showPopUp(message: response.message ?? Messages.SOMETHING_WRONG, options: [Messages.BTN_OK]) { _ in }
            }
        } catch let parsingError {
            print("Error", parsingError)
        }
        
    }*/
    
    private func currentTimeInMilliSeconds()-> Int
    {
        let currentDate = Date()
        let since1970 = currentDate.timeIntervalSince1970
        return Int(since1970 * 1000)
    }
    
}

extension Alamofire.SessionManager{
    
    @discardableResult
    open func requestWithCacheOrLoad(
        _ url: URLConvertible,
        method: HTTPMethod = .get,
        parameters: Parameters? = nil,
        encoding: ParameterEncoding = URLEncoding.default,
        headers: HTTPHeaders? = nil)
        -> DataRequest
    {
        do {
            var urlRequest = try URLRequest(url: url, method: method, headers: headers)
            urlRequest.cachePolicy = .reloadIgnoringLocalAndRemoteCacheData
            let encodedURLRequest = try encoding.encode(urlRequest, with: parameters)
            return request(encodedURLRequest)
        } catch {
            return request(URLRequest(url: URL(string: "http://koolmindapps.com")!))
        }
    }
}
