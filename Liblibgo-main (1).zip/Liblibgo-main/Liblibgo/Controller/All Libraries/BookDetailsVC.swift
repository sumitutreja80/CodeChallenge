//
//  BookDetailsVC.swift
//  Liblibgo
//
//  Created by apple on 28/05/22.
//

import UIKit

class BookDetailsVC: UIViewController {

    @IBOutlet weak var imgBookImage: UIImageView!
    @IBOutlet weak var btnFavorite: UIButton!
    @IBOutlet weak var btnCart: UIButton!
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var lblOwnerName: UILabel!
    @IBOutlet weak var lblMRP: UILabel!
    @IBOutlet weak var lblBuyAt: UILabel!
    @IBOutlet weak var lblRentDay: UILabel!
    @IBOutlet weak var lblDes: UILabel!
    @IBOutlet weak var btnBuyNow: UIButton!
    @IBOutlet weak var btnRentIn: UIButton!
    
    var objBookDetail: BookList?
    private var hub: BadgeHub?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.imgBookImage.sd_setImage(with: URL.init(string: self.objBookDetail?.imageURL?.urlQueryEncoded ?? ""), placeholderImage: nil, completed: nil)
        self.prepareUI()
        self.getBookDetail(bookId: self.objBookDetail?.bookID ?? "")
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.setNavigationBarHidden(true, animated: true)
        self.hub?.setCount(AppSettings.cartBadgeCount)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.navigationController?.setNavigationBarHidden(false, animated: true)
    }

    static func instance() -> BookDetailsVC{
        return StoryBoards.Main.instantiateViewController(withIdentifier: "BookDetailsVC") as! BookDetailsVC
    }
    
    fileprivate func prepareUI(){
        self.lblTitle.text = self.objBookDetail?.bookName
        self.lblOwnerName.text = "By \(self.objBookDetail?.authorName ?? "")"
        self.lblMRP.text = "MRP : ₹\(self.objBookDetail?.mrp ?? "")"
        self.lblBuyAt.text = "Buy at : ₹\(self.objBookDetail?.salePrice ?? "")"
        self.lblRentDay.text = "Rent/day at : ₹\(self.objBookDetail?.rentalPrice ?? "")"
        self.lblDes.text = self.objBookDetail?.description
        if let quantity = self.objBookDetail?.quantity{
            let qty = Int(quantity) ?? 0
            if qty <= 0{
                self.btnBuyNow.setTitle("Book Out Of Stock", for: .normal)
                self.btnBuyNow.backgroundColor = .systemRed
                self.btnRentIn.setTitle("Notify", for: .normal)
                self.btnRentIn.backgroundColor = .AppThemColor
                self.btnBuyNow.isHidden = false
                self.btnRentIn.isHidden = false
            }else{
                if self.objBookDetail?.sellingType ?? "" == "Both"{
                    self.btnBuyNow.isHidden = false
                    self.btnRentIn.isHidden = false
                }else if self.objBookDetail?.sellingType ?? "" == "For Sale"{
                    self.btnBuyNow.isHidden = false
                    self.btnRentIn.isHidden = true
                }else if self.objBookDetail?.sellingType ?? "" == "For Rent"{
                    self.btnBuyNow.isHidden = true
                    self.btnRentIn.isHidden = false
                }else{
                    self.btnBuyNow.isHidden = true
                    self.btnRentIn.isHidden = true
                }
            }
        }else{
            self.btnBuyNow.isHidden = true
            self.btnRentIn.isHidden = true
        }
        hub = BadgeHub(view: self.btnCart)
    }
    
    fileprivate func getBookDetail(bookId: String){
        Utill.showActivityIndicator()
        ApiManager.sharedInstance.request(url: Endpoints.BookDetails, parameter: ["book_id": bookId]) { (result: Result<BookDetailModel, ErrorType>) in
            Utill.removeActivityIndicator()
            guard let res = try? result.get() else { return }
            self.objBookDetail = res.response?.bookList
            self.prepareUI()
        }
    }
    
    @IBAction func btnBack(_ sender: UIButton){
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btnFavoriteTap(_ sender: UIButton){
        Utill.showActivityIndicator()
        ApiManager.sharedInstance.request(url: Endpoints.AddToWishList, parameter: ["user_id":AppSettings.currentUser?.userID ?? "", "book_id": self.objBookDetail?.bookID ?? ""]) { (result: Result<WishListAddRemoveModel, ErrorType>) in
            Utill.removeActivityIndicator()
            guard let res = try? result.get() else { return }
            Utill.setTost(title: nil, message: res.response?.message ?? "", controller: self, completion: nil)
            if res.response?.wishlistStatus ?? 0 == 0{
                self.btnFavorite.setImage(UIImage.init(systemName: "heart")?.applyingSymbolConfiguration(.init(scale: .large)), for: .normal)
                self.btnFavorite.tintColor = .lightGray
            }else{
                self.btnFavorite.setImage(UIImage.init(systemName: "heart.fill")?.applyingSymbolConfiguration(.init(scale: .large)), for: .normal)
                self.btnFavorite.tintColor = .red
            }
        }
    }
    
    @IBAction func btnCartTap(_ sender: UIButton){
        let vc = CartVC.instance()
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func btnBuyNowTap(_ sender: UIButton){
        if AppSettings.currentUser?.userID == self.objBookDetail?.ownerId{
            Utill.setTost(title: nil, message: "This is your own book.", controller: self, completion: nil)
        }else{
            Utill.showActivityIndicator()
            ApiManager.sharedInstance.request(url: Endpoints.AddToCart, parameter: ["user_id":AppSettings.currentUser?.userID ?? "", "book_id": self.objBookDetail?.bookID ?? "", "quantity": "1", "cart_for":"purchase"]) { (result: Result<WishListAddRemoveModel, ErrorType>) in
                Utill.removeActivityIndicator()
                guard let res = try? result.get() else { return }
                if res.response?.code ?? 0 == 1{
                    AppSettings.cartBadgeCount += 1
                    self.hub?.increment(by: 1)
                }
                Utill.setTost(title: nil, message: res.response?.message ?? "", controller: self, completion: nil)
            }
        }
    }
    
    @IBAction func btnRentInTap(_ sender: UIButton){
        if AppSettings.currentUser?.userID == self.objBookDetail?.ownerId{
            Utill.setTost(title: nil, message: "This is your own book.", controller: self, completion: nil)
        }else{
            if sender.currentTitle == "Notify"{
                Utill.showActivityIndicator()
                ApiManager.sharedInstance.request(url: Endpoints.NotifyMe, parameter: ["user_id":AppSettings.currentUser?.userID ?? "", "book_id": self.objBookDetail?.bookID ?? ""]) { (result: Result<WishListAddRemoveModel, ErrorType>) in
                    Utill.removeActivityIndicator()
                    guard let res = try? result.get() else { return }
                    Utill.setTost(title: nil, message: res.response?.message ?? "", controller: self, completion: nil)
                }
            }else{
                Utill.showActivityIndicator()
                ApiManager.sharedInstance.request(url: Endpoints.AddToCart, parameter: ["user_id":AppSettings.currentUser?.userID ?? "", "book_id": self.objBookDetail?.bookID ?? "", "quantity": "1", "cart_for":"rent"]) { (result: Result<WishListAddRemoveModel, ErrorType>) in
                    Utill.removeActivityIndicator()
                    guard let res = try? result.get() else { return }
                    if res.response?.code ?? 0 == 1{
                        AppSettings.cartBadgeCount += 1
                        self.hub?.increment(by: 1)
                    }
                    Utill.setTost(title: nil, message: res.response?.message ?? "", controller: self, completion: nil)
                }
            }
        }
    }

}
