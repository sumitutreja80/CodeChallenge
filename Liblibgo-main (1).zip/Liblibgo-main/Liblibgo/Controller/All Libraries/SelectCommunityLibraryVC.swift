//
//  SelectCommunityLibraryVC.swift
//  Liblibgo
//
//  Created by apple on 22/05/22.
//

import UIKit

class SelectCommunityLibraryVC: UIViewController {

    var isOwnLibrary = false
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.navigationController?.setNavigationBarHidden(false, animated: true)
    }
    

    static func instance() -> SelectCommunityLibraryVC{
        return StoryBoards.Main.instantiateViewController(withIdentifier: "SelectCommunityLibraryVC") as! SelectCommunityLibraryVC
    }
    
    @IBAction func btnClose(_ sender: UIButton){
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btnLibraryList(_ sender: UIButton){
        
    }
    
    @IBAction func btnCreateVirtuallibrary(_ sender: UIButton){
        let vc = CreateVirtuallibraryVC.instance()
        vc.isOwnLibrary = self.isOwnLibrary
        self.navigationController?.pushViewController(vc, animated: true)
    }

}
