//
//  ManageCommunityUsersVC.swift
//  Liblibgo
//
//  Created by apple on 26/05/22.
//

import UIKit

class ManageCommunityUsersVC: UIViewController {

    @IBOutlet weak var tblCommunityRequestList: UITableView!
    
    var arrCommunityRequestList: [MyCommunityRequestList] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.title = "Manage Community Users"
        self.prepareUI()
        self.getCommunityUsersRequestList()
    }
    
    static func instance() -> ManageCommunityUsersVC{
        return StoryBoards.Main.instantiateViewController(withIdentifier: "ManageCommunityUsersVC") as! ManageCommunityUsersVC
    }
    
    fileprivate func prepareUI(){
        self.tblCommunityRequestList.register(UINib.init(nibName: "tblCommunityRequestListCell", bundle: nil), forCellReuseIdentifier: "tblCommunityRequestListCell")
        let refreshControl = UIRefreshControl()
        refreshControl.addTarget(self, action: #selector(self.refreshData), for: .valueChanged)
        self.tblCommunityRequestList.refreshControl = refreshControl
        self.tblCommunityRequestList.tableFooterView = UIView()
    }
    
    @objc func refreshData(){
        self.getCommunityUsersRequestList()
    }
    
    fileprivate func getCommunityUsersRequestList(){
        self.tblCommunityRequestList.refreshControl?.beginRefreshing()
        ApiManager.sharedInstance.request(url: Endpoints.MyCommunityRequestList, parameter: ["user_id": AppSettings.currentUser?.userID ?? ""]) { (result: Result<MyCommunityRequestModel, ErrorType>) in
            self.tblCommunityRequestList.refreshControl?.endRefreshing()
            guard let res = try? result.get() else { return }
            self.arrCommunityRequestList = res.response?.requestList ?? []
            self.tblCommunityRequestList.reloadData()
        }
    }

}

extension ManageCommunityUsersVC: UITableViewDelegate, UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.arrCommunityRequestList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "tblCommunityRequestListCell", for: indexPath) as! tblCommunityRequestListCell
        cell.lblTitle.text = self.arrCommunityRequestList[indexPath.row].requestUserName
        cell.lblNumber.text = "+91\(self.arrCommunityRequestList[indexPath.row].requestUserMobile ?? "")"
        cell.btnAccept.tag = indexPath.row
        cell.btnReject.tag = indexPath.row
        cell.btnAccepted.tag = indexPath.row
        if self.arrCommunityRequestList[indexPath.row].communityStatus ?? "0" == "0"{
            cell.btnAccept.isHidden = false
            cell.btnReject.isHidden = false
            cell.btnAccepted.isHidden = true
        }else if self.arrCommunityRequestList[indexPath.row].communityStatus ?? "0" == "1"{
            cell.btnAccept.isHidden = true
            cell.btnReject.isHidden = true
            cell.btnAccepted.isHidden = false
            cell.btnAccepted.setTitle("Accepted", for: .normal)
        }else{
            cell.btnAccept.isHidden = true
            cell.btnReject.isHidden = true
            cell.btnAccepted.isHidden = false
            cell.btnAccepted.setTitle("Rejected", for: .normal)
        }
        cell.btnAccept.addTarget(self, action: #selector(self.btnAcceptTap(_:)), for: .touchUpInside)
        cell.btnReject.addTarget(self, action: #selector(self.btnRejectTap(_:)), for: .touchUpInside)
        cell.btnAccepted.addTarget(self, action: #selector(self.btnAcceptedTap(_:)), for: .touchUpInside)
        return cell
    }
    
    @objc func btnAcceptTap(_ sender: UIButton){
        Utill.showActivityIndicator()
        ApiManager.sharedInstance.request(url: Endpoints.AcceptRejectCommunityRequest, parameter: ["community_id":self.arrCommunityRequestList[sender.tag].communityID ?? "", "request_status": "1"]) { (result: Result<LibraryModel, ErrorType>) in
            Utill.removeActivityIndicator()
            guard (try? result.get()) != nil else { return }
            self.arrCommunityRequestList[sender.tag].communityStatus = "1"
            self.tblCommunityRequestList.reloadData()
        }
    }
    
    @objc func btnRejectTap(_ sender: UIButton){
        Utill.showActivityIndicator()
        ApiManager.sharedInstance.request(url: Endpoints.AcceptRejectCommunityRequest, parameter: ["community_id":self.arrCommunityRequestList[sender.tag].communityID ?? "", "request_status": "2"]) { (result: Result<LibraryModel, ErrorType>) in
            Utill.removeActivityIndicator()
            guard (try? result.get()) != nil else { return }
            self.arrCommunityRequestList[sender.tag].communityStatus = "1"
            self.tblCommunityRequestList.reloadData()
        }
    }
    
    @objc func btnAcceptedTap(_ sender: UIButton){
        
    }
}
