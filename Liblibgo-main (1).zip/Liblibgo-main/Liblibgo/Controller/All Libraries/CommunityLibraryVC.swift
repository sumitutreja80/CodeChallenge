//
//  CommunityLibraryVC.swift
//  Liblibgo
//
//  Created by apple on 21/05/22.
//

import UIKit

class CommunityLibraryVC: UIViewController {

    @IBOutlet weak var tblLibraryList: UITableView!
    
    var arrLibraryList: [LibraryList] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.prepareUI()
        self.getLibrary()
    }

    static func instance() -> CommunityLibraryVC{
        return StoryBoards.Main.instantiateViewController(withIdentifier: "CommunityLibraryVC") as! CommunityLibraryVC
    }
    
    fileprivate func prepareUI(){
        self.tblLibraryList.register(UINib.init(nibName: "tblCommunityLibrariesCell", bundle: nil), forCellReuseIdentifier: "tblCommunityLibrariesCell")
        let refreshControl = UIRefreshControl()
        refreshControl.addTarget(self, action: #selector(self.refreshData), for: .valueChanged)
        self.tblLibraryList.refreshControl = refreshControl
        self.tblLibraryList.tableFooterView = UIView()
    }
    
    @objc func refreshData(){
        self.getLibrary()
    }
    
    @IBAction func btnCreate(_ sender: UIButton){
        if AppSettings.currentUser != nil{
            //check status
            Utill.showActivityIndicator()
            ApiManager.sharedInstance.request(url: Endpoints.CheckApartmentLibraryStatus, parameter: ["user_id": AppSettings.currentUser?.userID ?? ""]) { (result: Result<CheckApartmentLibraryStatusModel, ErrorType>) in
                Utill.removeActivityIndicator()
                guard let res = try? result.get() else { return }
                if res.response?.libraryStatus == "yes"{
                    Utill.setTost(title: nil, message: "You have already created your community library. One user can create only one community library.", controller: self, completion: nil)
                }else{
                    let vc = SelectCommunityLibraryVC.instance()
                    vc.hidesBottomBarWhenPushed = true
                    vc.isOwnLibrary = false
                    self.navigationController?.pushViewController(vc, animated: true)
                }
            }
        }else{
            let vc = LoginVC.instance()
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
        }
    }
    
    fileprivate func getLibrary(){
        self.tblLibraryList.refreshControl?.beginRefreshing()
        ApiManager.sharedInstance.request(url: Endpoints.ApartmentLibraryListNearByMe, parameter: ["user_id": AppSettings.currentUser?.userID ?? ""]) { (result: Result<LibraryModel, ErrorType>) in
            self.tblLibraryList.refreshControl?.endRefreshing()
            guard let res = try? result.get() else { return }
            if let libraryList = res.response?.libraryList{
                self.arrLibraryList = libraryList.sorted(by: { obj , _  in
                    return obj.userID == AppSettings.currentUser?.userID
                })
            }
            self.tblLibraryList.reloadData()
        }
    }

}

extension CommunityLibraryVC: UITableViewDelegate, UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.arrLibraryList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "tblCommunityLibrariesCell", for: indexPath) as! tblCommunityLibrariesCell
        cell.btnJoin.tag = indexPath.row
        cell.btnEdit.tag = indexPath.row
        cell.btnManageMember.tag = indexPath.row
        cell.btnJoin.addTarget(self, action: #selector(self.btnJoinTap(_:)), for: .touchUpInside)
        cell.btnEdit.addTarget(self, action: #selector(self.btnEdit(_:)), for: .touchUpInside)
        cell.btnManageMember.addTarget(self, action: #selector(self.btnManageMember(_:)), for: .touchUpInside)
        cell.bindData(self.arrLibraryList[indexPath.row])
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if AppSettings.currentUser != nil{
            if self.arrLibraryList[indexPath.row].userID == AppSettings.currentUser?.userID{
            //go to detail page
            AppSettings.communityId = "0"
            let vc = BookOfLibraryVC.instance()
            vc.name = self.arrLibraryList[indexPath.row].libraryName ?? ""
            vc.libraryId = self.arrLibraryList[indexPath.row].libraryID ?? ""
            self.navigationController?.pushViewController(vc, animated: true)
        }else if self.arrLibraryList[indexPath.row].communityStatus ?? "" == "1"{
            //check status
            Utill.showActivityIndicator()
            ApiManager.sharedInstance.request(url: Endpoints.CheckLibraryCommunityStatus, parameter: ["library_id":self.arrLibraryList[indexPath.row].libraryID ?? "", "user_id": AppSettings.currentUser?.userID ?? ""]) { (result: Result<CheckLibraryStatusModel, ErrorType>) in
                Utill.removeActivityIndicator()
                guard let res = try? result.get() else {
                    Utill.setTost(title: nil, message: "Join fist to see books of this community.", controller: self, completion: nil)
                    return
                }
                if res.response?.message == "data available" && res.response?.status == "1"{
                    //go to detail page
                    AppSettings.communityId = res.response?.communityID ?? ""
                    let vc = BookOfLibraryVC.instance()
                    vc.name = self.arrLibraryList[indexPath.row].libraryName ?? ""
                    vc.libraryId = self.arrLibraryList[indexPath.row].libraryID ?? ""
                    self.navigationController?.pushViewController(vc, animated: true)
                }else if res.response?.status == "0"{
                    //requested message
                    Utill.setTost(title: nil, message: "Your request is pending yet.", controller: self, completion: nil)
                }else{
                    Utill.setTost(title: nil, message: "Join fist to see books of this community.", controller: self, completion: nil)
                }
            }
        }
        }else{
            let vc = LoginVC.instance()
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
        }
    }
    
    @objc func btnJoinTap(_ sender: UIButton){
        if AppSettings.currentUser != nil{
            if self.arrLibraryList[sender.tag].communityStatus ?? "" == ""{
                Utill.showActivityIndicator()
                ApiManager.sharedInstance.request(url: Endpoints.SentCommunityRequest, parameter: ["library_id":self.arrLibraryList[sender.tag].libraryID ?? "", "user_id": AppSettings.currentUser?.userID ?? ""]) { (result: Result<LibraryModel, ErrorType>) in
                    Utill.removeActivityIndicator()
                    guard let res = try? result.get() else { return }
                    if res.response?.message == "Your Request has been send successfully"{
                        self.arrLibraryList[sender.tag].communityStatus = "0"
                        self.tblLibraryList.reloadData()
                    }
                }
            }
        }else{
            let vc = LoginVC.instance()
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
        }
        
    }
    
    @objc func btnEdit(_ sender: UIButton){
        
    }
    
    @objc func btnManageMember(_ sender: UIButton){
        if AppSettings.currentUser != nil{
            let vc = ManageCommunityUsersVC.instance()
            self.navigationController?.pushViewController(vc, animated: true)
        }else{
            let vc = LoginVC.instance()
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
        }
    }
    
}
