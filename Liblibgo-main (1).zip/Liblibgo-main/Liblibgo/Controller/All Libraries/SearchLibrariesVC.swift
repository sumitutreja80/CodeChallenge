//
//  SearchLibrariesVC.swift
//  Liblibgo
//
//  Created by apple on 21/05/22.
//

import UIKit

class SearchLibrariesVC: UIViewController {

    @IBOutlet weak var tblLibraryList: UITableView!
    @IBOutlet weak var txtSearch: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.title = "Search Library"
        //self.txtSearch.delegate = self
        self.prepareUI()
    }

    static func instance() -> SearchLibrariesVC{
        return StoryBoards.Main.instantiateViewController(withIdentifier: "SearchLibrariesVC") as! SearchLibrariesVC
    }

    fileprivate func prepareUI(){
        self.tblLibraryList.register(UINib.init(nibName: "tblIndividualLibraryCell", bundle: nil), forCellReuseIdentifier: "tblIndividualLibraryCell")
        self.tblLibraryList.tableFooterView = UIView()
    }
}

extension SearchLibrariesVC: UITableViewDelegate, UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 10
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "tblIndividualLibraryCell", for: indexPath) as! tblIndividualLibraryCell
        cell.lblTitle.text = "text \n text \n ahsdgh\n sjdfk\n jksdfnk"
        //cell.lblDes.text = "text \n text \n ahsdgh\n sjdfk\n jksdfnk"
        return cell
    }
    
}
