//
//  AllLibrariesVC.swift
//  Liblibgo
//
//  Created by apple on 21/05/22.
//

import UIKit
import Parchment
import SnapKit

class AllLibrariesVC: UIViewController {

    @IBOutlet weak var vwContainer: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.title = "All Libraries"
        //let config = UIImage.SymbolConfiguration(scale: .large)
        //let rightBtn = UIBarButtonItem(image: UIImage(systemName: "magnifyingglass")?.withConfiguration(config), style: .plain, target: self, action: #selector(self.btnSearch(_:)))
        //self.navigationItem.rightBarButtonItem = rightBtn
        self.prepareUI()
    }

    static func instance() -> AllLibrariesVC{
        return StoryBoards.Main.instantiateViewController(withIdentifier: "AllLibrariesVC") as! AllLibrariesVC
    }

    fileprivate func prepareUI(){
        let communityLibraryVC = CommunityLibraryVC.instance()
        communityLibraryVC.title = "Community Librar".uppercased()
        
        //let individualLibraryVC = IndividualLibraryVC.instance()
        //individualLibraryVC.title = "Individual Library".uppercased()
        
        let individualLibraryVC = MyLibraryIndividualVC.instance()
        individualLibraryVC.title = "Individual Library".uppercased()
        
        let pagingViewController = PagingViewController(viewControllers: [
            communityLibraryVC,
            individualLibraryVC,
        ])
        
        pagingViewController.backgroundColor = .AppThemColor
        pagingViewController.textColor = .white
        pagingViewController.selectedTextColor = .black
        pagingViewController.menuBackgroundColor = .AppThemColor
        pagingViewController.selectedBackgroundColor = .white
        pagingViewController.indicatorColor = .clear
        pagingViewController.font = UIFont.systemFont(ofSize: 15.0)
        pagingViewController.selectedFont = UIFont.systemFont(ofSize: 15.0)
        
        addChild(pagingViewController)
        self.vwContainer.addSubview(pagingViewController.view)
        self.vwContainer.constrainToEdges(pagingViewController.view)
        pagingViewController.didMove(toParent: self)
    }
    
    @objc func btnSearch(_ sender: UIBarButtonItem){
        print("Search")
        let vc = SearchLibrariesVC.instance()
        self.navigationController?.pushViewController(vc, animated: true)
    }
}
