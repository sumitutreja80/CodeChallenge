//
//  FilterBooksVC.swift
//  Liblibgo
//
//  Created by apple on 26/06/22.
//

import UIKit

class colItemCell: UICollectionViewCell{
    
    @IBOutlet weak var vwBG: UIView!
    @IBOutlet weak var lblTitle: UILabel!
    
    override func awakeFromNib(){
        super.awakeFromNib()
        vwBG.layer.cornerRadius = 15
    }
}

class FilterBooksVC: UIViewController {

    @IBOutlet weak var colCategory: UICollectionView!
    
    var arrCategory: [CategoryList] = []
    var selectedIds: ((_ ids: String) -> ())?
    var selectedCategories = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.prepareUI()
    }

    static func instance() -> FilterBooksVC{
        return StoryBoards.Main.instantiateViewController(withIdentifier: "FilterBooksVC") as! FilterBooksVC
    }
    
    func prepareUI(){
        if self.selectedCategories != ""{
            let arrStr = self.selectedCategories.components(separatedBy: ",")
            for i in 0..<self.arrCategory.count{
                if arrStr.contains(self.arrCategory[i].categoryID ?? ""){
                    self.arrCategory[i].isSelected = true
                }
            }
            self.colCategory.reloadData()
        }
    }
    
    @IBAction func btnClose(_ sender: UIButton){
        self.dismiss(animated: true, completion: nil)
    }

}

extension FilterBooksVC: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout{

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.arrCategory.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "colItemCell", for: indexPath) as! colItemCell
        cell.lblTitle.text = self.arrCategory[indexPath.row].categoryName
        cell.vwBG.backgroundColor = self.arrCategory[indexPath.row].isSelected ? .AppThemColor : UIColor.systemGray2
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        self.arrCategory[indexPath.row].isSelected = !self.arrCategory[indexPath.row].isSelected
        self.colCategory.reloadData()
        let ids = self.arrCategory.filter({ $0.isSelected == true }).map({ $0.categoryID ?? "" }).joined(separator: ",")
        self.selectedIds?(ids)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: collectionView.frame.width / 3, height: 60.0)
    }

}
