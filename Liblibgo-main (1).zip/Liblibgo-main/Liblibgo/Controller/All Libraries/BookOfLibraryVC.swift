//
//  BookOfLibraryVC.swift
//  Liblibgo
//
//  Created by apple on 27/05/22.
//

import UIKit

class BookOfLibraryVC: UIViewController {

    @IBOutlet weak var tblBookList: UITableView!
    @IBOutlet weak var txtSearch: UITextField!
    @IBOutlet weak var txtIsMyBook: DropDownField!
    @IBOutlet weak var txtSellingType: DropDownField!
    @IBOutlet weak var txtCategories: DropDownField!
    @IBOutlet weak var btnReload: UIButton!
    
    var name = ""
    var libraryId = ""
    var arrMainBookList: [BookList] = []
    var arrBookList: [BookList] = []
    lazy var viewModel : CategoryVM = {
        let viewModel = CategoryVM()
        return viewModel
    }()
    var arrCategory: [CategoryList] = []
    var ids = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.title = "Book of \(name)"
        self.prepareUI()
        self.getBooklist()
    }
    

    static func instance() -> BookOfLibraryVC{
        return StoryBoards.Main.instantiateViewController(withIdentifier: "BookOfLibraryVC") as! BookOfLibraryVC
    }
    
    fileprivate func prepareUI(){
        self.txtSearch.addTarget(self, action: #selector(self.textSearchChange(_:)), for: .editingChanged)
        self.tblBookList.register(UINib.init(nibName: "tblBookOfLibraryListCell", bundle: nil), forCellReuseIdentifier: "tblBookOfLibraryListCell")
        let refreshControl = UIRefreshControl()
        refreshControl.addTarget(self, action: #selector(self.refreshData), for: .valueChanged)
        self.tblBookList.refreshControl = refreshControl
        self.tblBookList.tableFooterView = UIView()
        
        self.txtIsMyBook.lblText.text = "Books4U"
        self.txtIsMyBook.dropDown.dataSource = ["Books4U", "My Books"]
        self.txtIsMyBook.dropDown.selectionAction = { [unowned self] (index: Int, item: String) in
            self.txtIsMyBook.lblText.text = item
            self.getBooklist(categories: self.ids)
        }
        
        self.txtSellingType.lblText.text = "Buy Or Rent"
        self.txtSellingType.dropDown.dataSource = ["For Rent", "For Buy", "Giveaway", "Buy Or Rent"]
        self.txtSellingType.dropDown.selectionAction = { [unowned self] (index: Int, item: String) in
            self.txtSellingType.lblText.text = item
            self.getBooklist(categories: self.ids)
        }
        
        self.txtCategories.lblText.text = "Category"
        self.txtCategories.btnClick.addTarget(self, action: #selector(self.btnCategoryTap), for: .touchUpInside)
        
        self.viewModel.data.addObserver(self) { [weak self] categoryList in
            self?.arrCategory = categoryList
        }
        self.viewModel.fetchCategory()
    }
    
    @objc func refreshData(){
        self.txtSearch.text = nil
        self.getBooklist()
    }
    
    @objc func btnCategoryTap(){
        guard self.arrCategory.count > 0 else { return }
        let vc = FilterBooksVC.instance()
        vc.arrCategory = self.arrCategory
        vc.selectedIds = { ids in
            self.ids = ids
            self.getBooklist(categories: self.ids)
        }
        vc.selectedCategories = self.ids
        self.present(vc, animated: true, completion: nil)
    }
    
    fileprivate func getBooklist(categories: String = ""){
        
        let userId = self.txtIsMyBook.lblText.text == "My Books" ? AppSettings.currentUser?.userID ?? "" : ""
        let giveaway = self.txtSellingType.lblText.text == "Giveaway" ? "yes" : "no"
        let sellingType = self.txtSellingType.lblText.text == "Buy Or Rent" ? "" : self.txtSellingType.lblText.text == "Giveaway" ? "" : self.txtSellingType.lblText.text == "For Buy" ? "For Sale" : self.txtSellingType.lblText.text
        
        self.tblBookList.refreshControl?.beginRefreshing()
        ApiManager.sharedInstance.request(url: Endpoints.BookListByCategoryOrLibrary, parameter: ["user_id": userId, "library_id": self.libraryId, "giveaway": giveaway, "selling_type": sellingType ?? "", "categories": categories, "login_user_id" : AppSettings.currentUser?.userID ?? ""]) { (result: Result<BookListModel, ErrorType>) in
            self.tblBookList.refreshControl?.endRefreshing()
            guard let res = try? result.get() else { return }
            self.arrBookList = res.response?.bookList ?? []
            self.arrMainBookList = res.response?.bookList ?? []
            self.tblBookList.reloadData()
        }
    }
    
    @IBAction func btnCreateTap(_ sender: UIButton){
        let vc = AddNewBookVC.instance()
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func btnReload(_ sender: UIButton){
        self.txtSearch.text = nil
        self.ids = ""
        self.txtIsMyBook.lblText.text = "Books4U"
        self.txtSellingType.lblText.text = "Buy Or Rent"
        self.txtCategories.lblText.text = "Category"
        self.getBooklist()
    }

}

extension BookOfLibraryVC: UITextFieldDelegate{
    
    @objc func textSearchChange(_ sender: UITextField){
        self.searchBook(sender.text == "" ? nil : sender.text)
    }
    
    fileprivate func searchBook(_ text: String? = nil){
        if let text = text{
            self.arrBookList = self.arrMainBookList.filter({ book in
                return (book.bookName?.lowercased().starts(with: text.lowercased()) ?? false) || (book.authorName?.lowercased().starts(with: text.lowercased()) ?? false) || (book.isbnNo?.lowercased().starts(with: text.lowercased()) ?? false)
            })
            self.tblBookList.reloadData()
        }else{
            self.arrBookList = self.arrMainBookList
            self.tblBookList.reloadData()
        }
    }
    
}

extension BookOfLibraryVC: UITableViewDelegate, UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.arrBookList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "tblBookOfLibraryListCell", for: indexPath) as! tblBookOfLibraryListCell
        cell.imgBookImage.sd_setImage(with: URL.init(string: self.arrBookList[indexPath.row].imageURL?.urlQueryEncoded ?? ""), placeholderImage: nil, completed: nil)
        cell.lblTitle.text = self.arrBookList[indexPath.row].bookName
        cell.lblOwnerName.text = "By \(self.arrBookList[indexPath.row].authorName ?? "")"
        cell.lblAddedBy.text = "Added By : \(self.arrBookList[indexPath.row].userName ?? "")"
        if self.arrBookList[indexPath.row].flagStatus ?? 0 == 0{
            cell.lblAvailable.text = "Book is not available yet."
        }else if self.arrBookList[indexPath.row].flagStatus ?? 0 == 1{
            cell.lblAvailable.text = "Book is available for you."
        }else{
            cell.lblAvailable.text = "Someone issued this book."
        }
        cell.btnWhatsApp.tag = indexPath.row
        cell.btnEmail.tag = indexPath.row
        cell.btnWhatsApp.addTarget(self, action: #selector(self.btnWhatsAppTap(_:)), for: .touchUpInside)
        cell.btnEmail.addTarget(self, action: #selector(self.btnEmailTap(_:)), for: .touchUpInside)
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vc = BookDetailsVC.instance()
        vc.objBookDetail = self.arrBookList[indexPath.row]
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @objc func btnWhatsAppTap(_ sender: UIButton){
        
    }
    
    @objc func btnEmailTap(_ sender: UIButton){
        
    }
    
}
