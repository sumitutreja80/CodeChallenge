//
//  CreateVirtuallibraryVC.swift
//  Liblibgo
//
//  Created by apple on 27/05/22.
//

import UIKit
import CoreLocation

class CreateVirtuallibraryVC: UIViewController {

    @IBOutlet weak var imgProfile: UIImageView!
    @IBOutlet weak var txtName: UITextField!
    @IBOutlet weak var txtLibraryName: UITextField!
    @IBOutlet weak var txtEmail: UITextField!
    @IBOutlet weak var txtAddress: UITextField!
    @IBOutlet weak var btnCommunityCustomers: UIButton!
    @IBOutlet weak var btnAllCustomers: UIButton!
    @IBOutlet weak var vwAllowSelfPickup: UIView!
    @IBOutlet weak var vwMobileNumber: UIView!
    @IBOutlet weak var txtMobileNumber: UITextField!
    @IBOutlet weak var lblNote: UILabel!
    @IBOutlet weak var btnCreate: UIButton!
    
    var selectedImgProfile: UIImage? = nil
    var isOwnLibrary = false
    private lazy var imagePicker: ImagePicker = {
        let imagePicker = ImagePicker()
        imagePicker.delegate = self
        return imagePicker
    }()
    var lat: Double = 0.0
    var long: Double = 0.0
    var myLibraryObj: MyLibraryResponse? = nil
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.title = self.myLibraryObj == nil ? self.isOwnLibrary ? "Create Your Own Library" : "Create Community Library" : "Edit Community Library"
        self.btnCreate.setTitle(self.myLibraryObj == nil ? "Create" : "Update", for: .normal)
        self.prepareUI()
    }
    

    static func instance() -> CreateVirtuallibraryVC{
        return StoryBoards.Main.instantiateViewController(withIdentifier: "CreateVirtuallibraryVC") as! CreateVirtuallibraryVC
    }
    
    fileprivate func prepareUI(){
        if self.myLibraryObj == nil{
            if let name = AppSettings.currentUser?.username{
                self.txtName.text = name
            }else if let name = AppSettings.currentUser?.userName{
                self.txtName.text = name
            }
            self.txtEmail.text = AppSettings.currentUser?.email
            self.txtAddress.text = AppSettings.currentUser?.address
            self.txtMobileNumber.text = AppSettings.currentUser?.mobile ?? ""
            self.vwAllowSelfPickup.isHidden = !self.isOwnLibrary
            LocationManager.shared.getLocation(completionHandler: { (location:CLLocation?, error:NSError?) in
                if error != nil {
                    return
                }
                guard let location = location else {
                    return
                }
                self.lat = location.coordinate.latitude
                self.long = location.coordinate.longitude
            })
        }else{
            self.txtName.text = self.myLibraryObj?.name
            self.txtLibraryName.text = self.myLibraryObj?.libraryName
            self.txtEmail.text = self.myLibraryObj?.email
            self.txtAddress.text = self.myLibraryObj?.libraryAddress
            self.vwAllowSelfPickup.isHidden = !self.isOwnLibrary
            self.imgProfile.sd_setImage(with: URL.init(string: self.myLibraryObj?.libraryImage ?? "")) { image, error, imagecatch, url  in
                guard error == nil else { return }
                self.selectedImgProfile = image
            }
        }
    }

    @IBAction func btnChangeProfile(_ sender: UIButton){
        self.showPopUp(message: Messages.OPTION, options: [Messages.BTN_GALLERY, Messages.BTN_CAMERA, Messages.BTN_CANCEL]) { (str) in
            if str == Messages.BTN_GALLERY{
                self.imagePicker.photoGalleryAsscessRequest()
            }else if str == Messages.BTN_CAMERA{
                self.imagePicker.cameraAsscessRequest()
            }
        }
    }
    
    @IBAction func btnSelfPickup(_ sender: UIButton){
        if sender.isSelected{
            sender.isSelected = false
            sender.tintColor = .darkGray
        }else{
            self.btnCommunityCustomers.tintColor = .darkGray
            self.btnAllCustomers.tintColor = .darkGray
            self.btnCommunityCustomers.isSelected = false
            self.btnAllCustomers.isSelected = false
            sender.isSelected = true
            sender.tintColor = UIColor.init(red: 0.0, green: 100/255, blue: 0.0, alpha: 1.0)
        }
        self.vwMobileNumber.isHidden = !(self.btnCommunityCustomers.isSelected || self.btnAllCustomers.isSelected)
        self.lblNote.text = self.btnAllCustomers.isSelected ? "Note : All customers can call." : "Note : Only Community's customers can call."
    }
    
    @IBAction func btnCreateTap(_ sender: UIButton){
        self.view.endEditing(true)
        if self.txtName.text ?? "" == ""{
            Utill.setTost(title: nil, message: "Name can not be blank.", controller: self, completion: nil)
            return
        }
        
        if self.txtLibraryName.text ?? "" == ""{
            Utill.setTost(title: nil, message: "Library name can not be blank.", controller: self, completion: nil)
            return
        }
        
        if self.txtEmail.text ?? "" != ""{
            if !Utill.share.isValidEmail(text: self.txtEmail.text ?? ""){
                Utill.setTost(title: nil, message: "Please enter valid email address.", controller: self, completion: nil)
                return
            }
        }
        
        if self.txtAddress.text ?? "" == ""{
            Utill.setTost(title: nil, message: "Address can not be blank.", controller: self, completion: nil)
            return
        }
        print("All Field Valid")
        if self.myLibraryObj == nil{
            var arrImage = [(String, UIImage)]()
            if selectedImgProfile != nil{
                arrImage = [("image",self.selectedImgProfile!)]
            }
            let selfPickupStatus = self.btnCommunityCustomers.isSelected || self.btnAllCustomers.isSelected
            
            Utill.showActivityIndicator()
            ApiManager.sharedInstance.uploadRequest(url: Endpoints.CreateOwnLibrary, method: .post, parameter: ["user_id": AppSettings.currentUser?.userID ?? "", "address":self.txtAddress.text ?? "", "latitude": "\(self.lat)", "longitude": "\(self.long)", "self_pickup_status":selfPickupStatus ? "1" : "0", "library_name":self.txtLibraryName.text ?? "", "is_own_library": self.isOwnLibrary ? "1" : "0", "allow_contact":self.btnAllCustomers.isSelected ? "1" : "0", "contact_no":self.txtMobileNumber.text ?? ""], arrImage: arrImage, arrVideo: nil, arrAudio: nil) { (result: Result<GeneralResponceModel, Error>) in
                Utill.removeActivityIndicator()
                guard let res = try? result.get() else { return }
                if res.response?.code ?? 0 == 1{
                    for vc in self.navigationController!.viewControllers {
                        if let allLibrariesVC = vc as? AllLibrariesVC
                        {
                            allLibrariesVC.viewDidLoad()
                            self.navigationController?.popToViewController(allLibrariesVC, animated: true)
                        }
                    }
                }else{
                    Utill.setTost(title: nil, message: res.response?.message ?? "", controller: self, completion: nil)
                }
            }
        }else{
            var arrImage = [(String, UIImage)]()
            if selectedImgProfile != nil{
                arrImage = [("library_image",self.selectedImgProfile!)]
            }
            Utill.showActivityIndicator()
            ApiManager.sharedInstance.uploadRequest(url: Endpoints.EditLibraryProfile, method: .post, parameter: ["user_id": AppSettings.currentUser?.userID ?? "", "address": self.txtAddress.text ?? "", "library_name":self.txtLibraryName.text ?? "", "is_own_library": "0"], arrImage: arrImage, arrVideo: nil, arrAudio: nil) { (result: Result<GeneralResponceModel, Error>) in
                Utill.removeActivityIndicator()
                guard let res = try? result.get() else { return }
                if res.response?.code ?? 0 == 1{
                    self.navigationController?.popToRootViewController(animated: true)
                }else{
                    Utill.setTost(title: nil, message: res.response?.message ?? "", controller: self, completion: nil)
                }
            }
        }
    }
}

// MARK: ImagePickerDelegate
extension CreateVirtuallibraryVC: ImagePickerDelegate {

    func imagePicker(_ imagePicker: ImagePicker, didSelect image: UIImage) {
        imagePicker.dismiss()
        self.imgProfile.image = image
        self.selectedImgProfile = image
    }

    func cancelButtonDidClick(on imageView: ImagePicker) { imagePicker.dismiss() }
    func imagePicker(_ imagePicker: ImagePicker, grantedAccess: Bool,
                     to sourceType: UIImagePickerController.SourceType) {
        guard grantedAccess else { return }
        imagePicker.present(parent: self, sourceType: sourceType)
    }
}
