//
//  IndividualLibraryVC.swift
//  Liblibgo
//
//  Created by apple on 21/05/22.
//

import UIKit

class IndividualLibraryVC: UIViewController {

    @IBOutlet weak var tblLibraryList: UITableView!
    
    var arrLibraryList: [LibraryList] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.prepareUI()
        self.getLibrary()
    }

    static func instance() -> IndividualLibraryVC{
        return StoryBoards.Main.instantiateViewController(withIdentifier: "IndividualLibraryVC") as! IndividualLibraryVC
    }
    
    fileprivate func prepareUI(){
        self.tblLibraryList.register(UINib.init(nibName: "tblIndividualLibraryCell", bundle: nil), forCellReuseIdentifier: "tblIndividualLibraryCell")
        let refreshControl = UIRefreshControl()
        refreshControl.addTarget(self, action: #selector(self.refreshData), for: .valueChanged)
        self.tblLibraryList.refreshControl = refreshControl
        self.tblLibraryList.tableFooterView = UIView()
    }
    
    @objc func refreshData(){
        self.getLibrary()
    }
    
    fileprivate func getLibrary(){
        self.tblLibraryList.refreshControl?.beginRefreshing()
        ApiManager.sharedInstance.request(url: Endpoints.LibraryListNearByMe, parameter: [:]) { (result: Result<LibraryModel, ErrorType>) in
            self.tblLibraryList.refreshControl?.endRefreshing()
            guard let res = try? result.get() else { return }
            self.arrLibraryList = res.response?.libraryList ?? []
            self.tblLibraryList.reloadData()
        }
    }
    
    @IBAction func btnCreate(_ sender: UIButton){
        if AppSettings.currentUser != nil{
            let vc = SelectCommunityLibraryVC.instance()
            vc.hidesBottomBarWhenPushed = true
            vc.isOwnLibrary = true
            self.navigationController?.pushViewController(vc, animated: true)
        }else{
            let vc = LoginVC.instance()
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
        }
    }

}

extension IndividualLibraryVC: UITableViewDelegate, UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.arrLibraryList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "tblIndividualLibraryCell", for: indexPath) as! tblIndividualLibraryCell
        cell.imgLibraries.sd_setImage(with: URL.init(string: (self.arrLibraryList[indexPath.row].libraryImage ?? "").urlQueryEncoded ?? ""), placeholderImage: UIImage.init(named: "no_img"), completed: nil)
        cell.lblTitle.text = self.arrLibraryList[indexPath.row].libraryName
        cell.lblDes.text = "Owner, \(self.arrLibraryList[indexPath.row].libraryOwnerName ?? "")"
        cell.vwStar.rating = self.arrLibraryList[indexPath.row].ratings ?? 0.0
        cell.btnCall.isHidden = self.arrLibraryList[indexPath.row].allowContact ?? 0 != 2
        return cell
    }
    
}
