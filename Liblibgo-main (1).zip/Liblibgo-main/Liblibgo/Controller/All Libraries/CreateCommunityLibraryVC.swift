//
//  CreateCommunityLibraryVC.swift
//  Liblibgo
//
//  Created by apple on 22/05/22.
//

import UIKit

class CreateCommunityLibraryVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    static func instance() -> CreateCommunityLibraryVC{
        return StoryBoards.Main.instantiateViewController(withIdentifier: "CreateCommunityLibraryVC") as! CreateCommunityLibraryVC
    }

}
