//
//  OrderHistoryVC.swift
//  Liblibgo
//
//  Created by apple on 10/06/22.
//

import UIKit

class OrderHistoryVC: UIViewController {

    @IBOutlet weak var tblOrderList: UITableView!
    @IBOutlet weak var vwDropDown: DropDownField!
    
    var arrOrderList: [OrderList] = []
    lazy var viewModel : OrderHistoryVM = {
        let viewModel = OrderHistoryVM()
        return viewModel
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.title = "Notification"
        self.prepareUI()
        self.viewModel.data.addAndNotify(observer: self) { [weak self] _ in
            if self?.viewModel.state == .loading || self?.viewModel.state == .initial{
                self?.tblOrderList.refreshControl?.beginRefreshing()
            }else{
                self?.tblOrderList.refreshControl?.endRefreshing()
            }
            self?.tblOrderList.reloadData()
        }
        self.viewModel.fetchOrderHistory(userId: AppSettings.currentUser?.userID ?? "")
    }
    
    static func instance() -> OrderHistoryVC{
        return StoryBoards.MyAccount.instantiateViewController(withIdentifier: "OrderHistoryVC") as! OrderHistoryVC
    }

    fileprivate func prepareUI(){
        self.tblOrderList.register(UINib.init(nibName: "tblOrderHistoryListCell", bundle: nil), forCellReuseIdentifier: "tblOrderHistoryListCell")
        let refreshControl = UIRefreshControl()
        refreshControl.addTarget(self, action: #selector(self.refreshData), for: .valueChanged)
        self.tblOrderList.refreshControl = refreshControl
        self.tblOrderList.tableFooterView = UIView()
        self.vwDropDown.lblText.text = "All Orders"
        self.vwDropDown.dropDown.dataSource = ["Borrowed","Lent","Bought","Sold","All Orders"]
        self.vwDropDown.dropDown.selectionAction = { [unowned self] (index: Int, item: String) in
            self.vwDropDown.lblText.text = item
            if item == "All Orders"{
                self.refreshData()
            }else if item == "Borrowed"{
                self.viewModel.fetchOrderHistory(userId: AppSettings.currentUser?.userID ?? "", filter: "buyer_rent")
            }else if item == "Lent"{
                self.viewModel.fetchOrderHistory(userId: AppSettings.currentUser?.userID ?? "", filter: "seller_rent")
            }else if item == "Bought"{
                self.viewModel.fetchOrderHistory(userId: AppSettings.currentUser?.userID ?? "", filter: "buyer_purchase")
            }else if item == "Sold"{
                self.viewModel.fetchOrderHistory(userId: AppSettings.currentUser?.userID ?? "", filter: "seller_purchase")
            }
        }
    }
    
    @objc func refreshData(){
        self.vwDropDown.lblText.text = "All Orders"
        self.viewModel.fetchOrderHistory(userId: AppSettings.currentUser?.userID ?? "")
    }
}

extension OrderHistoryVC: UITableViewDelegate, UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.viewModel.data.value.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "tblOrderHistoryListCell", for: indexPath) as! tblOrderHistoryListCell
        cell.bindData(self.viewModel.data.value[indexPath.row])
        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vc = OrderDetailVC.instance()
        vc.orderDetail = self.viewModel.data.value[indexPath.row]
        vc.hidesBottomBarWhenPushed = true
        self.navigationController?.pushViewController(vc, animated: true)
    }
}
