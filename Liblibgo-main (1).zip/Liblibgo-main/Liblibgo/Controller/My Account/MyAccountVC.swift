//
//  MyAccountVC.swift
//  Liblibgo
//
//  Created by apple on 21/05/22.
//

import UIKit
import Parchment

class MyAccountVC: UIViewController {

    @IBOutlet weak var vwContainer: UIView!
    @IBOutlet weak var vwLogin: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.prepareUI()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.vwLogin.isHidden = AppSettings.currentUser != nil
    }

    static func instance() -> MyAccountVC{
        return StoryBoards.Main.instantiateViewController(withIdentifier: "MyAccountVC") as! MyAccountVC
    }
    
    fileprivate func prepareUI(){
        let communityLibraryVC = OrderHistoryVC.instance()
        communityLibraryVC.title = "Order History".uppercased()
        
        let individualLibraryVC = TransactionHistoryVC.instance()
        individualLibraryVC.title = "Transaction History".uppercased()
        
        let pagingViewController = PagingViewController(viewControllers: [
            communityLibraryVC,
            individualLibraryVC,
        ])
        
        pagingViewController.backgroundColor = .AppThemColor
        pagingViewController.textColor = .white
        pagingViewController.selectedTextColor = .black
        pagingViewController.menuBackgroundColor = .AppThemColor
        pagingViewController.selectedBackgroundColor = .white
        pagingViewController.indicatorColor = .clear
        pagingViewController.font = UIFont.systemFont(ofSize: 15.0)
        pagingViewController.selectedFont = UIFont.systemFont(ofSize: 15.0)
        
        addChild(pagingViewController)
        self.vwContainer.addSubview(pagingViewController.view)
        self.vwContainer.constrainToEdges(pagingViewController.view)
        pagingViewController.didMove(toParent: self)
    }

    @IBAction func btnLogin(_ sender: UIButton){
        if let topVC = UIApplication.getTopViewController(){
            let vc = LoginVC.instance()
            vc.modalPresentationStyle = .fullScreen
            topVC.present(vc, animated: true, completion: nil)
        }
    }
}
