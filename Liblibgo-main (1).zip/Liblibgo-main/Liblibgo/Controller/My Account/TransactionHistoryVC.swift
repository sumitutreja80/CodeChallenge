//
//  TransactionHistoryVC.swift
//  Liblibgo
//
//  Created by apple on 10/06/22.
//

import UIKit

class TransactionHistoryVC: UIViewController {

    @IBOutlet weak var tblTransactionHistory: UITableView!
    
    lazy var viewModel : TransactionHistoryVM = {
        let viewModel = TransactionHistoryVM()
        return viewModel
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.prepareUI()
        self.viewModel.data.addAndNotify(observer: self) { [weak self] _ in
            if self?.viewModel.state == .loading || self?.viewModel.state == .initial{
                self?.tblTransactionHistory.refreshControl?.beginRefreshing()
            }else{
                self?.tblTransactionHistory.refreshControl?.endRefreshing()
            }
            self?.tblTransactionHistory.reloadData()
        }
        self.viewModel.fetchTransactionHistory(userId: AppSettings.currentUser?.userID ?? "")
    }

    static func instance() -> TransactionHistoryVC{
        return StoryBoards.MyAccount.instantiateViewController(withIdentifier: "TransactionHistoryVC") as! TransactionHistoryVC
    }
    
    fileprivate func prepareUI(){
        self.tblTransactionHistory.register(UINib.init(nibName: "tblTransactionHistoryCell", bundle: nil), forCellReuseIdentifier: "tblTransactionHistoryCell")
        let refreshControl = UIRefreshControl()
        refreshControl.addTarget(self, action: #selector(self.refreshData), for: .valueChanged)
        self.tblTransactionHistory.refreshControl = refreshControl
        self.tblTransactionHistory.tableFooterView = UIView()
    }
    
    @objc func refreshData(){
        self.viewModel.fetchTransactionHistory(userId: AppSettings.currentUser?.userID ?? "")
    }

}

extension TransactionHistoryVC: UITableViewDelegate, UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.viewModel.data.value.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "tblTransactionHistoryCell", for: indexPath) as! tblTransactionHistoryCell
        cell.bindData(self.viewModel.data.value[indexPath.row])
        return cell
    }
}
