//
//  OrderDetailVC.swift
//  Liblibgo
//
//  Created by apple on 16/06/22.
//

import UIKit

class OrderDetailVC: UIViewController {
    
    @IBOutlet weak var lblOrderId: UILabel!
    @IBOutlet weak var lblOrderDate: UILabel!
    @IBOutlet weak var imgBookImage: UIImageView!
    @IBOutlet weak var lblBookName: UILabel!
    @IBOutlet weak var lblAuthorName: UILabel!
    @IBOutlet weak var lblBookPrice: UILabel!
    @IBOutlet weak var lblSecurityDeposit: UILabel!
    @IBOutlet weak var lblTotal: UILabel!
    @IBOutlet weak var lblPaymentStatus: UILabel!
    @IBOutlet weak var lblOnlinePay: UILabel!
    @IBOutlet weak var lblUsedLibCoin: UILabel!
    @IBOutlet weak var lblContactSeller: UILabel!
    @IBOutlet weak var lblOrderStatus: UILabel!

    var orderId = ""
    var orderDetail: OrderList?
    lazy var viewModel : OrderHistoryVM = {
        let viewModel = OrderHistoryVM()
        return viewModel
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.title = "Order Details"
        self.viewModel.data.addAndNotify(observer: self) { [weak self] orderData in
            if self?.viewModel.state == .initial || self?.viewModel.state == .loading{
                Utill.showActivityIndicator()
            }else{
                Utill.removeActivityIndicator()
                if self?.viewModel.state == .data{
                    self?.orderDetail = orderData.first
                    guard let order = self?.orderDetail else { return }
                    self?.prepareUI(order)
                }else{
                    guard let order = self?.orderDetail else { return }
                    self?.prepareUI(order)
                }
            }
        }
        self.viewModel.fetchOrderDetail(userId: AppSettings.currentUser?.userID ?? "", orderId: self.orderId == "" ? orderDetail?.orderID ?? "" : self.orderId)
        self.viewModel.onErrorHandling = { [weak self] error in
            Utill.removeActivityIndicator()
            self?.showAlert(withMessage: error?.localizedDescription, withActions: UIAlertAction(title: "Ok", style: .default) { (_) in })
        }
    }

    static func instance() -> OrderDetailVC{
        return StoryBoards.MyAccount.instantiateViewController(withIdentifier: "OrderDetailVC") as! OrderDetailVC
    }
    
    fileprivate func prepareUI(_ data: OrderList){
        self.lblOrderId.text = "Order Id : \(data.orderID ?? "")"
        self.lblOrderDate.text = Utill.share.getFormatedDate(stringDate: data.orderDate ?? "", format: "dd MMM yyyy", defaultformat: "yyyy-MM-dd HH:mm:ss")
        self.imgBookImage.sd_setImage(with: URL.init(string: data.imageURL ?? ""), completed: nil)
        self.lblBookName.text = data.bookName
        self.lblAuthorName.text = "By, \(data.authorName ?? "")"
        self.lblBookPrice.text = "₹ \(data.bookPrice ?? "0.0")"
        self.lblSecurityDeposit.text = "₹ \(data.securityMoney ?? "0.0")"
        self.lblTotal.text = "₹ \(data.orderAmout ?? "0.0")"
        self.lblPaymentStatus.text = data.paymentStatus ?? "" == "success" ? "Paid" : "Failed"
        self.lblOnlinePay.text = "₹ \(data.bookPrice ?? "0.0")"
        self.lblUsedLibCoin.text = data.libcoins
        self.lblContactSeller.text = data.userName
        if let orderStatus = data.orderStatus{
            self.lblOrderStatus.text = orderStatus == "0" ? "Order Processing" : "Order Complete"
        }
    }

}
