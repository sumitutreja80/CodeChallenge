//
//  HomeVC.swift
//  Liblibgo
//
//  Created by apple on 19/05/22.
//

import UIKit
import SideMenu

class HomeVC: UIViewController{

    @IBOutlet weak var colSlider: UICollectionView!
    @IBOutlet weak var pageControl: UIPageControl!
        
    lazy var viewModel : HomeBannerListViewModel = {
        let viewModel = HomeBannerListViewModel()
        return viewModel
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        Utill.share.registerNotification()
        self.prepareUI()
        self.viewModel.data.addAndNotify(observer: self) { [weak self] _ in
            if self?.viewModel.state == .data || self?.viewModel.state == .error{
                let count = self?.viewModel.data.value.count ?? 0
                if count > 0{
                    self?.startTimer()
                }
                self?.pageControl.numberOfPages = count
                self?.colSlider.reloadData()
            }
        }
        self.viewModel.fetchBannerList()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.navigationController?.setNavigationBarHidden(false, animated: true)
    }
    
    static func instance() -> HomeVC{
        return StoryBoards.Main.instantiateViewController(withIdentifier: "HomeVC") as! HomeVC
    }
    
    func prepareUI(){
        self.colSlider.register(UINib.init(nibName: "colSliderCell", bundle: nil), forCellWithReuseIdentifier: "colSliderCell")
    }
    
    @IBAction func btnMenuTap(_ sender: UIButton){
        let menu = storyboard!.instantiateViewController(withIdentifier: "RightMenu") as! SideMenuNavigationController
        menu.presentationStyle = .menuSlideIn
        menu.menuWidth = self.view.frame.width * 0.8
        menu.hidesBottomBarWhenPushed = true
        menu.dismissOnPush = true
        present(menu, animated: true, completion: nil)
    }
    
    @IBAction func btnNotification(_ sender: UIButton){
        let vc = NotificationVC.instance()
        vc.hidesBottomBarWhenPushed = true
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func btnCreateJoinLibrary(_ sender: UIButton){
        let vc = AllLibrariesVC.instance()
        vc.hidesBottomBarWhenPushed = true
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func btnTrackNow(_ sender: UIButton){
        if AppSettings.currentUser != nil{
            let vc = TrackMyBookVC.instance()
            vc.hidesBottomBarWhenPushed = true
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
    
    @IBAction func txtSearchBook(_ textfield: UITextField){
        textfield.resignFirstResponder()
        let vc = SearchBooksVC.instance()
        vc.hidesBottomBarWhenPushed = true
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    func startTimer() {
        _ =  Timer.scheduledTimer(timeInterval: 2.0, target: self, selector: #selector(self.scrollAutomatically), userInfo: nil, repeats: true)
    }
    
    
    @objc func scrollAutomatically(_ timer1: Timer) {
        if let coll  = self.colSlider {
            for cell in coll.visibleCells {
                let indexPath: IndexPath? = coll.indexPath(for: cell)
                if ((indexPath?.row)! < self.viewModel.data.value.count - 1){
                    let indexPath1: IndexPath?
                    indexPath1 = IndexPath.init(row: (indexPath?.row)! + 1, section: (indexPath?.section)!)
                    coll.scrollToItem(at: indexPath1!, at: .right, animated: true)
                }else{
                    let indexPath1: IndexPath?
                    indexPath1 = IndexPath.init(row: 0, section: (indexPath?.section)!)
                    coll.scrollToItem(at: indexPath1!, at: .left, animated: true)
                }
            }
        }
    }
}

extension HomeVC: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout{
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.viewModel.data.value.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "colSliderCell", for: indexPath) as! colSliderCell
        cell.imgSliderImage.sd_setShowActivityIndicatorView(true)
        cell.imgSliderImage.sd_setIndicatorStyle(.medium)
        let escapedString = self.viewModel.data.value[indexPath.row].banner ?? "".urlQueryEncoded
        cell.imgSliderImage.sd_setImage(with: URL.init(string: escapedString ?? ""), placeholderImage: UIImage(named: "ic_banner_placeholder"), options: .refreshCached, completed: nil)
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return .init(width: collectionView.bounds.size.width, height: collectionView.bounds.size.height)
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let visibleRect = CGRect(origin: self.colSlider.contentOffset, size: self.colSlider.bounds.size)
        let visiblePoint = CGPoint(x: visibleRect.midX, y: visibleRect.midY)
        if let visibleIndexPath = self.colSlider.indexPathForItem(at: visiblePoint) {
            self.pageControl.currentPage = visibleIndexPath.row
        }
    }
    
}
