//
//  SettingVC.swift
//  Liblibgo
//
//  Created by apple on 21/06/22.
//

import UIKit

class SettingVC: UIViewController {

    @IBOutlet weak var switch1: UISwitch!
    @IBOutlet weak var switch2: UISwitch!
    @IBOutlet weak var switch3: UISwitch!
    @IBOutlet weak var switch4: UISwitch!
    @IBOutlet weak var switch5: UISwitch!
    
    lazy var viewModel : SettingVM = {
        let viewModel = SettingVM()
        return viewModel
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.title = "Settings"
        self.prepareUI()
    }
    
    static func instance() -> SettingVC{
        return StoryBoards.Main.instantiateViewController(withIdentifier: "SettingVC") as! SettingVC
    }
    
    fileprivate func prepareUI(){
        Utill.showActivityIndicator()
        self.viewModel.fetchSetting(userId: AppSettings.currentUser?.userID ?? "") { [weak self] response in
            Utill.removeActivityIndicator()
            guard let self = self else { return }
            if response != nil{
                self.switch1.isOn = response?.addBookNotification ?? "0" == "1" ? true : false
                self.switch2.isOn = response?.addBookCommunityNotification ?? "0" == "1" ? true : false
                self.switch3.isOn = response?.notifyNotification ?? "0" == "1" ? true : false
                self.switch4.isOn = response?.demandedBookNofification ?? "0" == "1" ? true : false
            }
        }
    }
    
    fileprivate func updateSetting(type: String){
        self.viewModel.updateSetting(userId: AppSettings.currentUser?.userID ?? "", notificationType: type) { [weak self] response in
            Utill.removeActivityIndicator()
            guard let self = self else { return }
            self.prepareUI()
        }
    }

    @IBAction func btnSwitchTap(_ sender: UISwitch){
        switch sender.tag{
        case 1:
            self.updateSetting(type: "add_book_notification")
            break
        case 2:
            self.updateSetting(type: "add_book_community_notification")
            break
        case 3:
            self.updateSetting(type: "notify_notification")
            break
        case 4:
            break
        case 5:
            self.updateSetting(type: "demanded_book_nofification")
            break
        default:
            break
        }
    }
}
