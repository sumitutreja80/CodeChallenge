//
//  CartVC.swift
//  Liblibgo
//
//  Created by apple on 21/05/22.
//

import UIKit

class CartVC: UIViewController {

    @IBOutlet weak var vwLogin: UIView!
    @IBOutlet weak var tblCartList: UITableView!
    @IBOutlet weak var btnContinue: UIButton!
    
    var arrCartList: [ResponseCartList] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.prepareUI()
    }
        
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.vwLogin.isHidden = AppSettings.currentUser != nil
        if AppSettings.currentUser != nil{
            self.getCartList()
        }
    }

    static func instance() -> CartVC{
        return StoryBoards.Main.instantiateViewController(withIdentifier: "CartVC") as! CartVC
    }
    
    fileprivate func prepareUI(){
        self.tblCartList.register(UINib.init(nibName: "tblCartListCell", bundle: nil), forCellReuseIdentifier: "tblCartListCell")
        let refreshControl = UIRefreshControl()
        refreshControl.addTarget(self, action: #selector(self.refreshData), for: .valueChanged)
        self.tblCartList.refreshControl = refreshControl
        self.tblCartList.tableFooterView = UIView()
    }
    
    @objc func refreshData(){
        self.getCartList()
    }
    
    fileprivate func getCartList(){
        self.tblCartList.refreshControl?.beginRefreshing()
        ApiManager.sharedInstance.request(url: Endpoints.MyCartList, parameter: ["user_id": AppSettings.currentUser?.userID ?? ""]) { (result: Result<CartModel, ErrorType>) in
            self.tblCartList.refreshControl?.endRefreshing()
            guard let res = try? result.get() else { return }
            self.arrCartList = res.response?.cartList ?? []
            var count = 0
            self.arrCartList.forEach { cart in
                count += cart.cartList?.count ?? 0
            }
            AppSettings.cartBadgeCount = count
            self.btnContinue.backgroundColor = self.arrCartList.count > 0 ? UIColor.AppThemColor : UIColor.lightGray
            self.tblCartList.reloadData()
        }
    }
    
    @IBAction func btnLogin(_ sender: UIButton){
        if let topVC = UIApplication.getTopViewController(){
            let vc = LoginVC.instance()
            vc.modalPresentationStyle = .fullScreen
            topVC.present(vc, animated: true, completion: nil)
        }
    }

    @IBAction func btnContinue(_ sender: UIButton){
        if self.arrCartList.count > 0{
            let vc = CheckoutVC.instance()
            vc.hidesBottomBarWhenPushed = true
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
}

extension CartVC: UITableViewDelegate, UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.arrCartList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "tblCartListCell", for: indexPath) as! tblCartListCell
        cell.lblTitle.text = "LibCart \(indexPath.row + 1)"
        cell.lblLibraryName.text = self.arrCartList[indexPath.row].libraryName
        cell.btnDelete.tag = indexPath.row
        cell.btnDelete.addTarget(self, action: #selector(self.btnDeleteTap(_:)), for: .touchUpInside)
        cell.swBookList.removeAllArrangedSubviews()
        self.arrCartList[indexPath.row].cartList?.forEach({ cartList in
            let vw = vwCartLibrary.instanceFromNib() as! vwCartLibrary
            vw.setDetail(obj: cartList)
            vw.controller = self
            cell.swBookList.addArrangedSubview(vw)
        })
        return cell
    }
    
    @objc func btnDeleteTap(_ sender: UIButton){
        self.showAlertYesNo(withMessage: "Do you want to delete this lib cart?", yesButtonText: "Yes", noButtonText: "No", parentController: self, isAnimate: true, handler: { isDelete in
            if isDelete{
                Utill.showActivityIndicator()
                ApiManager.sharedInstance.request(url: Endpoints.RemoveCart, parameter: ["remove_for":"library", "id": self.arrCartList[sender.tag].libraryID ?? ""]) { (result: Result<WishListAddRemoveModel, ErrorType>) in
                    Utill.removeActivityIndicator()
                    guard let res = try? result.get() else { return }
                    if res.response?.message == "Cart removed successfully"{
                        AppSettings.cartBadgeCount = 0
                        self.arrCartList.remove(at: sender.tag)
                        self.tblCartList.reloadData()
                        self.btnContinue.backgroundColor = self.arrCartList.count > 0 ? UIColor.AppThemColor : UIColor.lightGray
                    }
                    Utill.setTost(title: nil, message: res.response?.message ?? "", controller: self, completion: nil)
                }
            }
        })
    }
    
}
