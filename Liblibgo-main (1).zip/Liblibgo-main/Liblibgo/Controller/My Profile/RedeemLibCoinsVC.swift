//
//  RedeemLibCoinsVC.swift
//  Liblibgo
//
//  Created by apple on 02/07/22.
//

import UIKit
import Razorpay

class RedeemLibCoinsVC: UIViewController {
    
    @IBOutlet weak var lblDes: UILabel!
    @IBOutlet weak var txtQuantity: UITextField!
    @IBOutlet weak var btnRedeem: UIButton!
    
    var razorpayObj : RazorpayCheckout? = nil
    var merchantDetails : MerchantsDetails = MerchantsDetails.getDefaultData()
    lazy var redeemLibCoinVM : RedeemLibCoinVM = {
        let viewModel = RedeemLibCoinVM()
        return viewModel
    }()
    var isReload: (() -> Void)?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.view.backgroundColor = UIColor.black.withAlphaComponent(0.3)
        self.prepareUI()
    }
    

    static func instance() -> RedeemLibCoinsVC{
        return StoryBoards.Main.instantiateViewController(withIdentifier: "RedeemLibCoinsVC") as! RedeemLibCoinsVC
    }
    
    fileprivate func prepareUI(){
        self.lblDes.text = "You have \(AppSettings.currentUser?.libcoins ?? "") Lib coins. \n Enter how many lib coins you want to redeem."
        self.txtQuantity.text = AppSettings.currentUser?.libcoins
        self.txtQuantity.layer.borderColor = UIColor.AppThemColor.cgColor
        self.txtQuantity.layer.borderWidth = 1
        self.txtQuantity.layer.cornerRadius = 10
    }
    
    @IBAction func btnBackView(_ sender: UIButton){
        self.dismiss(animated: false, completion: nil)
    }
    
    @IBAction func btnRedeem(_ sender: UIButton){
        let coin = Int(AppSettings.currentUser?.libcoins ?? "0") ?? 0
        let enterCoin = Int(self.txtQuantity.text ?? "0") ?? 0
        if enterCoin > coin{
            Utill.setTost(title: nil, message: "You have only \(AppSettings.currentUser?.libcoins ?? "") Lib coins.", controller: self, completion: nil)
            return
        }else{
            if AppSettings.currentUser?.upiStatus ?? "0" == "0"{
                self.openRazorpayCheckout()
            }else{
                self.createTransaction(txnId: "", redeemLibcoins: self.txtQuantity.text ?? "")
            }
        }
    }
    
    fileprivate func createTransaction(txnId: String, redeemLibcoins: String){
        Utill.showActivityIndicator()
        self.redeemLibCoinVM.postRedeemLibcoinsRequest(userId: AppSettings.currentUser?.userID ?? "", redeemLibcoins: redeemLibcoins, transactionId: txnId) { [weak self] response in
            Utill.removeActivityIndicator()
            guard let self = self else { return }
            self.dismiss(animated: true) {
                self.isReload?()
            }
        }
    }

    private func openRazorpayCheckout() {
        // 1. Initialize razorpay object with provided key. Also depending on your requirement you can assign delegate to self. It can be one of the protocol from RazorpayPaymentCompletionProtocolWithData, RazorpayPaymentCompletionProtocol.
        razorpayObj = RazorpayCheckout.initWithKey(Endpoints.razorpayKey, andDelegate: self)
        let options: [AnyHashable:Any] = [
            "prefill": [
                "contact": "+91\(AppSettings.currentUser?.mobile ?? "1234567890")",
                "email": "liblibgo.dev@gmail.com"
            ],
            "image": merchantDetails.logo,
            "amount" : 100,
            "currency": "INR",
            "name": merchantDetails.name,
            "theme": [
                "color": merchantDetails.color.toHexString()
            ],
            "description": "is a one stop solution for your library management",
            "method": "upi"
            // follow link for more options - https://razorpay.com/docs/payment-gateway/web-integration/standard/checkout-form/
        ]
        if let rzp = self.razorpayObj {
            //rzp.open(options)
            rzp.open(options, displayController: self)
        } else {
            print("Unable to initialize")
        }
    }
}

extension RedeemLibCoinsVC : CustomizeDataDelegate {
    
    func dataChanged(with merchantDetails: MerchantsDetails) {
        self.merchantDetails = merchantDetails
    }
    
}

// RazorpayPaymentCompletionProtocol - This will execute two methods 1.Error and 2. Success case. On payment failure you will get a code and description. In payment success you will get the payment id.
extension RedeemLibCoinsVC : RazorpayPaymentCompletionProtocol {
    
    func onPaymentError(_ code: Int32, description str: String) {
        print("error: ", code, str)
        self.showAlert(withMessage: str, withActions: UIAlertAction(title: "Ok", style: .default) { (_) in
            
        })
    }
    
    func onPaymentSuccess(_ payment_id: String) {
        self.createTransaction(txnId: payment_id, redeemLibcoins: self.txtQuantity.text ?? "")
    }
}

// RazorpayPaymentCompletionProtocolWithData - This will returns you the data in both error and success case. On payment failure you will get a code and description. In payment success you will get the payment id.
extension RedeemLibCoinsVC: RazorpayPaymentCompletionProtocolWithData {
    
    func onPaymentError(_ code: Int32, description str: String, andData response: [AnyHashable : Any]?) {
        print("error: ", code)
        self.showAlert(withMessage: str, withActions: UIAlertAction(title: "Ok", style: .default) { (_) in
            
        })
    }
    
    func onPaymentSuccess(_ payment_id: String, andData response: [AnyHashable : Any]?) {
        print("success: ", payment_id)
        self.createTransaction(txnId: payment_id, redeemLibcoins: self.txtQuantity.text ?? "")
    }
}
