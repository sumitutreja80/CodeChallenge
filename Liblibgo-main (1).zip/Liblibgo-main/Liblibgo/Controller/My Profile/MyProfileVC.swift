//
//  MyProfileVC.swift
//  Liblibgo
//
//  Created by apple on 22/05/22.
//

import UIKit

class MyProfileVC: UIViewController {
    
    @IBOutlet weak var imgProfile: UIImageView!
    @IBOutlet weak var lblLibCoins: UILabel!
    @IBOutlet weak var txtName: UITextField!
    @IBOutlet weak var txtEmail: UITextField!
    @IBOutlet weak var txtPhoneNumber: UITextField!
    @IBOutlet weak var txtPincode: UITextField!
    @IBOutlet weak var txtFlatNoHouseNo: UITextField!
    @IBOutlet weak var txtCommunity: UITextField!
    @IBOutlet weak var txtAreColonyLocality: UITextField!
    @IBOutlet weak var txtTownCity: UITextField!
    @IBOutlet weak var txtState: UITextField!
    @IBOutlet weak var txtLandmark: UITextField!
    @IBOutlet weak var btnRedeem: UIButton!

    private lazy var imagePicker: ImagePicker = {
        let imagePicker = ImagePicker()
        imagePicker.delegate = self
        return imagePicker
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.title = "My Profile"
        self.prepareUI()
        self.getUserDetail(userId: AppSettings.currentUser?.userID ?? "") { _ in self.prepareUI() }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.setNavigationBarHidden(false, animated: true)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }

    static func instance() -> MyProfileVC{
        return StoryBoards.Main.instantiateViewController(withIdentifier: "MyProfileVC") as! MyProfileVC
    }
    
    fileprivate func prepareUI(){
        self.imgProfile.sd_setImage(with: URL.init(string: AppSettings.currentUser?.profileImage ?? ""), placeholderImage: UIImage.init(named: "no_img"), completed: nil)
        self.lblLibCoins.text = "Lib Coins: \(AppSettings.currentUser?.libcoins ?? "0")"
        self.txtName.text = AppSettings.currentUser?.username
        self.txtEmail.text = AppSettings.currentUser?.email
        self.txtPhoneNumber.text = AppSettings.currentUser?.mobile
        self.txtPincode.text = AppSettings.currentUser?.pincode
        self.txtFlatNoHouseNo.text = AppSettings.currentUser?.flatNo
        self.txtCommunity.text = AppSettings.currentUser?.apartmentName
        self.txtAreColonyLocality.text = AppSettings.currentUser?.areaName
        self.txtTownCity.text = AppSettings.currentUser?.city
        self.txtState.text = AppSettings.currentUser?.state
        self.txtLandmark.text = AppSettings.currentUser?.landmark
        if let libCoin = AppSettings.currentUser?.libcoins{
            if libCoin != "" && libCoin != "0"{
                self.btnRedeem.backgroundColor = UIColor.AppThemColor
            }else{
                self.btnRedeem.backgroundColor = UIColor.gray
            }
        }else{
            self.btnRedeem.backgroundColor = UIColor.gray
        }
    }
    
    func getUserDetail(userId: String, complation: @escaping (Bool) -> ()){
        ApiManager.sharedInstance.request(url: Endpoints.GetUserDetails, parameter: ["user_id": userId]) { (result: Result<UserModel, ErrorType>) in
            guard let res = try? result.get() else { return }
            if res.response?.message == "User details available"{
                res.response?.saveToDefault()
                AppSettings.currentUser = res.response
                complation(true)
            }else{
                complation(false)
                //self.showPopUp(message: res.response?.message ?? Messages.SOMETHING_WRONG, options: [Messages.BTN_OK]) { (_) in }
            }
        }
    }
    
    func updateUserDetail(param: [String:Any] = [:], complation: @escaping (Bool) -> ()){
        Utill.showActivityIndicator()
        ApiManager.sharedInstance.request(url: Endpoints.UpdateUserProfile, parameter: param) { (result: Result<GeneralResponceModel, ErrorType>) in
            Utill.removeActivityIndicator()
            guard let res = try? result.get() else { return }
            if res.response?.code ?? 0 == 1{
                complation(true)
                self.showPopUp(message: res.response?.message ?? Messages.SOMETHING_WRONG, options: [Messages.BTN_OK]) { (_) in }
            }else{
                complation(false)
                self.showPopUp(message: res.response?.message ?? Messages.SOMETHING_WRONG, options: [Messages.BTN_OK]) { (_) in }
            }
        }
    }

    @IBAction func btnChangeProfile(_ sender: UIButton){
        self.showPopUp(message: Messages.OPTION, options: [Messages.BTN_GALLERY, Messages.BTN_CAMERA, Messages.BTN_CANCEL]) { (str) in
            if str == Messages.BTN_GALLERY{
                self.imagePicker.photoGalleryAsscessRequest()
            }else if str == Messages.BTN_CAMERA{
                self.imagePicker.cameraAsscessRequest()
            }
        }
    }
    
    @IBAction func btnRedeem(_ sender: UIButton){
        if let libCoin = AppSettings.currentUser?.libcoins{
            if libCoin != "" && libCoin != "0"{
                let vc = RedeemLibCoinsVC.instance()
                vc.modalPresentationStyle = .overFullScreen
                vc.isReload = {
                    self.getUserDetail(userId: AppSettings.currentUser?.userID ?? "") { _ in self.prepareUI() }
                }
                self.present(vc, animated: false, completion: nil)
            }
        }
    }
    
    @IBAction func btnSubmit(_ sender: UIButton){
        self.view.endEditing(true)
        self.updateUserDetail(param: ["user_id": AppSettings.currentUser?.userID ?? "", "name": self.txtName.text ?? "", "email": self.txtEmail.text ?? "", "mobile": self.txtPhoneNumber.text ?? "", "area": self.txtAreColonyLocality.text ?? "", "city": self.txtTownCity.text ?? "", "state": self.txtState.text ?? "", "pincode": self.txtPincode.text ?? "", "landmark": self.txtLandmark.text ?? "", "flat_no": self.txtFlatNoHouseNo.text ?? "", "apartment_name": self.txtCommunity.text ?? ""]) { isUpdate in
            print(isUpdate)
        }
    }
    
    @IBAction func btnDelete(_ sender: UIButton){
        self.view.endEditing(true)
        self.showAlertYesNo(withMessage: Messages.DELETE_ACCOUNT, yesButtonText: "Delete", noButtonText: "No", parentController: self, isAnimate: true, handler: { (isClicked) in
            if isClicked{
                Utill.showActivityIndicator()
                ApiManager.sharedInstance.request(url: Endpoints.DeleteMyAccount, parameter: ["user_id":AppSettings.currentUser?.userID ?? ""]) { (result: Result<GeneralResponceModel, ErrorType>) in
                    Utill.removeActivityIndicator()
                    guard (try? result.get()) != nil else { return }
                    AppSettings.currentUser?.clearFromDefault()
                    AppSettings.currentUser = nil
                    AppDelegate.appDelegate.GoToDashboard()
                }
            }
        })
    }
}

// MARK: ImagePickerDelegate
extension MyProfileVC: ImagePickerDelegate {

    func imagePicker(_ imagePicker: ImagePicker, didSelect image: UIImage) {
        imagePicker.dismiss()
        self.imgProfile.image = image
        Utill.showActivityIndicator()
        ApiManager.sharedInstance.uploadRequest(url: Endpoints.UpdateProfileImage, method: .post, parameter: ["user_id": AppSettings.currentUser?.userID ?? ""], arrImage: [("image",image)], arrVideo: nil, arrAudio: nil) { (result: Result<UserProfileModel, Error>) in
            Utill.removeActivityIndicator()
            guard let res = try? result.get() else { return }
            if res.response?.message == "Profile updated successfully"{
                self.getUserDetail(userId: AppSettings.currentUser?.userID ?? "") { _ in }
            }else{
                self.showPopUp(message: res.response?.message ?? Messages.SOMETHING_WRONG, options: [Messages.BTN_OK]) { (_) in }
            }
        }
    }

    func cancelButtonDidClick(on imageView: ImagePicker) { imagePicker.dismiss() }
    func imagePicker(_ imagePicker: ImagePicker, grantedAccess: Bool,
                     to sourceType: UIImagePickerController.SourceType) {
        guard grantedAccess else { return }
        imagePicker.present(parent: self, sourceType: sourceType)
    }
}
