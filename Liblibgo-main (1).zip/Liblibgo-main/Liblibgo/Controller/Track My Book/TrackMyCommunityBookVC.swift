//
//  TrackMyCommunityBookVC.swift
//  Liblibgo
//
//  Created by apple on 25/06/22.
//

import UIKit

class TrackMyCommunityBookVC: UIViewController {

    @IBOutlet weak var tblBookList: UITableView!
    @IBOutlet weak var txtSearch: UITextField!
    
    lazy var viewModel : TrackMyBookVM = {
        let viewModel = TrackMyBookVM()
        return viewModel
    }()
    var arrMainBookList: [BookList] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.prepareUI()
    }
    

    static func instance() -> TrackMyCommunityBookVC{
        return StoryBoards.TrackMyBooks.instantiateViewController(withIdentifier: "TrackMyCommunityBookVC") as! TrackMyCommunityBookVC
    }
    
    fileprivate func prepareUI(){
        self.txtSearch.addTarget(self, action: #selector(self.textSearchChange(_:)), for: .editingChanged)
        self.tblBookList.register(UINib.init(nibName: "tblTrackMyCommunityBookListCell", bundle: nil), forCellReuseIdentifier: "tblTrackMyCommunityBookListCell")
        let refreshControl = UIRefreshControl()
        refreshControl.addTarget(self, action: #selector(self.refreshData), for: .valueChanged)
        self.tblBookList.refreshControl = refreshControl
        self.tblBookList.tableFooterView = UIView()
        self.viewModel.data.addAndNotify(observer: self) { [weak self] bookList in
            if self?.viewModel.state == .loading || self?.viewModel.state == .initial{
                self?.tblBookList.refreshControl?.beginRefreshing()
            }else{
                self?.arrMainBookList = bookList
                self?.tblBookList.refreshControl?.endRefreshing()
                self?.tblBookList.reloadData()
            }
        }
        self.viewModel.fetchBooksList()
    }

    @objc func refreshData(){
        self.viewModel.fetchBooksList()
    }

}

//MARK: Search Book By Book name
extension TrackMyCommunityBookVC: UITextFieldDelegate{
    
    @objc func textSearchChange(_ sender: UITextField){
        self.searchBook(sender.text == "" ? nil : sender.text)
    }
    
    fileprivate func searchBook(_ text: String? = nil){
        if let text = text{
            self.arrMainBookList = self.viewModel.data.value.filter({ book in
                return (book.bookName?.lowercased().starts(with: text.lowercased()) ?? false) || (book.authorName?.lowercased().starts(with: text.lowercased()) ?? false) || (book.isbnNo?.lowercased().starts(with: text.lowercased()) ?? false)
            })
            self.tblBookList.reloadData()
        }else{
            self.arrMainBookList = self.viewModel.data.value
            self.tblBookList.reloadData()
        }
    }
    
}

extension TrackMyCommunityBookVC: UITableViewDelegate, UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.arrMainBookList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "tblTrackMyCommunityBookListCell", for: indexPath) as! tblTrackMyCommunityBookListCell
        cell.bindData(self.arrMainBookList[indexPath.row])
        cell.switchBook.tag = indexPath.row
        cell.switchBook.addTarget(self, action: #selector(self.switchValueChange(_:)), for: .valueChanged)
        return cell
    }
    
    @objc func switchValueChange(_ sender: UISwitch){
        self.viewModel.changeBookStatus(bookId: self.arrMainBookList[sender.tag].bookID ?? "", status: sender.isOn ? "1" : "0") { response in
            Utill.setTost(title: nil, message: response?.message ?? Messages.SOMETHING_WRONG, controller: self, completion: nil)
            self.arrMainBookList[sender.tag].approvalStatus = sender.isOn ? "1" : "0"
            self.tblBookList.reloadRows(at: [IndexPath.init(row: sender.tag, section: 0)], with: .automatic)
        }
    }
}
