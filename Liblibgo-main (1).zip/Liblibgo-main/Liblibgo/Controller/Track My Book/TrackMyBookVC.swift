//
//  TrackMyBookVC.swift
//  Liblibgo
//
//  Created by apple on 25/06/22.
//

import UIKit
import Parchment

class TrackMyBookVC: UIViewController {

    @IBOutlet weak var vwContainer: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.title = "Track My Books"
        self.prepareUI()
    }

    static func instance() -> TrackMyBookVC{
        return StoryBoards.TrackMyBooks.instantiateViewController(withIdentifier: "TrackMyBookVC") as! TrackMyBookVC
    }
    
    fileprivate func prepareUI(){
        let trackMyCommunityBookVC = TrackMyCommunityBookVC.instance()
        trackMyCommunityBookVC.title = "My community books".uppercased()
        
        let communityLibraryVC = MyLibraryIndividualVC.instance()
        communityLibraryVC.title = "My Individual Books".uppercased()
        
        let pagingViewController = PagingViewController(viewControllers: [
            trackMyCommunityBookVC,
            communityLibraryVC,
        ])
        
        pagingViewController.backgroundColor = .AppThemColor
        pagingViewController.textColor = .white
        pagingViewController.selectedTextColor = .black
        pagingViewController.menuBackgroundColor = .AppThemColor
        pagingViewController.selectedBackgroundColor = .white
        pagingViewController.indicatorColor = .clear
        pagingViewController.font = UIFont.systemFont(ofSize: 15.0)
        pagingViewController.selectedFont = UIFont.systemFont(ofSize: 15.0)
        
        addChild(pagingViewController)
        self.vwContainer.addSubview(pagingViewController.view)
        self.vwContainer.constrainToEdges(pagingViewController.view)
        pagingViewController.didMove(toParent: self)
    }
}
