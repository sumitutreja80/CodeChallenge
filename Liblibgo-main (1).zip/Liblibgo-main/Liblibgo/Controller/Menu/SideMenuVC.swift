//
//  SideMenuVC.swift
//  Liblibgo
//
//  Created by apple on 19/05/22.
//

import UIKit

class tblSideMenuCell: UITableViewCell {
    
    @IBOutlet weak var imgMenuicon: UIImageView!
    @IBOutlet weak var lblMenu: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }
}

class SideMenuVC: UIViewController {
    
    @IBOutlet weak var tblMenuList: UITableView!
    @IBOutlet weak var lblName: UILabel!

    var arrMenuList:[(String, String)] = [("ic_menu_about_us", "About Us"), ("ic_menu_privacy", "Privacy Policy"), ("ic_menu_TC", "Terms & Conditions"), ("ic_menu_contact_us", "Contact Us"), ("ic_menu_power", "Login")]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.lblName.text = "Guest"
        if let name = AppSettings.currentUser?.username{
            self.lblName.text = name
        }else if let name = AppSettings.currentUser?.userName{
            self.lblName.text = name
        }
        if AppSettings.currentUser != nil{
            //, ("", "My Gift Card")
            self.arrMenuList = [("ic_menu_pencil", "Edit Profile"), ("ic_menu_like", "My Favorite Books"), ("ic_menu_about_us", "About Us"), ("ic_menu_privacy", "Privacy Policy"), ("ic_menu_TC", "Terms & Conditions"), ("ic_menu_contact_us", "Contact Us"), ("ic_menu_settings", "Settings"), ("ic_menu_power", "Logout")]
            self.tblMenuList.reloadData()
        }
    }

    static func instance() -> SideMenuVC{
        return UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "SideMenuVC") as! SideMenuVC
    }

}

extension SideMenuVC: UITableViewDelegate, UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.arrMenuList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "tblSideMenuCell", for: indexPath) as! tblSideMenuCell
        cell.lblMenu.text = self.arrMenuList[indexPath.row].1
        cell.imgMenuicon.image = UIImage.init(named: self.arrMenuList[indexPath.row].0)?.withTintColor(UIColor.init(named: "AppThemColor")!)
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        switch self.arrMenuList[indexPath.row].1 {
        case "Edit Profile":
            let vc = MyProfileVC.instance()
            vc.hidesBottomBarWhenPushed = true
            self.navigationController?.pushViewController(vc, animated: true)
            break
        case "My Favorite Books":
            let vc = FavoriteListVC.instance()
            vc.hidesBottomBarWhenPushed = true
            vc.title = "Favorite"
            self.navigationController?.pushViewController(vc, animated: true)
            break
        case "Login":
            //let vc = LoginVC.instance()
            //self.navigationController?.pushViewController(vc, animated: true)
            dismiss(animated: true) {
                if let topVC = UIApplication.getTopViewController(){
                    let vc = LoginVC.instance()
                    vc.modalPresentationStyle = .fullScreen
                    topVC.present(vc, animated: true, completion: nil)
                }
            }
            break
        case "About Us":
            let vc = AboutUsVC.instance()
            vc.hidesBottomBarWhenPushed = true
            vc.title = "About Us"
            vc.type = 1
            self.navigationController?.pushViewController(vc, animated: true)
            break
        case "Privacy Policy":
            let vc = AboutUsVC.instance()
            vc.hidesBottomBarWhenPushed = true
            vc.title = "Privacy Policy"
            vc.type = 2
            self.navigationController?.pushViewController(vc, animated: true)
            break
        case "Terms & Conditions":
            let vc = AboutUsVC.instance()
            vc.hidesBottomBarWhenPushed = true
            vc.title = "Terms & Conditions"
            vc.type = 3
            self.navigationController?.pushViewController(vc, animated: true)
            break
        case "Contact Us":
            let vc = ContactUsVC.instance()
            vc.hidesBottomBarWhenPushed = true
            self.navigationController?.pushViewController(vc, animated: true)
            break
        case "Settings":
            let vc = SettingVC.instance()
            vc.hidesBottomBarWhenPushed = true
            self.navigationController?.pushViewController(vc, animated: true)
            break
        case "Logout":
            self.showAlertYesNo(withMessage: Messages.LOGOUT, yesButtonText: "Logout", noButtonText: "No", parentController: self, isAnimate: true, handler: { (isClicked) in
                if isClicked{
                    AppSettings.currentUser?.clearFromDefault()
                    AppSettings.currentUser = nil
                    AppDelegate.appDelegate.GoToDashboard()
                }
            })
            break
        default:
            break
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 70.0
    }
    
    
}
