//
//  LoginVC.swift
//  Liblibgo
//
//  Created by apple on 19/05/22.
//

import UIKit

class LoginVC: UIViewController, UITextFieldDelegate {
    
    @IBOutlet weak var txtPhoneNumber: FPhoneTextField!
    @IBOutlet weak var txtMobileNumber: UITextField!

    override func viewDidLoad() {
        super.viewDidLoad()

        self.prepareUI()
    }
    
    static func instance() -> LoginVC{
        return StoryBoards.Authentication.instantiateViewController(withIdentifier: "LoginVC") as! LoginVC
    }
    
    fileprivate func prepareUI(){
        self.txtPhoneNumber.setup()
    }
    
    @IBAction func btnSendOTP(_ sender: UIButton){
        self.view.endEditing(true)
        if isValid() {
            Utill.showActivityIndicator()
            ApiManager.sharedInstance.request(url: Endpoints.Login, parameter: ["mobile":self.txtMobileNumber.text ?? ""]) { (result: Result<LoginModel, ErrorType>) in
                Utill.removeActivityIndicator()
                guard let res = try? result.get() else { return }
                if res.response?.message == "OTP has been send successfully"{
                    let vc = OTPVC.instance()
                    vc.loginResponce = res.response
                    vc.mobileNumber = "+91 \(self.txtMobileNumber.text ?? "")"
                    vc.modalPresentationStyle = .fullScreen
                    self.present(vc, animated: true, completion: nil)
                }else{
                    self.showPopUp(message: res.response?.message ?? Messages.SOMETHING_WRONG, options: [Messages.BTN_OK]) { (_) in }
                }
            }
        }else{
            self.showPopUp(message: Messages.PHONE_INVALID, options: [Messages.BTN_OK]) { (_) in }
        }
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        guard CharacterSet(charactersIn: "0123456789").isSuperset(of: CharacterSet(charactersIn: string)) else {
            return false
        }
        return range.location < 10
    }

}

//MARK: - Helper Methods -
extension LoginVC {
    
    private func isValid() -> Bool {
        var isValid = true
        
        if self.txtMobileNumber.text?.count ?? 0 < 10{
            isValid = false
        }
        
        /*///Mobile Number
        if txtPhoneNumber.isEmpty{
            isValid = false
            //txtPhoneNumber.errorMessage = Messages.PHONE_INVALID
        }else{
            if txtPhoneNumber.phoneNumber == nil{
                isValid = false
                //txtPhoneNumber.errorMessage = Messages.PHONE_INVALID
            }
        }*/
        
        return isValid
        
    }
    
    private func getPhoneNumber() -> String {
        return txtPhoneNumber.phoneNumber?.replacingOccurrences(of: " ", with: "") ?? ""
    }
    
    private func getPhoneNumberWithoutCode() -> String {
        return txtPhoneNumber.phoneNumberWithoutCode ?? ""
    }
}
