//
//  ComplateRegistrationVC.swift
//  Liblibgo
//
//  Created by apple on 01/07/22.
//


import UIKit
import CoreLocation

class ComplateRegistrationVC: UIViewController {
    
    @IBOutlet weak var txtName: UITextField!
    @IBOutlet weak var txtPincode: UITextField!
    @IBOutlet weak var txtFlatNoHouseNo: UITextField!
    @IBOutlet weak var txtCommunity: UITextField!
    @IBOutlet weak var txtAreColonyLocality: UITextField!
    @IBOutlet weak var txtTownCity: UITextField!
    @IBOutlet weak var txtState: UITextField!
    @IBOutlet weak var txtLandmark: UITextField!
    @IBOutlet weak var lblTC: UILabel!
    @IBOutlet weak var btnTC: UIButton!
    
    var loginResponce: LoginResponse? = nil
    lazy var complateSignupVM : ComplateSignupVM = {
        let viewModel = ComplateSignupVM()
        return viewModel
    }()
    var locationManager: CLLocationManager!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.title = "Fill Your Details"
        self.prepareUI()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.setNavigationBarHidden(false, animated: true)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }

    static func instance() -> ComplateRegistrationVC{
        return StoryBoards.Authentication.instantiateViewController(withIdentifier: "ComplateRegistrationVC") as! ComplateRegistrationVC
    }
    
    fileprivate func prepareUI(){
        
        self.txtPincode.addTarget(self, action: #selector(self.txtPincodeChange(_:)), for: .editingChanged)
        
        let text = "To proceed, you have to agree with our Terms & Conditions."
        self.lblTC.text = text
        let underlineAttriString = NSMutableAttributedString(string: text)
        let range1 = (text as NSString).range(of: "Terms & Conditions.")
                underlineAttriString.addAttribute(NSAttributedString.Key.underlineStyle, value: NSUnderlineStyle.single.rawValue, range: range1)
        underlineAttriString.addAttribute(NSAttributedString.Key.font, value: UIFont.systemFont(ofSize: 14.0), range: range1)
        underlineAttriString.addAttribute(NSAttributedString.Key.foregroundColor, value: UIColor.AppThemColor, range: range1)
        self.lblTC.attributedText = underlineAttriString
        self.lblTC.isUserInteractionEnabled = true
        self.lblTC.addGestureRecognizer(UITapGestureRecognizer(target:self, action: #selector(self.tapLabel(gesture:))))
        
        locationManager = CLLocationManager()
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.requestAlwaysAuthorization()
        
        if (CLLocationManager.locationServicesEnabled()) {
            locationManager.startUpdatingLocation()
            
            switch locationManager.authorizationStatus {
            case .notDetermined:
                // Request when-in-use authorization initially
                debugPrint("notDetermined")
                break
            case .restricted, .denied:
                // Disable location features
                checkUsersLocationServicesAuthorization()
                break
            case .authorizedWhenInUse, .authorizedAlways:
                // Enable location features
                break
            default:
                debugPrint("default")
            }
        }
    }
    
    func updateUserDetail(param: [String:Any] = [:], complation: @escaping (Bool) -> ()){
        Utill.showActivityIndicator()
        ApiManager.sharedInstance.request(url: Endpoints.UserRegistrationByMobile, parameter: param) { (result: Result<UserModel, ErrorType>) in
            Utill.removeActivityIndicator()
            guard let res = try? result.get() else { return }
            if res.response?.code ?? 0 == 1{
                res.response?.saveToDefault()
                AppSettings.currentUser = res.response
                AppDelegate.appDelegate.GoToDashboard()
                self.view.window?.rootViewController?.dismiss(animated: true, completion: nil)
            }else{
                complation(false)
                self.showPopUp(message: res.response?.message ?? Messages.SOMETHING_WRONG, options: [Messages.BTN_OK]) { (_) in }
            }
        }
    }
    
    @IBAction func tapLabel(gesture: UITapGestureRecognizer) {
        //let termsRange = (self.lblTC.text! as NSString).range(of: "Terms & Condition.".localiz())
        let string  = self.lblTC.text!
        let range = (string as NSString).range(of: "Terms & Conditions.", options: .caseInsensitive)
        if gesture.didTapAttributedTextInLabel(label: self.lblTC, inRange: range) {
            if let url = URL.init(string: Endpoints.tcURL){
                UIApplication.shared.open(url)
            }
        }
    }
    
    @IBAction func btnTC(_ sender: UIButton) {
        sender.isSelected = !sender.isSelected
    }
    
    @IBAction func btnSubmit(_ sender: UIButton){
        self.view.endEditing(true)
        if checkValidation(){
            self.updateUserDetail(param: ["name": self.txtName.text ?? "", "mobile": self.loginResponce?.mobile ?? "", "area": self.txtAreColonyLocality.text ?? "", "city": self.txtTownCity.text ?? "", "state": self.txtState.text ?? "", "pincode": self.txtPincode.text ?? "", "landmark": self.txtLandmark.text ?? "", "flat_no": self.txtFlatNoHouseNo.text ?? "", "apartment": self.txtCommunity.text ?? ""]) { isUpdate in
                print(isUpdate)
            }
        }
    }
    
    fileprivate func checkValidation() -> Bool{
        
        var status = true
        
        if self.txtName.isEmpty() {
            self.txtName.superview?.layer.borderColor = UIColor.red.cgColor
            status =  false
        }
        
        if self.txtPincode.isEmpty() {
            self.txtPincode.superview?.layer.borderColor = UIColor.red.cgColor
            status =  false
        }
        
        if self.txtAreColonyLocality.isEmpty() {
            self.txtAreColonyLocality.superview?.layer.borderColor = UIColor.red.cgColor
            status =  false
        }
        
        if self.txtTownCity.isEmpty() {
            self.txtTownCity.superview?.layer.borderColor = UIColor.red.cgColor
            status =  false
        }
        
        if self.txtState.isEmpty() {
            self.txtState.superview?.layer.borderColor = UIColor.red.cgColor
            status =  false
        }
        
        if !self.btnTC.isSelected && status == true{
            Utill.setTost(title: nil, message: "Please accept our team and condition to continue.", controller: self, completion: nil)
            return false
        }
        
        return status
    }
    
    @objc func txtPincodeChange(_ sender: UITextField){
        guard sender.text?.count ?? 0 > 5 else { return }
        self.complateSignupVM.getLocation(pincode: sender.text ?? "") { [weak self] response in
            guard let self = self else { return }
            DispatchQueue.main.async {
                if let data = response?.postOffice?.first{
                    self.txtState.text = data.state
                    self.txtAreColonyLocality.text = data.taluk
                    self.txtTownCity.text = data.district
                }else{
                    self.txtState.text = nil
                    self.txtAreColonyLocality.text = nil
                    self.txtTownCity.text = nil
                }
            }
        }
    }
}

//MARK: TextField Delegate
extension ComplateRegistrationVC: UITextFieldDelegate{
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        if textField == self.txtName{
            self.txtName.superview?.layer.borderColor = UIColor.AppThemColor.cgColor
        }else if textField == self.txtPincode{
            self.txtPincode.superview?.layer.borderColor = UIColor.AppThemColor.cgColor
        }else if textField == self.txtAreColonyLocality{
            self.txtAreColonyLocality.superview?.layer.borderColor = UIColor.AppThemColor.cgColor
        }else if textField == self.txtTownCity{
            self.txtTownCity.superview?.layer.borderColor = UIColor.AppThemColor.cgColor
        }else if textField == self.txtState{
            self.txtState.superview?.layer.borderColor = UIColor.AppThemColor.cgColor
        }
    }
}

//MARK: Location Manager
extension ComplateRegistrationVC : CLLocationManagerDelegate {
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        let location = locations.last! as CLLocation
        self.locationManager.stopUpdatingLocation()
        CLGeocoder().reverseGeocodeLocation(location) {(placemarks, error) -> Void in
            guard error == nil else {
                debugPrint("Reverse geocoder failed with error \(error?.localizedDescription ?? "")")
                return
            }
            guard let placemarks = placemarks else {
                debugPrint("Problem with the data received from geocoder")
                return
            }
            if placemarks.count > 1 {
                let placemark = placemarks[1]
                self.txtTownCity.text = placemark.subAdministrativeArea
                self.txtState.text = placemark.administrativeArea
                self.txtPincode.text = placemarks[0].postalCode
                self.txtCommunity.text = placemark.thoroughfare
                self.txtAreColonyLocality.text = placemark.locality
            }else if placemarks.count > 0 {
                let placemark = placemarks[0]
                self.txtTownCity.text = placemark.subAdministrativeArea
                self.txtState.text = placemark.administrativeArea
                self.txtPincode.text = placemark.postalCode
                self.txtCommunity.text = placemark.thoroughfare
                self.txtAreColonyLocality.text = placemark.locality
            }
            else{
                print("Problem with the data received from geocoder")
            }
        }
    }
    
    func checkUsersLocationServicesAuthorization() {
        let alert = UIAlertController(title: "Allow Location Access", message: "Your current location will be used to find address.\nTurn on Location Services in your device settings.", preferredStyle: UIAlertController.Style.alert)
        
        // Button to Open Settings
        alert.addAction(UIAlertAction(title: "Settings", style: UIAlertAction.Style.default, handler: { action in
            guard let settingsUrl = URL(string: UIApplication.openSettingsURLString) else {
                return
            }
            if UIApplication.shared.canOpenURL(settingsUrl) {
                UIApplication.shared.open(settingsUrl, completionHandler: { (success) in
                    debugPrint("Settings opened: \(success)")
                })
            }
        }))
        alert.addAction(UIAlertAction(title: "Cancel", style: UIAlertAction.Style.cancel, handler: {(action:UIAlertAction!) in
           
        }))
        self.present(alert, animated: true, completion: nil)
        
    }
}
