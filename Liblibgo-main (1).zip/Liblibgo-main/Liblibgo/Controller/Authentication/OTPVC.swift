//
//  OTPVC.swift
//  Liblibgo
//
//  Created by apple on 21/05/22.
//

import UIKit
import FirebaseMessaging

class OTPVC: UIViewController {

    // MARK: Properties
    @IBOutlet weak var otpTextField: AEOTPTextField!
    @IBOutlet private weak var lblPhoneNumber: UILabel!
    
    var loginResponce: LoginResponse? = nil
    var mobileNumber        : String    = ""
    var countryCode         : String    = ""
    private var enteredOtp  : String    = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.prepareOTPView()
        self.getFCMToken()
    }
    
    static func instance() -> OTPVC{
        return StoryBoards.Authentication.instantiateViewController(withIdentifier: "OTPVC") as! OTPVC
    }

    fileprivate func prepareOTPView() {
        self.lblPhoneNumber.text = mobileNumber
        otpTextField.otpDelegate = self
        otpTextField.otpFontSize = 16
        otpTextField.otpBackgroundColor = .white
        otpTextField.otpFilledBackgroundColor = .white
        otpTextField.otpDefaultBorderWidth = 1
        otpTextField.otpFilledBorderWidth = 1
        otpTextField.otpDefaultBorderColor = UIColor.darkGray
        otpTextField.otpFilledBorderColor = UIColor.darkGray
        otpTextField.otpTextColor = .black
        otpTextField.configure(with: 4)
    }
    
    fileprivate func getFCMToken(){
        if AppDelegate.appDelegate.pushDeviceToken == "iosTest" || AppDelegate.appDelegate.pushDeviceToken == ""{
            Messaging.messaging().token { token, error in
                if let error = error {
                    print("Error fetching FCM registration token: \(error)")
                } else if let token = token {
                    print("FCM registration token: \(token)")
                    AppDelegate.appDelegate.pushDeviceToken = token
                }
            }
        }
    }
    
    @IBAction func btnVerify(_ sender: UIButton){
        self.view.endEditing(true)
        self.verifyOTP(param: ["mobile": self.loginResponce?.mobile ?? "", "otp": self.enteredOtp, "device_id": AppDelegate.appDelegate.pushDeviceToken])
    }
    
    @IBAction func btnResend(_ sender: UIButton){
        Utill.showActivityIndicator()
        ApiManager.sharedInstance.request(url: Endpoints.reSendOTP, parameter: ["mobile":self.loginResponce?.mobile ?? ""]) { (result: Result<GeneralResponceModel, ErrorType>) in
            Utill.removeActivityIndicator()
            guard let res = try? result.get() else { return }
            self.showPopUp(message: res.response?.message ?? Messages.SOMETHING_WRONG, options: [Messages.BTN_OK]) { (_) in }
        }
    }
    
    @IBAction func btnChangeNumber(_ sender: UIButton){
        self.dismiss(animated: true, completion: nil)
    }
    
    fileprivate func verifyOTP(param: [String:String]){
        Utill.showActivityIndicator()
        ApiManager.sharedInstance.request(url: Endpoints.verifyOtp, parameter: param) { (result: Result<UserModel, ErrorType>) in
            Utill.removeActivityIndicator()
            guard let res = try? result.get() else { return }
            if res.response?.code ?? 0 == 1{
                if res.response?.apartmentStatus ?? 0 == 1{
                    res.response?.saveToDefault()
                    AppSettings.currentUser = res.response
                    AppDelegate.appDelegate.GoToDashboard()
                    self.view.window?.rootViewController?.dismiss(animated: true, completion: nil)
                }else{
                    let vc = ComplateRegistrationVC.instance()
                    vc.loginResponce = self.loginResponce
                    vc.modalPresentationStyle = .fullScreen
                    self.present(vc, animated: true, completion: nil)
                }
            }else{
                self.showPopUp(message: res.response?.message ?? Messages.SOMETHING_WRONG, options: [Messages.BTN_OK]) { (_) in }
            }
        }
    }
}

// MARK: - AEOTPTextField Delegate
extension OTPVC: AEOTPTextFieldDelegate {
    func didUserFinishEnter(the code: String) {
        self.enteredOtp = code
        self.view.endEditing(true)
        self.verifyOTP(param: ["mobile":self.loginResponce?.mobile ?? "", "otp":self.enteredOtp, "device_id": AppDelegate.appDelegate.pushDeviceToken])
    }
}
