//
//  ContactUsVC.swift
//  Liblibgo
//
//  Created by apple on 22/05/22.
//

import UIKit

class ContactUsVC: UIViewController {
    
    @IBOutlet weak var txtEmail: UITextField!

    override func viewDidLoad() {
        super.viewDidLoad()

        self.title = "Contact Us"
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.setNavigationBarHidden(false, animated: true)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }

    static func instance() -> ContactUsVC{
        return StoryBoards.Main.instantiateViewController(withIdentifier: "ContactUsVC") as! ContactUsVC
    }

    @IBAction func btnSend(_ sender: UIButton){
        
    }
}
