//
//  AboutUsVC.swift
//  Liblibgo
//
//  Created by apple on 22/05/22.
//

import UIKit
import WebKit

class AboutUsVC: UIViewController {
    
    @IBOutlet weak var webView: WKWebView!

    var type = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.prepareUI()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.setNavigationBarHidden(false, animated: true)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }

    static func instance() -> AboutUsVC{
        return StoryBoards.Main.instantiateViewController(withIdentifier: "AboutUsVC") as! AboutUsVC
    }
    
    func prepareUI(){
        if type == 1{
            let link = URL(string: Endpoints.aboutUs)!
            let request = URLRequest(url: link)
            webView.load(request)
        }else if type == 2{
            let link = URL(string: Endpoints.privacyURL)!
            let request = URLRequest(url: link)
            webView.load(request)
        }else if type == 3{
            let link = URL(string: Endpoints.tcURL)!
            let request = URLRequest(url: link)
            webView.load(request)
        }
    }

}
