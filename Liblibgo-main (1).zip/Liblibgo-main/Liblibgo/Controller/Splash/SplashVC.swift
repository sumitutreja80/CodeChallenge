//
//  SplashVC.swift
//  Liblibgo
//
//  Created by apple on 21/05/22.
//

import UIKit

class SplashVC: UIViewController {
    
    @IBOutlet weak var imgGif: UIImageView!

    override func viewDidLoad() {
        super.viewDidLoad()

        self.prepareUI()
    }

    static func instance() -> SplashVC{
        return StoryBoards.Splace.instantiateViewController(withIdentifier: "SplashVC") as! SplashVC
    }
    
    fileprivate func prepareUI(){
        let imageData = try? Data(contentsOf: Bundle.main.url(forResource: "splash", withExtension: "gif")!)
        self.imgGif.image = UIImage.gifImageWithData(imageData!)
        
        if let u = User.loadFromDefault(){
            AppSettings.currentUser = u
        }else{
            AppSettings.currentUser = nil
        }
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
            let vc = StoryBoards.Main.instantiateInitialViewController()
            UIApplication.shared.keyWindow?.rootViewController = vc
            UIApplication.shared.keyWindow?.makeKeyAndVisible()
        }
    }

}
