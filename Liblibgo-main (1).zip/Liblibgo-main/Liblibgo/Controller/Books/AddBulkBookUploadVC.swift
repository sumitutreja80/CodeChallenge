//
//  AddBulkBookUploadVC.swift
//  Liblibgo
//
//  Created by apple on 28/06/22.
//

import UIKit

class AddBulkBookUploadVC: UIViewController {

    var arrCategory: [CategoryList] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.title = "Bulk Book Upload"
    }
    

    static func instance() -> AddBulkBookUploadVC{
        return StoryBoards.Books.instantiateViewController(withIdentifier: "AddBulkBookUploadVC") as! AddBulkBookUploadVC
    }
    
    @IBAction func btnUploadStack(_ sender: UIButton){
        let vc = UploadStackOfBookVC.instance()
        vc.arrCategory = self.arrCategory
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func btnDownloadFile(_ sender: UIButton){
        self.showPopUp(message: "We are working on it.", options: [Messages.BTN_OK]) { (_) in }
    }
    
    @IBAction func btnUploadFile(_ sender: UIButton){
        self.showPopUp(message: "We are working on it.", options: [Messages.BTN_OK]) { (_) in }
    }

}
