//
//  AddNewBookVC.swift
//  Liblibgo
//
//  Created by apple on 19/06/22.
//

import UIKit
import BarcodeScanner

class AddNewBookVC: UIViewController {
    
    @IBOutlet weak var lblIsbnNo: UILabel!
    @IBOutlet weak var txtIsbnNo: UITextField!
    @IBOutlet weak var txtBookName: UITextField!
    @IBOutlet weak var txtAuthorName: UITextField!
    @IBOutlet weak var txtDescription: UITextField!
    @IBOutlet weak var txtCategory: DropDownField!
    @IBOutlet weak var btnGiveaway: UIButton!
    @IBOutlet weak var vwSaleType: UIView!
    @IBOutlet weak var txtSaleType: DropDownField!
    @IBOutlet weak var vwBookQuantity: UIView!
    @IBOutlet weak var txtBookQuantity: UITextField!
    @IBOutlet weak var vwBookCondition: UIView!
    @IBOutlet weak var txtBookCondition: DropDownField!
    @IBOutlet weak var vwApproxMRP: UIView!
    @IBOutlet weak var txtApproxMRP: UITextField!
    @IBOutlet weak var vwBooksSecurityPrice: UIView!
    @IBOutlet weak var txtBooksSecurityPrice: UITextField!
    @IBOutlet weak var vwRecommendedSalePrice: UIView!
    @IBOutlet weak var txtRecommendedSalePrice: UITextField!
    @IBOutlet weak var vwRecommendedRentDayPrice: UIView!
    @IBOutlet weak var txtRecommendedRentDayPrice: UITextField!
    @IBOutlet weak var vwRentDurationNoOfDays: UIView!
    @IBOutlet weak var txtRentDurationNoOfDays: UITextField!
    @IBOutlet weak var imgImage: UIImageView!
    @IBOutlet weak var lblOR: UILabel!
    @IBOutlet weak var lblORCenter: NSLayoutConstraint!
    
    lazy var viewModel : CategoryVM = {
        let viewModel = CategoryVM()
        return viewModel
    }()
    lazy var bookViewModel : UploadBookVM = {
        let viewModel = UploadBookVM()
        return viewModel
    }()
    
    private lazy var imagePicker: ImagePicker = {
        let imagePicker = ImagePicker()
        imagePicker.delegate = self
        return imagePicker
    }()
    var selectedImgProfile: UIImage? = nil
    var imageUrl = ""
    private func makeBarcodeScannerViewController() -> BarcodeScannerViewController {
        let viewController = BarcodeScannerViewController()
        viewController.headerViewController.titleLabel.text = "Scan barcode"
        viewController.headerViewController.closeButton.tintColor = .white
        viewController.headerViewController.titleLabel.textColor = .white
        viewController.codeDelegate = self
        viewController.errorDelegate = self
        viewController.dismissalDelegate = self
        return viewController
    }
    var arrCategory: [CategoryList] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.title = "Upload Book Details"
        self.prepareUI()
        self.viewEnableDisable(sale: true)
    }

    static func instance() -> AddNewBookVC{
        return StoryBoards.Books.instantiateViewController(withIdentifier: "AddNewBookVC") as! AddNewBookVC
    }
    
    fileprivate func prepareUI(){
        
        self.txtApproxMRP.addTarget(self, action: #selector(self.checkBookConditionPer(_:)), for: .editingChanged)
        
        self.txtCategory.lblText.text = "Select Category"
        var arrStr:[String] = ["Select Category"]
        self.viewModel.data.addObserver(self) { [weak self] (list) in
            self?.arrCategory = list
            arrStr.append(contentsOf: list.map({ $0.categoryName ?? "" }))
            self?.txtCategory.dropDown.dataSource = arrStr
            self?.txtCategory.dropDown.selectionAction = { [unowned self] (index: Int, item: String) in
                self?.txtCategory.lblText.text = item
                if item != "Select Category"{
                    if let item = list.first(where: { $0.categoryName == item }){
                        self?.txtCategory.accessibilityIdentifier = item.categoryID ?? nil
                    }else{
                        self?.txtCategory.accessibilityIdentifier = nil
                    }
                }else{
                    self?.txtCategory.accessibilityIdentifier = nil
                }
            }
        }
        
        self.txtSaleType.lblText.text = "For Sale"
        self.txtSaleType.accessibilityIdentifier = "For Sale"
        self.txtSaleType.dropDown.dataSource = ["For Sale", "For Rent", "Sale or Rent"]
        self.txtSaleType.dropDown.selectionAction = { [unowned self] (index: Int, item: String) in
            self.txtSaleType.lblText.text = item
            if item != "Sale or Rent"{
                if item == "For Sale"{
                    self.viewEnableDisable(giveaway: false, sale: true, rent: false)
                    self.txtSaleType.accessibilityIdentifier = "For Sale"
                }else{
                    self.txtRentDurationNoOfDays.text = "30"
                    self.txtSaleType.accessibilityIdentifier = "For Rent"
                    self.viewEnableDisable(giveaway: false, sale: false, rent: true)
                }
            }else{
                self.txtSaleType.accessibilityIdentifier = "Both"
                self.viewEnableDisable()
            }
            
            if self.txtApproxMRP.text?.isEmpty ?? true == false{
                self.checkBookConditionPer(self.txtApproxMRP)
            }
        }
        
        self.txtBookCondition.lblText.text = "As good as new"
        self.txtBookCondition.accessibilityIdentifier = "As good as new"
        self.txtBookCondition.dropDown.dataSource = ["As good as new", "Marked texts", "Torn or pale pages", "Marked texts & Torn cover page"]
        self.txtBookCondition.dropDown.selectionAction = { [unowned self] (index: Int, item: String) in
            self.txtBookCondition.lblText.text = item
            self.txtBookCondition.accessibilityIdentifier = item
            if self.txtApproxMRP.text?.isEmpty ?? true == false{
                self.checkBookConditionPer(self.txtApproxMRP)
            }
        }
        
        let backButton = UIButton(frame: CGRect(x: 0, y: 0, width: 100, height: 40))
        backButton.setTitle("Bulk Upload", for: .normal)
        backButton.titleLabel?.font = UIFont.systemFont(ofSize: 13.0)
        backButton.setTitleColor(.AppThemColor, for: .normal)
        backButton.backgroundColor = .white
        backButton.layer.cornerRadius = 8
        backButton.addTarget(self, action: #selector(self.btnBulkUpload), for: .touchUpInside)
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(customView: backButton)
    }

    fileprivate func viewEnableDisable(giveaway: Bool = false, sale: Bool = false, rent: Bool = false) {
        self.vwSaleType.isUserInteractionEnabled = !giveaway
        self.vwSaleType.alpha = giveaway ? 0.5 : 1.0
        self.txtSaleType.superview?.layer.borderColor = UIColor.AppThemColor.cgColor
        
        self.vwBookQuantity.isUserInteractionEnabled = !giveaway
        self.vwBookQuantity.alpha = giveaway ? 0.5 : 1.0
        self.txtBookQuantity.superview?.layer.borderColor = UIColor.AppThemColor.cgColor
        self.txtBookQuantity.text = "1"
        
        self.vwBookCondition.isUserInteractionEnabled = !giveaway
        self.vwBookCondition.alpha = giveaway ? 0.5 : 1.0
        self.txtBookCondition.superview?.layer.borderColor = UIColor.AppThemColor.cgColor
        self.txtBookCondition.lblText.text = "As good as new"
        self.txtBookCondition.accessibilityIdentifier = "As good as new"
        
        self.vwApproxMRP.isUserInteractionEnabled = !giveaway
        self.vwApproxMRP.alpha = giveaway ? 0.5 : 1.0
        self.txtApproxMRP.superview?.layer.borderColor = UIColor.AppThemColor.cgColor
        self.txtApproxMRP.text = giveaway ? "0" : nil
        
        self.vwBooksSecurityPrice.isUserInteractionEnabled = !giveaway
        self.vwBooksSecurityPrice.alpha = giveaway ? 0.5 : 1.0
        self.txtBooksSecurityPrice.superview?.layer.borderColor = UIColor.AppThemColor.cgColor
        self.txtBooksSecurityPrice.text = giveaway ? "0" : nil
        
        self.vwRecommendedSalePrice.isUserInteractionEnabled = !giveaway
        self.vwRecommendedSalePrice.alpha = giveaway ? 0.5 : 1.0
        self.txtRecommendedSalePrice.superview?.layer.borderColor = UIColor.AppThemColor.cgColor
        self.txtRecommendedSalePrice.text = giveaway ? "0" : nil
        
        self.vwRecommendedRentDayPrice.isUserInteractionEnabled = !giveaway
        self.vwRecommendedRentDayPrice.alpha = giveaway ? 0.5 : 1.0
        self.txtRecommendedRentDayPrice.superview?.layer.borderColor = UIColor.AppThemColor.cgColor
        self.txtRecommendedRentDayPrice.text = giveaway ? "0" : nil
        
        self.vwRentDurationNoOfDays.isUserInteractionEnabled = !giveaway
        self.vwRentDurationNoOfDays.alpha = giveaway ? 0.5 : 1.0
        self.txtRentDurationNoOfDays.superview?.layer.borderColor = UIColor.AppThemColor.cgColor
        self.txtRentDurationNoOfDays.text = giveaway ? "0" : nil
        
        if rent{
            self.vwRecommendedSalePrice.isUserInteractionEnabled = false
            self.vwRecommendedSalePrice.alpha = 0.5
            self.txtRecommendedSalePrice.superview?.layer.borderColor = UIColor.AppThemColor.cgColor
            self.txtRecommendedSalePrice.text = "0"
            
        }else if sale{
            self.vwBooksSecurityPrice.isUserInteractionEnabled = false
            self.vwBooksSecurityPrice.alpha = 0.5
            self.txtBooksSecurityPrice.superview?.layer.borderColor = UIColor.AppThemColor.cgColor
            self.txtBooksSecurityPrice.text = "0"
            
            self.vwRecommendedRentDayPrice.isUserInteractionEnabled = false
            self.vwRecommendedRentDayPrice.alpha = 0.5
            self.txtRecommendedRentDayPrice.superview?.layer.borderColor = UIColor.AppThemColor.cgColor
            self.txtRecommendedRentDayPrice.text = "0"
            
            self.vwRentDurationNoOfDays.isUserInteractionEnabled = false
            self.vwRentDurationNoOfDays.alpha = 0.5
            self.txtRentDurationNoOfDays.superview?.layer.borderColor = UIColor.AppThemColor.cgColor
            self.txtRentDurationNoOfDays.text = "0"
        }
    }
    
    @objc func btnBulkUpload(){
        if self.arrCategory.count > 0{
            let vc = AddBulkBookUploadVC.instance()
            vc.arrCategory = self.arrCategory
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
    
    @IBAction func btnScan(_ sender: UIButton){
        self.view.endEditing(true)
        let viewController = makeBarcodeScannerViewController()
        viewController.title = "Scan barcode"
        present(viewController, animated: true, completion: nil)
    }
    
    @IBAction func GiveawayTap(_ sender: UIButton){
        self.view.endEditing(true)
        sender.isSelected = !sender.isSelected
        self.viewEnableDisable(giveaway: self.btnGiveaway.isSelected)
    }
    
    @IBAction func btnUploadImage(_ sender: UIButton){
        self.view.endEditing(true)
        self.showPopUp(message: Messages.OPTION, options: [Messages.BTN_GALLERY, Messages.BTN_CAMERA, Messages.BTN_CANCEL]) { (str) in
            if str == Messages.BTN_GALLERY{
                self.imagePicker.photoGalleryAsscessRequest()
            }else if str == Messages.BTN_CAMERA{
                self.imagePicker.cameraAsscessRequest()
            }
        }
    }
    
    @IBAction func btnUpload(_ sender: UIButton){
        self.view.endEditing(true)
        let sale = self.txtSaleType.accessibilityIdentifier == "Both" ? false : self.txtSaleType.accessibilityIdentifier == "For Sale" ? true : false
        let rent = self.txtSaleType.accessibilityIdentifier == "Both" ? false : self.txtSaleType.accessibilityIdentifier == "For Rent" ? true : false
        if self.checkValidation(giveaway: self.btnGiveaway.isSelected, sale: sale, rent: rent){
            let param:[String:String] = ["book_name": self.txtBookName.text ?? "",
                                         "user_id": AppSettings.currentUser?.userID ?? "",
                                         "shelf_id": "",
                                         "author_name": self.txtAuthorName.text ?? "",
                                         "publish_date": "",
                                         "description": self.txtDescription.text ?? "",
                                         "image_url": self.imageUrl,
                                         "isbn_no": self.txtIsbnNo.text ?? "",
                                         "rent_duration": self.btnGiveaway.isSelected ? "30" : self.txtRentDurationNoOfDays.isEmpty() ? "30" : self.txtRentDurationNoOfDays.text ?? "30",
                                         "book_id": "",
                                         "category_id": self.txtCategory.accessibilityIdentifier ?? "",
                                         "mrp": self.txtApproxMRP.text ?? "0",
                                         "rental_price": self.txtBooksSecurityPrice.text ?? "0",
                                         "sale_price": self.txtRecommendedSalePrice.text ?? "0",
                                         "security_money": self.txtApproxMRP.text ?? "",
                                         "quantity": self.btnGiveaway.isSelected ? "1" : self.txtBookQuantity.text ?? "1",
                                         "selling_type": self.btnGiveaway.isSelected ? "For Sale" : self.txtSaleType.accessibilityIdentifier ?? "",
                                         "book_condition_type": self.txtBookCondition.accessibilityIdentifier ?? "",
                                         "giveaway": self.btnGiveaway.isSelected ? "yes" : "no",
                                         "is_own_library": "0",
                                         "community_id": AppSettings.communityId]
            self.bookViewModel.addNewBook(param: param, image: self.selectedImgProfile) { response in
                if response?.code ?? 0 == 1{
                    self.showPopUp(message: Messages.BOOK_UPLOAD, options: [Messages.BTN_OK]) { (str) in
                        if str == Messages.BTN_OK{
                            self.navigationController?.popViewController(animated: true)
                        }
                    }
                }
            }
        }
    }
    
    fileprivate func checkValidation(giveaway: Bool = false, sale: Bool = false, rent: Bool = false) -> Bool{
        
        var status = true
        
        if self.txtIsbnNo.isEmpty() {
            self.txtIsbnNo.superview?.layer.borderColor = UIColor.red.cgColor
            status =  false
        }
        
        if self.txtIsbnNo.text?.count == 10 || self.txtIsbnNo.text?.count == 13{
            
        }else{
            self.txtIsbnNo.superview?.layer.borderColor = UIColor.red.cgColor
            status = false
        }
        
        if self.txtBookName.isEmpty(){
            self.txtBookName.superview?.layer.borderColor = UIColor.red.cgColor
            status = false
        }
        
        if self.txtCategory.accessibilityIdentifier == nil || self.txtCategory.accessibilityIdentifier == "" || self.txtCategory.accessibilityIdentifier == "Select Category"{
            self.txtCategory.layer.borderColor = UIColor.red.cgColor
            status = false
        }
        
        if giveaway{
            status = true
            return status
        }
        
        if self.txtBookQuantity.isEmpty(){
            self.txtBookQuantity.superview?.layer.borderColor = UIColor.red.cgColor
            status = false
        }
        if self.txtApproxMRP.isEmpty(){
            self.txtApproxMRP.superview?.layer.borderColor = UIColor.red.cgColor
            status = false
        }
        if (rent && self.txtBooksSecurityPrice.isEmpty()) || (!rent && !sale && self.txtBooksSecurityPrice.isEmpty()){
            self.txtBooksSecurityPrice.superview?.layer.borderColor = UIColor.red.cgColor
            status = false
        }
        if rent && self.txtRecommendedRentDayPrice.isEmpty() || (!rent && !sale && self.txtBooksSecurityPrice.isEmpty()){
            self.txtRecommendedRentDayPrice.superview?.layer.borderColor = UIColor.red.cgColor
            status = false
        }
        if rent && self.txtRentDurationNoOfDays.isEmpty() || (!rent && !sale && self.txtBooksSecurityPrice.isEmpty()){
            self.txtRentDurationNoOfDays.superview?.layer.borderColor = UIColor.red.cgColor
            status = false
        }
        if sale && self.txtRecommendedSalePrice.isEmpty() || (!rent && !sale && self.txtBooksSecurityPrice.isEmpty()){
            self.txtRecommendedSalePrice.superview?.layer.borderColor = UIColor.red.cgColor
            status = false
        }
        
        return status
    }
    
    fileprivate func getBookOnGoogle(isbnNo: String){
        self.bookViewModel.fetchBookInfo(isbn: isbnNo) { [weak self] info in
            guard let self = self else { return }
            self.getBookMSRP(isbnNo: isbnNo)
            DispatchQueue.main.async {
                self.txtBookName.text = info?.title
                self.txtAuthorName.text = info?.authors?.first
                self.txtDescription.text = info?.volumeInfoDescription
                if let image = info?.imageLinks?.thumbnail{
                    self.imageUrl = image
                    self.imgImage.sd_setImage(with: URL.init(string: image), completed: nil)
                    self.imgImage.isHidden = false
                    self.lblOR.isHidden = false
                    self.lblORCenter.constant = 0
                }else{
                    self.imageUrl = ""
                    self.selectedImgProfile = nil
                    self.imgImage.isHidden = true
                    self.lblOR.isHidden = true
                    self.lblORCenter.constant = -80
                }
            }
        }
    }
    
    fileprivate func getBookMSRP(isbnNo: String){
        self.bookViewModel.fetchBookMSRP(isbn: isbnNo) { [weak self] msrpDetail in
            guard let self = self else { return }
            DispatchQueue.main.async {
                var mrp:String = ""
                if (msrpDetail?.msrp == "" || msrpDetail?.msrp == "null" || msrpDetail?.msrp == "0.00"){
                    self.txtApproxMRP.text = nil
                }else {
                    let arrMSRP = msrpDetail?.msrp?.components(separatedBy: ".")
                    if arrMSRP?.count ?? 0 > 0{
                        mrp = arrMSRP?.first ?? ""
                        let mrpVal: Int = ((Int(mrp) ?? 0) * 80) / 2
                        self.txtApproxMRP.text = "\(mrpVal)"
                        self.checkBookConditionPer(self.txtApproxMRP)
                    }else{
                        mrp = msrpDetail?.msrp ?? ""
                        self.txtApproxMRP.text = msrpDetail?.msrp
                        self.checkBookConditionPer(self.txtApproxMRP)
                    }
                }
            }
        }
    }
    
}

//MARK: TextField Delegate
extension AddNewBookVC: UITextFieldDelegate{
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        if textField == self.txtIsbnNo{
            self.txtIsbnNo.superview?.layer.borderColor = UIColor.AppThemColor.cgColor
        }else if textField == self.txtBookName{
            self.txtBookName.superview?.layer.borderColor = UIColor.AppThemColor.cgColor
        }else if textField == self.txtBookQuantity{
            self.txtBookQuantity.superview?.layer.borderColor = UIColor.AppThemColor.cgColor
        }else if textField == self.txtApproxMRP{
            self.txtApproxMRP.superview?.layer.borderColor = UIColor.AppThemColor.cgColor
        }else if textField == self.txtBooksSecurityPrice{
            self.txtBooksSecurityPrice.superview?.layer.borderColor = UIColor.AppThemColor.cgColor
        }else if textField == self.txtRecommendedRentDayPrice{
            self.txtRecommendedRentDayPrice.superview?.layer.borderColor = UIColor.AppThemColor.cgColor
        }else if textField == self.txtRentDurationNoOfDays{
            self.txtRentDurationNoOfDays.superview?.layer.borderColor = UIColor.AppThemColor.cgColor
        }else if textField == self.txtRecommendedSalePrice{
            self.txtRecommendedSalePrice.superview?.layer.borderColor = UIColor.AppThemColor.cgColor
        }
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        if self.txtIsbnNo == textField{
            let maxLength = 13
            let currentString = (textField.text ?? "") as NSString
            let newString = currentString.replacingCharacters(in: range, with: string)
            if newString.count <= maxLength{
                self.lblIsbnNo.text = "Isbn No ( \(newString.count)/\(maxLength) )"
                if newString.count >= 10{
                    self.getBookOnGoogle(isbnNo: newString)
                }
            }
            return newString.count <= maxLength
        }else{
            return true
        }
    }
    
    @objc func checkBookConditionPer(_ textField: UITextField){
        
        guard !textField.text!.isEmpty else { return }
        
        let bookCondition = self.txtBookCondition.accessibilityIdentifier ?? ""
        var per = 0
        switch bookCondition {
        case "As good as new":
            per = 40
            break
        case "Marked texts":
            per = 60
            break
        case "Torn or pale pages":
            per = 70
            break
        case "Marked texts & Torn cover page":
            per = 80
            break
        default:
            break
        }
        
        guard per != 0 else { return }
        
        let value = calculatePercentage(value: Double(textField.text ?? "0") ?? 0.0, percentageVal: Double(per))
        print(value)
        
        let salePrice = Int(value + 1)
        let rentPrice = Int((salePrice/30) + 1)
        
        if self.txtSaleType.accessibilityIdentifier == "Both"{
            self.txtBooksSecurityPrice.text = textField.text
            self.txtRecommendedSalePrice.text = "\(salePrice)"
            self.txtRecommendedRentDayPrice.text = "\(rentPrice)"
        }else if self.txtSaleType.accessibilityIdentifier == "For Sale"{
            self.txtRecommendedSalePrice.text = "\(salePrice)"
        }else if self.txtSaleType.accessibilityIdentifier == "For Rent"{
            self.txtBooksSecurityPrice.text = textField.text
            self.txtRecommendedRentDayPrice.text = "\(rentPrice)"
        }
    }
    
    //Calucate percentage based on given values
    public func calculatePercentage(value:Double,percentageVal:Double)->Double{
        let val = value * percentageVal
        return value - (val / 100.0)
    }
}

// MARK: ImagePickerDelegate
extension AddNewBookVC: ImagePickerDelegate {

    func imagePicker(_ imagePicker: ImagePicker, didSelect image: UIImage) {
        imagePicker.dismiss()
        self.imgImage.image = image
        self.selectedImgProfile = image
        self.imgImage.isHidden = false
        self.lblOR.isHidden = false
        self.lblORCenter.constant = 0
    }

    func cancelButtonDidClick(on imageView: ImagePicker) { imagePicker.dismiss() }
    func imagePicker(_ imagePicker: ImagePicker, grantedAccess: Bool,
                     to sourceType: UIImagePickerController.SourceType) {
        guard grantedAccess else { return }
        imagePicker.present(parent: self, sourceType: sourceType)
    }
}

//MARK: Barcode Scanner Delegate
extension AddNewBookVC: BarcodeScannerCodeDelegate, BarcodeScannerErrorDelegate, BarcodeScannerDismissalDelegate{
    
    func scanner(_ controller: BarcodeScannerViewController, didCaptureCode code: String, type: String) {
        controller.dismiss(animated: true) {
            self.txtIsbnNo.text = code
            self.getBookOnGoogle(isbnNo: code)
        }
    }
    
    func scanner(_ controller: BarcodeScannerViewController, didReceiveError error: Error) {
        print(error.localizedDescription)
    }
    
    func scannerDidDismiss(_ controller: BarcodeScannerViewController) {
        controller.dismiss(animated: true, completion: nil)
    }
    
}
