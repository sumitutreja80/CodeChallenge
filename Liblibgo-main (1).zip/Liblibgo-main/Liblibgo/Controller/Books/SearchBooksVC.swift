//
//  SearchBooksVC.swift
//  Liblibgo
//
//  Created by apple on 21/05/22.
//

import UIKit

class SearchBooksVC: UIViewController {
    
    @IBOutlet weak var colBookList: UICollectionView!
    @IBOutlet weak var txtSearchBar: UITextField!

    lazy var viewModel : SearchBooksListVM = {
        let viewModel = SearchBooksListVM()
        return viewModel
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.title = "Search Community's Books"
        self.prepareUI()
        self.viewModel.data.addAndNotify(observer: self) { [weak self] _ in
            if self?.viewModel.state == .loading || self?.viewModel.state == .initial{
                self?.colBookList.refreshControl?.beginRefreshing()
            }else{
                self?.colBookList.refreshControl?.endRefreshing()
                self?.colBookList.reloadData()
            }
        }
        self.viewModel.fetchBooksList(bookName: self.txtSearchBar.text ?? "")
    }
    
    static func instance() -> SearchBooksVC{
        return StoryBoards.Books.instantiateViewController(withIdentifier: "SearchBooksVC") as! SearchBooksVC
    }
    
    fileprivate func prepareUI(){
        self.txtSearchBar.addTarget(self, action: #selector(self.textSearchChange(_:)), for: .editingChanged)
        self.colBookList.contentInset = .init(top: 5.0, left: 5.0, bottom: 5.0, right: 5.0)
        self.colBookList.register(UINib.init(nibName: "colSearchBooksCell", bundle: nil), forCellWithReuseIdentifier: "colSearchBooksCell")
        let refreshControl = UIRefreshControl()
        refreshControl.addTarget(self, action: #selector(self.refreshData), for: .valueChanged)
        self.colBookList.refreshControl = refreshControl
    }
    
    @objc func refreshData(){
        self.viewModel.fetchBooksList(bookName: self.txtSearchBar.text ?? "")
    }

}

extension SearchBooksVC: UITextFieldDelegate{
    
    @objc func textSearchChange(_ sender: UITextField){
        self.viewModel.fetchBooksList(bookName: sender.text ?? "")
    }
    
}

extension SearchBooksVC: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout{
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.viewModel.data.value.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "colSearchBooksCell", for: indexPath) as! colSearchBooksCell
        cell.bindData(self.viewModel.data.value[indexPath.row])
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let vc = BookDetailsVC.instance()
        vc.objBookDetail = self.viewModel.data.value[indexPath.row]
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let width = (collectionView.frame.width / 2) - 5
        return .init(width: width, height: width * 1.4)
    }
}
