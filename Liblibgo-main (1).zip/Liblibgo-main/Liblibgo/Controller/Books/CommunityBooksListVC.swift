//
//  CommunityBooksListVC.swift
//  Liblibgo
//
//  Created by apple on 10/06/22.
//

import UIKit

class CommunityBooksListVC: UIViewController {

    @IBOutlet weak var colBookList: UICollectionView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.colBookList.contentInset = .init(top: 5.0, left: 5.0, bottom: 5.0, right: 5.0)
        self.colBookList.register(UINib.init(nibName: "colSearchBooksCell", bundle: nil), forCellWithReuseIdentifier: "colSearchBooksCell")
    }
    

    static func instance() -> CommunityBooksListVC{
        return StoryBoards.Books.instantiateViewController(withIdentifier: "CommunityBooksListVC") as! CommunityBooksListVC
    }

}

extension CommunityBooksListVC: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout{
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "colSearchBooksCell", for: indexPath) as! colSearchBooksCell
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let width = (collectionView.frame.width / 2) - 5
        return .init(width: width, height: width * 1.4)
    }
}
