//
//  UploadStackOfBookVC.swift
//  Liblibgo
//
//  Created by apple on 28/06/22.
//

import UIKit

class UploadStackOfBookVC: UIViewController {

    @IBOutlet weak var btnGiveaway: UIButton!
    @IBOutlet weak var txtStackName: UITextField!
    @IBOutlet weak var txtDescription: UITextField!
    @IBOutlet weak var txtCategory: DropDownField!
    @IBOutlet weak var txtBookCondition: DropDownField!
    @IBOutlet weak var vwTotalPrice: UIView!
    @IBOutlet weak var txtTotalPrice: UITextField!
    @IBOutlet weak var txtQuantity: UITextField!
    @IBOutlet weak var imgImage: UIImageView!
    
    private lazy var imagePicker: ImagePicker = {
        let imagePicker = ImagePicker()
        imagePicker.delegate = self
        return imagePicker
    }()
    var selectedImgProfile: UIImage? = nil
    var arrCategory: [CategoryList] = []
    lazy var bookViewModel : UploadBookVM = {
        let viewModel = UploadBookVM()
        return viewModel
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.title = "Upload Stack Of Books"
        self.prepareUI()
    }
    
    static func instance() -> UploadStackOfBookVC{
        return StoryBoards.Books.instantiateViewController(withIdentifier: "UploadStackOfBookVC") as! UploadStackOfBookVC
    }
    
    fileprivate func prepareUI(){
        self.txtCategory.lblText.text = "Select Category"
        var arrStr:[String] = ["Select Category"]
        arrStr.append(contentsOf: self.arrCategory.map({ $0.categoryName ?? "" }))
        self.txtCategory.dropDown.dataSource = arrStr
        self.txtCategory.dropDown.selectionAction = { [unowned self] (index: Int, item: String) in
            self.txtCategory.lblText.text = item
            if item != "Select Category"{
                if let item = self.arrCategory.first(where: { $0.categoryName == item }){
                    self.txtCategory.accessibilityIdentifier = item.categoryID ?? nil
                }else{
                    self.txtCategory.accessibilityIdentifier = nil
                }
            }else{
                self.txtCategory.accessibilityIdentifier = nil
            }
        }
        
        self.txtBookCondition.lblText.text = "Select Condition"
        self.txtBookCondition.accessibilityIdentifier = "Select Condition"
        self.txtBookCondition.dropDown.dataSource = ["As good as new", "Marked texts", "Torn or pale pages", "Marked texts & Torn cover page"]
        self.txtBookCondition.dropDown.selectionAction = { [unowned self] (index: Int, item: String) in
            self.txtBookCondition.lblText.text = item
            self.txtBookCondition.accessibilityIdentifier = item
        }
    }

    @IBAction func GiveawayTap(_ sender: UIButton){
        self.view.endEditing(true)
        sender.isSelected = !sender.isSelected
        self.viewEnableDisable(giveaway: self.btnGiveaway.isSelected)
    }
    
    @IBAction func btnClickPicture(_ sender: UIButton){
        self.view.endEditing(true)
        //self.imagePicker.cameraAsscessRequest()
        self.imagePicker.photoGalleryAsscessRequest()
    }
    
    @IBAction func btnUpload(_ sender: UIButton){
        self.view.endEditing(true)
        if self.checkValidation(giveaway: self.btnGiveaway.isSelected){
            let param:[String:String] = ["book_name": self.txtStackName.text ?? "",
                                         "user_id": AppSettings.currentUser?.userID ?? "",
                                         "description": self.txtDescription.text ?? "",
                                         "is_own_library": "0",
                                         "community_id": AppSettings.communityId,
                                         "book_condition_type": self.txtBookCondition.accessibilityIdentifier ?? "",
                                         "category": self.txtCategory.accessibilityIdentifier ?? "",
                                         "stack_quantity": self.txtQuantity.text ?? "",
                                         "giveaway": self.btnGiveaway.isSelected ? "yes" : "no",
                                         "selling_type": "For Sale",
                                         "sale_price": self.txtTotalPrice.text ?? ""]
            self.bookViewModel.stackBookUpload(param: param, image: self.selectedImgProfile ?? UIImage()) { response in
                if response?.code ?? 0 == 1{
                    self.showPopUp(message: Messages.BOOK_UPLOAD, options: [Messages.BTN_OK]) { (str) in
                        if str == Messages.BTN_OK{
                            self.navigationController?.popViewController(animated: true)
                        }
                    }
                }
            }
        }
    }
    
    fileprivate func viewEnableDisable(giveaway: Bool = false) {
        self.vwTotalPrice.isUserInteractionEnabled = !giveaway
        self.vwTotalPrice.alpha = giveaway ? 0.5 : 1.0
        self.txtTotalPrice.superview?.layer.borderColor = UIColor.AppThemColor.cgColor
        self.txtTotalPrice.text = giveaway ? "0" : nil
    }
    
    fileprivate func checkValidation(giveaway: Bool = false) -> Bool{
        
        var status = true
        
        if self.txtStackName.isEmpty() {
            self.txtStackName.superview?.layer.borderColor = UIColor.red.cgColor
            status =  false
        }
                
        if self.txtCategory.accessibilityIdentifier == nil || self.txtCategory.accessibilityIdentifier == "" || self.txtCategory.accessibilityIdentifier == "Select Category"{
            self.txtCategory.layer.borderColor = UIColor.red.cgColor
            status = false
        }
        
        if self.txtBookCondition.accessibilityIdentifier == nil || self.txtBookCondition.accessibilityIdentifier == "" || self.txtBookCondition.accessibilityIdentifier == "Select Condition"{
            self.txtBookCondition.layer.borderColor = UIColor.red.cgColor
            status = false
        }
        
        if self.txtTotalPrice.isEmpty() && !giveaway{
            self.txtTotalPrice.superview?.layer.borderColor = UIColor.red.cgColor
            status = false
        }
        
        if self.txtQuantity.isEmpty(){
            self.txtQuantity.superview?.layer.borderColor = UIColor.red.cgColor
            status = false
        }
        
        if self.selectedImgProfile == nil{
            self.imgImage.borderColor = .red
            Utill.setTost(title: nil, message: "Provide Book Image.", controller: self, completion: nil)
            status = false
        }
        
        return status
    }
}

//MARK: TextField Delegate
extension UploadStackOfBookVC: UITextFieldDelegate{
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        if textField == self.txtStackName{
            self.txtStackName.superview?.layer.borderColor = UIColor.AppThemColor.cgColor
        }else if textField == self.txtTotalPrice{
            self.txtTotalPrice.superview?.layer.borderColor = UIColor.AppThemColor.cgColor
        }else if textField == self.txtQuantity{
            self.txtQuantity.superview?.layer.borderColor = UIColor.AppThemColor.cgColor
        }
    }
}

// MARK: ImagePickerDelegate
extension UploadStackOfBookVC: ImagePickerDelegate {

    func imagePicker(_ imagePicker: ImagePicker, didSelect image: UIImage) {
        imagePicker.dismiss()
        self.imgImage.image = image
        self.selectedImgProfile = image
        self.imgImage.borderColor = .AppThemColor
    }

    func cancelButtonDidClick(on imageView: ImagePicker) { imagePicker.dismiss() }
    func imagePicker(_ imagePicker: ImagePicker, grantedAccess: Bool,
                     to sourceType: UIImagePickerController.SourceType) {
        guard grantedAccess else { return }
        imagePicker.present(parent: self, sourceType: sourceType)
    }
}
