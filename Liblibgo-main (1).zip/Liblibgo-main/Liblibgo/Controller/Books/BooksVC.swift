//
//  BooksVC.swift
//  Liblibgo
//
//  Created by apple on 10/06/22.
//

import UIKit
import Parchment

class BooksVC: UIViewController {

    @IBOutlet weak var vwContainer: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.title = "Books"
        let config = UIImage.SymbolConfiguration(scale: .large)
        let rightBtn = UIBarButtonItem(image: UIImage(systemName: "magnifyingglass")?.withConfiguration(config), style: .plain, target: self, action: #selector(self.btnSearch(_:)))
        self.navigationItem.rightBarButtonItem = rightBtn
        self.prepareUI()
        
    }

    static func instance() -> BooksVC{
        return StoryBoards.Books.instantiateViewController(withIdentifier: "BooksVC") as! BooksVC
    }

    fileprivate func prepareUI(){
        let communityLibraryVC = IndividualBooksListVC.instance()
        communityLibraryVC.title = "Individual Books".uppercased()
        
        let individualLibraryVC = CommunityBooksListVC.instance()
        individualLibraryVC.title = "Community Books".uppercased()
        
        let pagingViewController = PagingViewController(viewControllers: [
            communityLibraryVC,
            individualLibraryVC,
        ])
        
        pagingViewController.backgroundColor = .AppThemColor
        pagingViewController.textColor = .white
        pagingViewController.selectedTextColor = .black
        pagingViewController.menuBackgroundColor = .AppThemColor
        pagingViewController.selectedBackgroundColor = .white
        pagingViewController.indicatorColor = .clear
        pagingViewController.font = UIFont.systemFont(ofSize: 15.0)
        pagingViewController.selectedFont = UIFont.systemFont(ofSize: 15.0)
        
        addChild(pagingViewController)
        self.vwContainer.addSubview(pagingViewController.view)
        self.vwContainer.constrainToEdges(pagingViewController.view)
        pagingViewController.didMove(toParent: self)
    }
    
    @objc func btnSearch(_ sender: UIBarButtonItem){
        let vc = SearchBooksVC.instance()
        self.navigationController?.pushViewController(vc, animated: true)
    }
}
