//
//  IndividualBooksListVC.swift
//  Liblibgo
//
//  Created by apple on 10/06/22.
//

import UIKit

class IndividualBooksListVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    static func instance() -> IndividualBooksListVC{
        return StoryBoards.Books.instantiateViewController(withIdentifier: "IndividualBooksListVC") as! IndividualBooksListVC
    }

}
