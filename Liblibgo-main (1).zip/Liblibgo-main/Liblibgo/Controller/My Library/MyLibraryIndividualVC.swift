//
//  MyLibraryIndividualVC.swift
//  Liblibgo
//
//  Created by apple on 13/06/22.
//

import UIKit

class MyLibraryIndividualVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    static func instance() -> MyLibraryIndividualVC{
        return StoryBoards.MyLibrary.instantiateViewController(withIdentifier: "MyLibraryIndividualVC") as! MyLibraryIndividualVC
    }

}
