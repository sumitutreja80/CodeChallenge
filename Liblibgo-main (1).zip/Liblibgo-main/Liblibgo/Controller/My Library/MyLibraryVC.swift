//
//  MyLibraryVC.swift
//  Liblibgo
//
//  Created by apple on 21/05/22.
//

import UIKit
import Parchment

class MyLibraryVC: UIViewController {

    @IBOutlet weak var vwLogin: UIView!
    @IBOutlet weak var vwContainer: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.prepareUI()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.vwLogin.isHidden = AppSettings.currentUser != nil
    }
    
    static func instance() -> MyLibraryVC{
        return StoryBoards.Main.instantiateViewController(withIdentifier: "MyLibraryVC") as! MyLibraryVC
    }
    
    fileprivate func prepareUI(){
        let communityLibraryVC = MyLibraryIndividualVC.instance()
        communityLibraryVC.title = "Individual Library".uppercased()
        
        let individualLibraryVC = MyLibraryCommunityVC.instance()
        individualLibraryVC.title = "Community Library".uppercased()
        
        let pagingViewController = PagingViewController(viewControllers: [
            individualLibraryVC,
            communityLibraryVC,
        ])
        
        pagingViewController.backgroundColor = .AppThemColor
        pagingViewController.textColor = .white
        pagingViewController.selectedTextColor = .black
        pagingViewController.menuBackgroundColor = .AppThemColor
        pagingViewController.selectedBackgroundColor = .white
        pagingViewController.indicatorColor = .clear
        pagingViewController.font = UIFont.systemFont(ofSize: 12.0)
        pagingViewController.selectedFont = UIFont.systemFont(ofSize: 12.0)
        
        addChild(pagingViewController)
        self.vwContainer.addSubview(pagingViewController.view)
        self.vwContainer.constrainToEdges(pagingViewController.view)
        pagingViewController.didMove(toParent: self)
    }

    @IBAction func btnLogin(_ sender: UIButton){
        if let topVC = UIApplication.getTopViewController(){
            let vc = LoginVC.instance()
            vc.modalPresentationStyle = .fullScreen
            topVC.present(vc, animated: true, completion: nil)
        }
    }
}
