//
//  ManageMyLibraryVC.swift
//  Liblibgo
//
//  Created by apple on 23/06/22.
//

import UIKit

class ManageMyLibraryVC: UIViewController {

    @IBOutlet weak var imgLibrary: UIImageView!{
        didSet{
            self.imgLibrary.layer.cornerRadius = self.imgLibrary.frame.height / 2
        }
    }
    @IBOutlet weak var lblLibraryName: UILabel!
    @IBOutlet weak var lblAddress: UILabel!
    @IBOutlet weak var lblLibCoins: UILabel!
    @IBOutlet weak var btnEditLibrary: UIButton!
    
    var myLibraryObj: MyLibraryResponse? = nil
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.title = "Library Dashboard"
        self.prepareUI()
    }

    static func instance() -> ManageMyLibraryVC{
        return StoryBoards.MyLibrary.instantiateViewController(withIdentifier: "ManageMyLibraryVC") as! ManageMyLibraryVC
    }
    
    fileprivate func prepareUI(){
        guard let response = self.myLibraryObj else { return }
        self.myLibraryObj = response
        self.imgLibrary.sd_setImage(with: URL.init(string: response.libraryImage ?? ""), completed: nil)
        self.lblLibraryName.text = response.libraryName
        self.lblAddress.text = response.libraryAddress
        self.lblLibCoins.text = "Lib Coins - \(response.libcoins ?? "")"
    }
    
    @IBAction func btnAddBooks(_ sender: UIButton){
        let vc = AddNewBookVC.instance()
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func btnEditLibrary(_ sender: UIButton){
        guard let response = self.myLibraryObj else { return }
        let vc = CreateVirtuallibraryVC.instance()
        vc.hidesBottomBarWhenPushed = true
        vc.myLibraryObj = response
        vc.selectedImgProfile = self.imgLibrary.image
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func btnManageLibrary(_ sender: UIButton){
        let vc = ManageCommunityUsersVC.instance()
        vc.hidesBottomBarWhenPushed = true
        self.navigationController?.pushViewController(vc, animated: true)
    }

}
