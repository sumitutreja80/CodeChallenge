//
//  MyLibraryCommunityVC.swift
//  Liblibgo
//
//  Created by apple on 13/06/22.
//

import UIKit

class MyLibraryCommunityVC: UIViewController {

    @IBOutlet weak var vwManageLibrary: UIView!
    @IBOutlet weak var vwCreateLibrary: UIView!
    @IBOutlet weak var imgLibrary: UIImageView!
    @IBOutlet weak var lblLibraryName: UILabel!
    @IBOutlet weak var lblOwnerName: UILabel!
    @IBOutlet weak var lblPeopleJoined: UILabel!
    @IBOutlet weak var btnManageLibrary: UIButton!
    @IBOutlet weak var btnEditLibrary: UIButton!
    @IBOutlet weak var btnLibraryCount: UIButton!
    @IBOutlet weak var tblJoinedLibraryList: UITableView!
    
    lazy var viewModel : LibraryListVM = {
        let viewModel = LibraryListVM()
        return viewModel
    }()
    var myLibraryObj: MyLibraryResponse? = nil
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.prepareUI()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        self.checkApartmentLibraryStatus()
    }

    static func instance() -> MyLibraryCommunityVC{
        return StoryBoards.MyLibrary.instantiateViewController(withIdentifier: "MyLibraryCommunityVC") as! MyLibraryCommunityVC
    }
    
    fileprivate func prepareUI(){
        self.tblJoinedLibraryList.register(UINib.init(nibName: "tblCommunityLibrariesCell", bundle: nil), forCellReuseIdentifier: "tblCommunityLibrariesCell")
        let refreshControl = UIRefreshControl()
        refreshControl.addTarget(self, action: #selector(self.refreshData), for: .valueChanged)
        self.tblJoinedLibraryList.refreshControl = refreshControl
        self.tblJoinedLibraryList.tableFooterView = UIView()
        self.viewModel.data.addAndNotify(observer: self) { [weak self] _ in
            if self?.viewModel.state == .loading || self?.viewModel.state == .initial{
                self?.tblJoinedLibraryList.refreshControl?.beginRefreshing()
            }else{
                self?.tblJoinedLibraryList.refreshControl?.endRefreshing()
            }
            self?.tblJoinedLibraryList.reloadData()
        }
    }
    
    @objc func refreshData(){
        self.viewModel.fetchMyCommunityJoinedLibraryList()
    }
    
    @IBAction func btnEditLibrary(_ sender: UIButton){
        guard let response = self.myLibraryObj else { return }
        let vc = CreateVirtuallibraryVC.instance()
        vc.hidesBottomBarWhenPushed = true
        vc.myLibraryObj = response
        vc.selectedImgProfile = self.imgLibrary.image
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func btnLibraryCount(_ sender: UIButton){
        let vc = ManageCommunityUsersVC.instance()
        vc.hidesBottomBarWhenPushed = true
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func btnManageLibrary(_ sender: UIButton){
        guard let response = self.myLibraryObj else { return }
        AppSettings.communityId = "0"
        let vc = ManageMyLibraryVC.instance()
        vc.hidesBottomBarWhenPushed = true
        vc.myLibraryObj = response
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func btnLibraryList(_ sender: UIButton){
        let vc = AllLibrariesVC.instance()
        vc.hidesBottomBarWhenPushed = true
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func btnCreateVirtualLibrary(_ sender: UIButton){
        let vc = CreateVirtuallibraryVC.instance()
        vc.hidesBottomBarWhenPushed = true
        vc.isOwnLibrary = false
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    func checkApartmentLibraryStatus(){
        if AppSettings.currentUser != nil{
            self.viewModel.checkApartmentLibraryStatus(userId: AppSettings.currentUser?.userID ?? "") { [weak self] response in
                guard let self = self else { return }
                guard let response = response else {
                    self.vwCreateLibrary.isHidden = false
                    self.tblJoinedLibraryList.refreshControl?.endRefreshing()
                    return
                }
                self.myLibraryObj = response
                self.vwCreateLibrary.isHidden = true
                self.vwManageLibrary.isHidden = false
                self.imgLibrary.sd_setImage(with: URL.init(string: response.libraryImage ?? ""), completed: nil)
                self.lblLibraryName.text = response.libraryName
                self.lblOwnerName.text = "Owner, \(response.name ?? "")"
                self.lblPeopleJoined.text = "\(response.myAcceptedCount ?? 0) people joined."
            }
        }
    }

}

extension MyLibraryCommunityVC: UITableViewDelegate, UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.viewModel.data.value.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "tblCommunityLibrariesCell", for: indexPath) as! tblCommunityLibrariesCell
        cell.bindData(self.viewModel.data.value[indexPath.row])
        cell.vwStar.isHidden = true
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if self.viewModel.data.value[indexPath.row].userID == AppSettings.currentUser?.userID{
            AppSettings.communityId = "0"
            let vc = BookOfLibraryVC.instance()
            vc.hidesBottomBarWhenPushed = true
            vc.name = self.viewModel.data.value[indexPath.row].libraryName ?? ""
            vc.libraryId = self.viewModel.data.value[indexPath.row].libraryID ?? ""
            self.navigationController?.pushViewController(vc, animated: true)
        }else if self.viewModel.data.value[indexPath.row].communityStatus ?? "" == "1"{
            Utill.showActivityIndicator()
            ApiManager.sharedInstance.request(url: Endpoints.CheckLibraryCommunityStatus, parameter: ["library_id":self.viewModel.data.value[indexPath.row].libraryID ?? "", "user_id": AppSettings.currentUser?.userID ?? ""]) { (result: Result<CheckLibraryStatusModel, ErrorType>) in
                Utill.removeActivityIndicator()
                guard let res = try? result.get() else {
                    Utill.setTost(title: nil, message: "Join fist to see books of this community.", controller: self, completion: nil)
                    return
                }
                if res.response?.message == "data available" && res.response?.status == "1"{
                    AppSettings.communityId = res.response?.communityID ?? ""
                    let vc = BookOfLibraryVC.instance()
                    vc.name = self.viewModel.data.value[indexPath.row].libraryName ?? ""
                    vc.libraryId = self.viewModel.data.value[indexPath.row].libraryID ?? ""
                    vc.hidesBottomBarWhenPushed = true
                    self.navigationController?.pushViewController(vc, animated: true)
                }else if res.response?.status == "0"{
                    //requested message
                    Utill.setTost(title: nil, message: "Your request is pending yet.", controller: self, completion: nil)
                }else{
                    Utill.setTost(title: nil, message: "Join fist to see books of this community.", controller: self, completion: nil)
                }
            }
        }
    }
}
