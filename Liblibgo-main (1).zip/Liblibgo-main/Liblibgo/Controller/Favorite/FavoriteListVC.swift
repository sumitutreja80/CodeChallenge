//
//  FavoriteListVC.swift
//  Liblibgo
//
//  Created by apple on 29/05/22.
//

import UIKit

class FavoriteListVC: UIViewController {

    @IBOutlet weak var tblBookList: UITableView!
    
    var arrWishlistData: [BookList] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.title = "Favorite"
        self.prepareUI()
        self.getBookList()
    }
    

    static func instance() -> FavoriteListVC{
        return StoryBoards.Main.instantiateViewController(withIdentifier: "FavoriteListVC") as! FavoriteListVC
    }
    
    fileprivate func prepareUI(){
        self.tblBookList.register(UINib.init(nibName: "tblFavoriteListCell", bundle: nil), forCellReuseIdentifier: "tblFavoriteListCell")
        let refreshControl = UIRefreshControl()
        refreshControl.addTarget(self, action: #selector(self.refreshData), for: .valueChanged)
        self.tblBookList.refreshControl = refreshControl
        self.tblBookList.tableFooterView = UIView()
    }

    @objc func refreshData(){
        self.getBookList()
    }
    
    fileprivate func getBookList(){
        self.tblBookList.refreshControl?.beginRefreshing()
        ApiManager.sharedInstance.request(url: Endpoints.MyWishlist, parameter: ["user_id": AppSettings.currentUser?.userID ?? ""]) { (result: Result<WishListModel, ErrorType>) in
            self.tblBookList.refreshControl?.endRefreshing()
            guard let res = try? result.get() else { return }
            self.arrWishlistData = res.response?.wishlistData ?? []
            self.tblBookList.reloadData()
        }
    }
}

extension FavoriteListVC: UITableViewDelegate, UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.arrWishlistData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "tblFavoriteListCell", for: indexPath) as! tblFavoriteListCell
        cell.imgBookImage.sd_setImage(with: URL.init(string: self.arrWishlistData[indexPath.row].bookImage?.urlQueryEncoded ?? ""), placeholderImage: nil, completed: nil)
        cell.lblTitle.text = self.arrWishlistData[indexPath.row].bookName
        cell.lblOwnerName.text = "By \(self.arrWishlistData[indexPath.row].authorName ?? "")"
        cell.lblPrice.text = "₹\(self.arrWishlistData[indexPath.row].salePrice ?? "")"
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vc = BookDetailsVC.instance()
        vc.objBookDetail = self.arrWishlistData[indexPath.row]
        self.navigationController?.pushViewController(vc, animated: true)
    }
}
