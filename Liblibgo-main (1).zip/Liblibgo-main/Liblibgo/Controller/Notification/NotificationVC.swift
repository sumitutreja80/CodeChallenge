//
//  NotificationVC.swift
//  Liblibgo
//
//  Created by apple on 12/06/22.
//

import UIKit

class NotificationVC: UIViewController {
    
    @IBOutlet weak var tblNotificationList: UITableView!

    var arrNotificationsList: [NotificationList] = []
    lazy var viewModel : NotificationListVM = {
        let viewModel = NotificationListVM()
        return viewModel
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.title = "Notification"
        self.prepareUI()
        self.viewModel.data.addAndNotify(observer: self) { [weak self] _ in
            if self?.viewModel.state == .loading || self?.viewModel.state == .initial{
                self?.tblNotificationList.refreshControl?.beginRefreshing()
            }else{
                self?.tblNotificationList.refreshControl?.endRefreshing()
            }
            self?.tblNotificationList.reloadData()
        }
        self.viewModel.fetchNotificationList(userId: AppSettings.currentUser?.userID ?? "")
    }

    static func instance() -> NotificationVC{
        return StoryBoards.Main.instantiateViewController(withIdentifier: "NotificationVC") as! NotificationVC
    }

    fileprivate func prepareUI(){
        self.tblNotificationList.register(UINib.init(nibName: "tblNotificationListCell", bundle: nil), forCellReuseIdentifier: "tblNotificationListCell")
        let refreshControl = UIRefreshControl()
        refreshControl.addTarget(self, action: #selector(self.refreshData), for: .valueChanged)
        self.tblNotificationList.refreshControl = refreshControl
        self.tblNotificationList.tableFooterView = UIView()
    }
    
    @objc func refreshData(){
        self.viewModel.fetchNotificationList(userId: AppSettings.currentUser?.userID ?? "")
    }
}

extension NotificationVC: UITableViewDelegate, UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.viewModel.data.value.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "tblNotificationListCell", for: indexPath) as! tblNotificationListCell
        cell.bindData(self.viewModel.data.value[indexPath.row])
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let orderId = Int(self.viewModel.data.value[indexPath.row].orderID ?? "0") ?? 0
        let communityId = Int(self.viewModel.data.value[indexPath.row].communityId ?? "0") ?? 0
        if orderId > 0{
            let vc = OrderDetailVC.instance()
            vc.orderId = "\(orderId)"
            vc.hidesBottomBarWhenPushed = true
            self.navigationController?.pushViewController(vc, animated: true)
        }else if self.viewModel.data.value[indexPath.row].notificationStatus ?? "" == "1"{
            let vc = ManageCommunityUsersVC.instance()
            vc.hidesBottomBarWhenPushed = true
            self.navigationController?.pushViewController(vc, animated: true)
        }else if communityId > 0{
            let vc = BookOfLibraryVC.instance()
            AppSettings.communityId = self.viewModel.data.value[indexPath.row].communityId ?? "0"
            vc.name = self.viewModel.data.value[indexPath.row].libraryName ?? ""
            vc.libraryId = self.viewModel.data.value[indexPath.row].libraryId ?? ""
            vc.hidesBottomBarWhenPushed = true
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }

}
