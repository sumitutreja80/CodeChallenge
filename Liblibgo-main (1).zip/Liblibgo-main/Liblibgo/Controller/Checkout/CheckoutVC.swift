//
//  CheckoutVC.swift
//  Liblibgo
//
//  Created by apple on 28/05/22.
//

import UIKit
import Razorpay

class CheckoutVC: UIViewController {
    
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblAddress: UILabel!
    @IBOutlet weak var tblCartList: UITableView!
    @IBOutlet weak var tblCartListHeight: NSLayoutConstraint!
    @IBOutlet weak var lblBookPriceText: UILabel!
    @IBOutlet weak var lblBookPrice: UILabel!
    @IBOutlet weak var lblSecurityDeposit: UILabel!
    @IBOutlet weak var lblBagTotal: UILabel!
    @IBOutlet weak var lblShippingCharge: UILabel!
    @IBOutlet weak var lblLibCoin: UILabel!
    @IBOutlet weak var lblOrderTotal: UILabel!
    @IBOutlet weak var btnConfirm: UIButton!
    
    var arrCartList: [ResponseCartList] = []
    var razorpayObj : RazorpayCheckout? = nil
    var merchantDetails : MerchantsDetails = MerchantsDetails.getDefaultData()
    var totalCartAmount = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Checkout"
        self.prepareUI()
        self.getCartList()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.tblCartList.addObserver(self, forKeyPath: "contentSize", options: .new, context: nil)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.tblCartList.removeObserver(self, forKeyPath: "contentSize")
    }
    
    override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
        
        if let tbl = object as? UITableView{
            if tbl == self.tblCartList {
                self.tblCartList.layer.removeAllAnimations()
                self.tblCartListHeight.constant = self.tblCartList.contentSize.height
            }
        }
        
        UIView.animate(withDuration: 0.5) {
            self.updateViewConstraints()
            self.loadViewIfNeeded()
        }
    }
    
    static func instance() -> CheckoutVC{
        return StoryBoards.Main.instantiateViewController(withIdentifier: "CheckoutVC") as! CheckoutVC
    }
    
    fileprivate func prepareUI(){
        if let name = AppSettings.currentUser?.username{
            self.lblName.text = name
            self.merchantDetails.name = name
        }else if let name = AppSettings.currentUser?.userName{
            self.lblName.text = name
            self.merchantDetails.name = name
        }
        self.lblAddress.text = "\(AppSettings.currentUser?.address ?? "")\n\(AppSettings.currentUser?.mobile ?? "")"
        self.tblCartList.register(UINib.init(nibName: "tblCheckoutItemCell", bundle: nil), forCellReuseIdentifier: "tblCheckoutItemCell")
        self.tblCartList.tableFooterView = UIView()
    }
    
    
    fileprivate func getCartList(){
        Utill.showActivityIndicator()
        self.tblCartList.refreshControl?.beginRefreshing()
        ApiManager.sharedInstance.request(url: Endpoints.Checkout, parameter: ["user_id": AppSettings.currentUser?.userID ?? ""]) { (result: Result<CheckoutModel, ErrorType>) in
            Utill.removeActivityIndicator()
            self.tblCartList.refreshControl?.endRefreshing()
            guard let res = try? result.get() else { return }
            self.arrCartList = res.response?.cartList ?? []
            self.tblCartList.reloadData()
            self.totalCartAmount = Int(res.response?.totalCartAmount ?? 0)
            if let mainCart = res.response?.cartList?.first, let cartList = mainCart.cartList?.first{
                if cartList.cartFor ?? "" == "rent"{
                    self.lblBookPriceText.text = "Book Price\n(Rent for \(cartList.rentDuration ?? "") days)"
                    self.lblBookPrice.text = "₹ \(cartList.bookPrice ?? 0)"
                    self.lblSecurityDeposit.text = "₹\(res.response?.securityMoney ?? "0")"
                } else if cartList.cartFor ?? "" == "purchase"{
                    self.lblBookPriceText.text = "Book Price (Purchase)"
                    self.lblBookPrice.text = "₹ \(cartList.bookPrice ?? 0)"
                    self.lblSecurityDeposit.text = "₹ 0"
                } else{
                    self.lblBookPrice.text = "₹ 0"
                }
            }else{
                self.lblBookPrice.text = "₹ 0"
            }
            self.lblBagTotal.text = "₹\(res.response?.totalCartAmount ?? 0)"
            self.lblOrderTotal.text = "₹\(res.response?.totalCartAmount ?? 0)"
            self.lblLibCoin.text = "Lib Coins: \(res.response?.libcoins ?? "0")"
        }
    }
    
    fileprivate func createOrder(txnId: String, orderAmount: Int){
        let libraryIds = self.arrCartList.map({ $0.libraryID ?? "" }).joined(separator: ",")
        Utill.showActivityIndicator()
        ApiManager.sharedInstance.request(url: Endpoints.CreateOrder, parameter: ["user_id": AppSettings.currentUser?.userID ?? "", "library_ids": "[\(libraryIds)]", "txn_id":txnId, "payment_status":"success", "customer_name": self.lblName.text ?? "", "mobile":AppSettings.currentUser?.mobile ?? "", "address":AppSettings.currentUser?.address ?? "", "order_amount":"\(orderAmount)", "libcoins":"0"]) { (result: Result<GeneralResponceModel, ErrorType>) in
            Utill.removeActivityIndicator()
            guard let res = try? result.get() else { return }
            print(res.response?.message ?? "")
            let vc = ThankYouVC.instance()
            self.navigationController?.pushViewController(vc, animated: false)
        }
    }
    
    @IBAction func btnConfirmTap(_ sender: UIButton){
        self.openRazorpayCheckout()
    }
    
    private func openRazorpayCheckout() {
        if totalCartAmount <= 0{
            let vc = ThankYouVC.instance()
            self.navigationController?.pushViewController(vc, animated: false)
        }else{
            // 1. Initialize razorpay object with provided key. Also depending on your requirement you can assign delegate to self. It can be one of the protocol from RazorpayPaymentCompletionProtocolWithData, RazorpayPaymentCompletionProtocol.
            razorpayObj = RazorpayCheckout.initWithKey(Endpoints.razorpayKey, andDelegate: self)
            let options: [AnyHashable:Any] = [
                "prefill": [
                    "contact": "+91\(AppSettings.currentUser?.mobile ?? "1234567890")",
                    "email": AppSettings.currentUser?.email ?? "a@a.com"
                ],
                "image": merchantDetails.logo,
                "amount" : self.totalCartAmount * 100,
                "currency": "INR",
                "name": merchantDetails.name,
                "theme": [
                    "color": merchantDetails.color.toHexString()
                ],
                "description": "is a one stop solution for your library management"
                // follow link for more options - https://razorpay.com/docs/payment-gateway/web-integration/standard/checkout-form/
            ]
            if let rzp = self.razorpayObj {
                rzp.open(options)
            } else {
                print("Unable to initialize")
            }
        }
    }
}

extension CheckoutVC : CustomizeDataDelegate {
    
    func dataChanged(with merchantDetails: MerchantsDetails) {
        self.merchantDetails = merchantDetails
    }
    
}

// RazorpayPaymentCompletionProtocol - This will execute two methods 1.Error and 2. Success case. On payment failure you will get a code and description. In payment success you will get the payment id.
extension CheckoutVC : RazorpayPaymentCompletionProtocol {
    
    func onPaymentError(_ code: Int32, description str: String) {
        print("error: ", code, str)
        self.showAlert(withMessage: str, withActions: UIAlertAction(title: "Ok", style: .default) { (_) in
            
        })
    }
    
    func onPaymentSuccess(_ payment_id: String) {
        self.createOrder(txnId: payment_id, orderAmount: self.totalCartAmount)
    }
}

// RazorpayPaymentCompletionProtocolWithData - This will returns you the data in both error and success case. On payment failure you will get a code and description. In payment success you will get the payment id.
extension CheckoutVC: RazorpayPaymentCompletionProtocolWithData {
    
    func onPaymentError(_ code: Int32, description str: String, andData response: [AnyHashable : Any]?) {
        print("error: ", code)
        self.showAlert(withMessage: str, withActions: UIAlertAction(title: "Ok", style: .default) { (_) in
            
        })
    }
    
    func onPaymentSuccess(_ payment_id: String, andData response: [AnyHashable : Any]?) {
        print("success: ", payment_id)
        self.createOrder(txnId: payment_id, orderAmount: self.totalCartAmount)
    }
}

extension CheckoutVC: UITableViewDelegate, UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.arrCartList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "tblCheckoutItemCell", for: indexPath) as! tblCheckoutItemCell
        cell.lblLibraryName.text = self.arrCartList[indexPath.row].libraryName
        cell.lblTotalPrice.text = "Total Price : ₹\(self.arrCartList[indexPath.row].libraryPrice ?? 0)"
        cell.lblShippingCharge.text = "Shipping Charge : ₹0"
        cell.swBookList.removeAllArrangedSubviews()
        self.arrCartList[indexPath.row].cartList?.forEach({ cartList in
            let vw = vwCartLibrary.instanceFromNib() as! vwCartLibrary
            vw.setDetail(obj: cartList, isFromCheckout: true)
            vw.controller = self
            cell.swBookList.addArrangedSubview(vw)
            cell.layoutIfNeeded()
        })
        return cell
    }
}

protocol CustomizeDataDelegate {
    func dataChanged(with merchantDetails : MerchantsDetails)
}

struct MerchantsDetails {
    var name : String
    let logo : String
    let color : UIColor
}

extension MerchantsDetails {
    
    static func getDefaultData() -> MerchantsDetails {
        let details = MerchantsDetails(name: AppSettings.APP_NAME,
                                       logo: "https://liblibgo.com/front/img/logo.jpg",
                                       color: UIColor.AppThemColor)
        return details
    }
}
