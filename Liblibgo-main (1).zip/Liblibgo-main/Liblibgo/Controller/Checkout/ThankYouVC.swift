//
//  ThankYouVC.swift
//  Liblibgo
//
//  Created by apple on 30/05/22.
//

import UIKit

class ThankYouVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
            let vc = StoryBoards.Main.instantiateInitialViewController()
            UIApplication.shared.keyWindow?.rootViewController = vc
            UIApplication.shared.keyWindow?.makeKeyAndVisible()
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }
    
    static func instance() -> ThankYouVC{
        return StoryBoards.Main.instantiateViewController(withIdentifier: "ThankYouVC") as! ThankYouVC
    }

}
