//
//  CartModel.swift
//  Liblibgo
//
//  Created by apple on 28/05/22.
//

import Foundation

// MARK: - CartModel
struct CartModel: Codable {
    let response: CartResponse?
}

// MARK: - Response
struct CartResponse: Codable {
    let code: Int?
    let message: String?
    let cartList: [ResponseCartList]?

    enum CodingKeys: String, CodingKey {
        case code, message
        case cartList = "cart_list"
    }
}

// MARK: - ResponseCartList
struct ResponseCartList: Codable {
    let libraryID, libraryName, libraryPincode, libraryAddress: String?
    let isSelfPickup, libraryPrice: Int?
    let selfPickupStatus: String?
    let libraryImage: String?
    let customerCity, customerState, customerArea, customerPincode: String?
    let customerLandmark: String?
    let cartList: [CartList]?
    
    enum CodingKeys: String, CodingKey {
        case libraryID = "library_id"
        case libraryName = "library_name"
        case libraryPincode = "library_pincode"
        case libraryAddress = "library_address"
        case isSelfPickup = "IsSelfPickup"
        case libraryPrice = "library_price"
        case selfPickupStatus = "self_pickup_status"
        case libraryImage = "library_image"
        case customerCity = "customer_city"
        case customerState = "customer_state"
        case customerArea = "customer_area"
        case customerPincode = "customer_pincode"
        case customerLandmark = "customer_landmark"
        case cartList = "cart_list"
    }
}

// MARK: - CartListCartList
struct CartList: Codable {
    let cartID, cartFor, bookID, defaultPrice: String?
    let bookName, authorName: String?
    let bookImage: String?
    let bookPrice: Int?
    let bookRentDuration, cartRentDuration, bookQuantity: String?
    let rentDuration: String?

    enum CodingKeys: String, CodingKey {
        case cartID = "cart_id"
        case cartFor = "cart_for"
        case bookID = "book_id"
        case defaultPrice = "default_price"
        case bookName = "book_name"
        case authorName = "author_name"
        case bookImage = "book_image"
        case bookPrice = "book_price"
        case bookRentDuration = "book_rent_duration"
        case cartRentDuration = "cart_rent_duration"
        case bookQuantity = "book_quantity"
        case rentDuration = "rent_duration"
    }
}
