//
//  TransactionHistoryModel.swift
//  Liblibgo
//
//  Created by apple on 19/06/22.
//

import Foundation

// MARK: - Transaction History Model
struct TransactionHistoryModel: Codable {
    let response: TransactionHistoryResponse?
}

// MARK: - Transaction History Response
struct TransactionHistoryResponse: Codable {
    let code: Int?
    let message: String?
    let historyList: [TransactionHistoryList]?

    enum CodingKeys: String, CodingKey {
        case code, message
        case historyList = "history_list"
    }
}

// MARK: - Transaction History List
struct TransactionHistoryList: Codable {
    let userID, transactionFor, transactionType, bookID: String?
    let bookName, libraryID, libraryName, coins: String?
    let orderFor, iniateStatus, transactionDate: String?

    enum CodingKeys: String, CodingKey {
        case userID = "user_id"
        case transactionFor = "transaction_for"
        case transactionType = "transaction_type"
        case bookID = "book_id"
        case bookName = "book_name"
        case libraryID = "library_id"
        case libraryName = "library_name"
        case coins
        case orderFor = "order_for"
        case iniateStatus = "iniate_status"
        case transactionDate = "transaction_date"
    }
}

