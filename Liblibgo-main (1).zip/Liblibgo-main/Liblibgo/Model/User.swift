//
//  User.swift
//  Liblibgo
//
//  Created by apple on 22/05/22.
//

import Foundation

// MARK: - LoginModel
struct LoginModel: Codable {
    let response: LoginResponse?
}

// MARK: - Response
struct LoginResponse: Codable {
    let code: Int?
    let message, mobile: String?
}

struct UserModel: Codable {
    let response: User?
}

struct User: Codable {
    
    let code: Int?
    let message, userID, userName, username, loginType: String?
    let email, mobile: String?
    let profileImage: String?
    let apartmentID, apartmentName, flatNo, address: String?
    let areaName, city, state, pincode: String?
    let landmark, libcoins, secureLibcoins, deviceID: String?
    var apartmentStatus: Int?
    var upiStatus: String?
    
    enum CodingKeys: String, CodingKey {
        case code, message
        case userID = "user_id"
        case userName = "user_name"
        case username = "username"
        case loginType = "login_type"
        case email, mobile
        case profileImage = "profile_image"
        case apartmentID = "apartment_id"
        case apartmentName = "apartment_name"
        case flatNo = "flat_no"
        case address
        case areaName = "area_name"
        case city, state, pincode, landmark, libcoins
        case secureLibcoins = "secure_libcoins"
        case deviceID = "device_id"
        case apartmentStatus = "apartment_status"
        case upiStatus = "upi_status"
    }
    
    func saveToDefault() {
        if let data = try? JSONEncoder().encode(self) {
            UserDefaults.standard.set(data, forKey: "liblibgo_user")
            UserDefaults.standard.synchronize()
        }
    }
    
    func clearFromDefault() {
        UserDefaults.standard.removeObject(forKey: "liblibgo_user")
        UserDefaults.standard.synchronize()
    }
    
    static func loadFromDefault() -> User? {
        if let data = UserDefaults.standard.value(forKey: "liblibgo_user") as? Data {
            guard let decoder = try? JSONDecoder().decode(User.self, from: data) else { return nil }
            return decoder
        }
        return nil
    }
    
}

// MARK: - UserProfileModel
struct UserProfileModel: Codable {
    let response: UserProfileResponse?
}

// MARK: - Response
struct UserProfileResponse: Codable {
    let code: Int?
    let message: String?
    let profileImage: String?

    enum CodingKeys: String, CodingKey {
        case code, message
        case profileImage = "profile_image"
    }
}
