//
//  SettingModel.swift
//  Liblibgo
//
//  Created by apple on 21/06/22.
//

import Foundation

// MARK: - Setting Model
struct SettingModel: Codable {
    let response: SettingResponse?
}

// MARK: - Setting Response
struct SettingResponse: Codable {
    let code: Int?
    let message, addBookNotification, addBookCommunityNotification, notifyNotification: String?
    let demandedBookNofification: String?

    enum CodingKeys: String, CodingKey {
        case code, message
        case addBookNotification = "add_book_notification"
        case addBookCommunityNotification = "add_book_community_notification"
        case notifyNotification = "notify_notification"
        case demandedBookNofification = "demanded_book_nofification"
    }
}
