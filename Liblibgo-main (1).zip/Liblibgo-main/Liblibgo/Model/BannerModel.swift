//
//  BannerModel.swift
//  Liblibgo
//
//  Created by apple on 23/05/22.
//

import Foundation

// MARK: - BannerModel
struct BannerModel: Codable {
    let response: BannerResponse?
}

// MARK: - Response
struct BannerResponse: Codable {
    let code: Int?
    let message: String?
    let bannerList: [BannerList]?

    enum CodingKeys: String, CodingKey {
        case code, message
        case bannerList = "banner_list"
    }
}

// MARK: - BannerList
struct BannerList: Codable {
    let bannerID: String?
    let banner: String?

    enum CodingKeys: String, CodingKey {
        case bannerID = "banner_id"
        case banner
    }
}
