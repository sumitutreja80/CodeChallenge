//
//  WishListModel.swift
//  Liblibgo
//
//  Created by apple on 28/05/22.
//

import Foundation

// MARK: - Welcome
struct WishListAddRemoveModel: Codable {
    let response: WishListAddRemoveResponse?
}

// MARK: - Response
struct WishListAddRemoveResponse: Codable {
    let code: Int?
    let message: String?
    let wishlistStatus: Int?

    enum CodingKeys: String, CodingKey {
        case code, message
        case wishlistStatus = "wishlist_status"
    }
}

// MARK: - WishListModel
struct WishListModel: Codable {
    let response: WishListResponse?
}

// MARK: - Response
struct WishListResponse: Codable {
    let code: Int?
    let message: String?
    let wishlistData: [BookList]?

    enum CodingKeys: String, CodingKey {
        case code, message
        case wishlistData = "wishlist_data"
    }
}
