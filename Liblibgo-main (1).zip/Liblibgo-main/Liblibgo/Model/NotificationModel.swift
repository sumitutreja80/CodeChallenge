//
//  NotificationModel.swift
//  Liblibgo
//
//  Created by apple on 12/06/22.
//

import Foundation

// MARK: - Notification Model
struct NotificationModel: Codable {
    let response: NotificationResponse?
}

// MARK: - Response
struct NotificationResponse: Codable {
    let code: Int?
    let message: String?
    let notifications: [NotificationList]?
}

// MARK: - Notification Data
struct NotificationList: Codable {
    let notificationID, orderID, username, title: String?
    let message, readStatus, dated: String?
    let communityId, libraryId, libraryName, notificationStatus: String?

    enum CodingKeys: String, CodingKey {
        case notificationID = "notification_id"
        case orderID = "order_id"
        case username, title, message
        case readStatus = "read_status"
        case dated
        case communityId = "community_id"
        case libraryId = "library_id"
        case libraryName = "library_name"
        case notificationStatus = "notification_status"
    }
}
