//
//  GeneralResponceModel.swift
//  Liblibgo
//
//  Created by apple on 29/05/22.
//

import Foundation

// MARK: - GeneralResponceModel
struct GeneralResponceModel: Codable {
    let response: GeneralResponse?
}

// MARK: - GeneralResponse
struct GeneralResponse: Codable {
    let code: Int?
    let message: String?
    let book_id: Int?
    
    enum CodingKeys: String, CodingKey {
        case code, message, book_id
    }
}
