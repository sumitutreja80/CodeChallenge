//
//  BookListModel.swift
//  Liblibgo
//
//  Created by apple on 27/05/22.
//

import Foundation

// MARK: - Welcome
struct BookListModel: Codable {
    let response: BookListResponse?
}

// MARK: - Response
struct BookListResponse: Codable {
    let code: Int?
    let message: String?
    let bookList: [BookList]?

    enum CodingKeys: String, CodingKey {
        case code, message
        case bookList = "book_list"
    }
}

// MARK: - BookList
struct BookList: Codable {
    let wishlistId: String?
    let bookID, cellName, bookNumber, bookName: String?
    let ownerId, quantity, description: String?
    let authorName, sellingType, mrp, addedBy: String?
    let userName: String?
    let mobileNo, categoryID, categoryName: String?
    let libraryID: String?
    let libraryName: String?
    let libraryType: String?
    let issueStatus, flagStatus: Int?
    let publishDate, isbnNo, rentalPrice, salePrice: String?
    let isOwnLibrary: String?
    let imageURL: String?
    let apartmentID: String?
    let apartmentName: String?
    let giveaway: String?
    let issuedUser: String?
    let returnDate: String?
    let bookImage: String?
    var approvalStatus: String?
    
    enum CodingKeys: String, CodingKey {
        case wishlistId = "wishlist_id"
        case bookID = "book_id"
        case cellName = "cell_name"
        case bookNumber = "book_number"
        case bookName = "book_name"
        case ownerId = "owner_id"
        case quantity = "quantity"
        case description = "description"
        case authorName = "author_name"
        case sellingType = "selling_type"
        case mrp = "mrp"
        case addedBy = "added_by"
        case userName = "user_name"
        case mobileNo = "mobile_no"
        case categoryID = "category_id"
        case categoryName = "category_name"
        case libraryID = "library_id"
        case libraryName = "library_name"
        case libraryType = "library_type"
        case issueStatus = "issue_status"
        case flagStatus = "flag_status"
        case publishDate = "publish_date"
        case isbnNo = "isbn_no"
        case rentalPrice = "rental_price"
        case salePrice = "sale_price"
        case isOwnLibrary = "is_own_library"
        case imageURL = "image_url"
        case apartmentID = "apartment_id"
        case apartmentName = "apartment_name"
        case giveaway
        case issuedUser = "issued_user"
        case returnDate = "return_date"
        case bookImage = "book_image"
        case approvalStatus = "approval_status"
    }
}

// MARK: - Welcome
struct BookDetailModel: Codable {
    let response: BookDetailResponse?
}

// MARK: - Response
struct BookDetailResponse: Codable {
    let code: Int?
    let message: String?
    let bookList: BookList?

    enum CodingKeys: String, CodingKey {
        case code, message
        case bookList = "book_list"
    }
}
