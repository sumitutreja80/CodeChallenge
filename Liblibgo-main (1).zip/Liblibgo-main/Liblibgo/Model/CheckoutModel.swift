//
//  CheckoutModel.swift
//  Liblibgo
//
//  Created by apple on 28/05/22.
//

import Foundation

// MARK: - CheckoutModel
struct CheckoutModel: Codable {
    let response: CheckoutResponse?
}

// MARK: - Response
struct CheckoutResponse: Codable {
    let code: Int?
    let message: String?
    let totalCartAmount: Int?
    let libcoins, securityMoney: String?
    let cartList: [ResponseCartList]?

    enum CodingKeys: String, CodingKey {
        case code, message
        case totalCartAmount = "TotalCartAmount"
        case libcoins
        case securityMoney = "security_money"
        case cartList = "cart_list"
    }
}

