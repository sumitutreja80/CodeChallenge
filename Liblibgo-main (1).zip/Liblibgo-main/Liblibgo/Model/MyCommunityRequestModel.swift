//
//  MyCommunityRequestModel.swift
//  Liblibgo
//
//  Created by apple on 26/05/22.
//

import Foundation

// MARK: - Welcome
struct MyCommunityRequestModel: Codable {
    let response: MyCommunityRequestResponse?
}

// MARK: - Response
struct MyCommunityRequestResponse: Codable {
    let code: Int?
    let message: String?
    let requestList: [MyCommunityRequestList]?

    enum CodingKeys: String, CodingKey {
        case code, message
        case requestList = "request_list"
    }
}

// MARK: - RequestList
struct MyCommunityRequestList: Codable {
    let communityID, requestUserID, requestUserName, requestUserMobile: String?
    var libraryID, libraryName, communityStatus, requestedDate: String?

    enum CodingKeys: String, CodingKey {
        case communityID = "community_id"
        case requestUserID = "request_user_id"
        case requestUserName = "request_user_name"
        case requestUserMobile = "request_user_mobile"
        case libraryID = "library_id"
        case libraryName = "library_name"
        case communityStatus = "community_status"
        case requestedDate = "requested_date"
    }
}
