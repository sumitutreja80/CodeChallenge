//
//  CheckLibraryStatusModel.swift
//  Liblibgo
//
//  Created by apple on 26/05/22.
//

import Foundation

// MARK: - Check Library
struct CheckLibraryStatusModel: Codable {
    let response: CheckLibraryStatusResponse?
}

// MARK: - Response
struct CheckLibraryStatusResponse: Codable {
    let code: Int?
    let message, communityID, status: String?

    enum CodingKeys: String, CodingKey {
        case code, message
        case communityID = "community_id"
        case status
    }
}


// MARK: - CheckApartmentLibraryStatus
struct CheckApartmentLibraryStatusModel: Codable {
    let response: CheckApartmentLibraryStatusResponse?
}

// MARK: - Response
struct CheckApartmentLibraryStatusResponse: Codable {
    let code: Int?
    let message, libraryStatus: String?
    let myAcceptedCount: Int?
    let libraryType, isActive, apartmentID, apartmentName: String?
    let flatNo: String?
    
    enum CodingKeys: String, CodingKey {
        case code, message
        case libraryStatus = "library_status"
        case myAcceptedCount = "my_accepted_count"
        case libraryType = "library_type"
        case isActive = "is_active"
        case apartmentID = "apartment_id"
        case apartmentName = "apartment_name"
        case flatNo = "flat_no"
    }
}
