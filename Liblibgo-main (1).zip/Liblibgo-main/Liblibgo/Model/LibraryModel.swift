//
//  LibraryModel.swift
//  Liblibgo
//
//  Created by apple on 22/05/22.
//

// MARK: - Welcome
struct LibraryModel: Codable {
    let response: LibraryResponse?
}

// MARK: - Response
struct LibraryResponse: Codable {
    let code: Int?
    let message: String?
    let libraryList: [LibraryList]?

    enum CodingKeys: String, CodingKey {
        case code, message
        case libraryList = "library_list"
    }
}

// MARK: - LibraryList
struct LibraryList: Codable {
    let libraryID: String?
    let libraryImage: String?
    let libraryName, libraryType, selfStatusFor, userID: String?
    let libraryAddress, libraryOwnerName: String?
    let totalPendingRequests, totalAcceptedRequests: Int?
    var isOwnLibrary, communityStatus: String?
    let allowContact: Int?
    let contactNo: String?
    let ratings: Double?
    let totalRatingUsers: String?
    
    enum CodingKeys: String, CodingKey {
        case libraryID = "library_id"
        case libraryImage = "library_image"
        case libraryName = "library_name"
        case libraryType = "library_type"
        case selfStatusFor = "self_status_for"
        case userID = "user_id"
        case libraryAddress = "library_address"
        case libraryOwnerName = "library_owner_name"
        case totalPendingRequests = "total_pending_requests"
        case totalAcceptedRequests = "total_accepted_requests"
        case isOwnLibrary = "is_own_library"
        case communityStatus = "community_status"
        case allowContact = "allow_contact"
        case contactNo = "contact_no"
        case ratings
        case totalRatingUsers = "total_rating_users"
    }
}

// MARK: - My Library Model
struct MyLibraryModel: Codable {
    let response: MyLibraryResponse?
}

// MARK: - Response
struct MyLibraryResponse: Codable {
    let code, message, userID, name: String?
    let username, email, mobile, apartmentID: String?
    let apartmentName, flatID, flatNo, libraryID: String?
    let libraryName, libraryAddress: String?
    let myAcceptedCount, myAcceptedUser, myPendingUser: Int?
    let libcoins: String?
    let libraryImage: String?

    enum CodingKeys: String, CodingKey {
        case code, message
        case userID = "user_id"
        case name, username, email, mobile
        case apartmentID = "apartment_id"
        case apartmentName = "apartment_name"
        case flatID = "flat_id"
        case flatNo = "flat_no"
        case libraryID = "library_id"
        case libraryName = "library_name"
        case libraryAddress = "library_address"
        case myAcceptedCount = "my_accepted_count"
        case myAcceptedUser = "my_accepted_user"
        case myPendingUser = "my_pending_user"
        case libcoins
        case libraryImage = "library_image"
    }
}
