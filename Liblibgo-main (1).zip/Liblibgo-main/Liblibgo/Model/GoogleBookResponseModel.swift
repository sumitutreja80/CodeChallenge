//
//  GoogleBookResponseModel.swift
//  Liblibgo
//
//  Created by apple on 25/06/22.
//

import Foundation

// MARK: - Welcome
struct GoogleBookResponseModel: Codable {
    let kind: String?
    let totalItems: Int?
    let items: [Item]?
}

// MARK: - Item
struct Item: Codable {
    let volumeInfo: VolumeInfo?
}

// MARK: - VolumeInfo
struct VolumeInfo: Codable {
    let title: String?
    let authors: [String]?
    let imageLinks: ImageLinks?
    let volumeInfoDescription: String?
    
    enum CodingKeys: String, CodingKey {
        case title, authors
        case imageLinks
        case volumeInfoDescription = "description"
    }
}

// MARK: - ImageLinks
struct ImageLinks: Codable {
    let smallThumbnail, thumbnail: String?
}

// MARK: - Welcome
struct BookMSRPModel: Codable {
    let book: BookMSRP?
}

// MARK: - Book
struct BookMSRP: Codable {
    let msrp: String?
}
