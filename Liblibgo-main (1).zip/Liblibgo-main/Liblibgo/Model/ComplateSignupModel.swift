//
//  ComplateSignupModel.swift
//  Liblibgo
//
//  Created by apple on 04/07/22.
//

import Foundation

// MARK: - ComplateSignupModel
struct ComplateSignupModel: Codable {
    let message, status: String?
    let postOffice: [PostOffice]?

    enum CodingKeys: String, CodingKey {
        case message = "Message"
        case status = "Status"
        case postOffice = "PostOffice"
    }
}

// MARK: - PostOffice
struct PostOffice: Codable {
    let name, postOfficeDescription, branchType, deliveryStatus: String?
    let taluk, circle, district, division: String?
    let region, state, country: String?

    enum CodingKeys: String, CodingKey {
        case name = "Name"
        case postOfficeDescription = "Description"
        case branchType = "BranchType"
        case deliveryStatus = "DeliveryStatus"
        case taluk = "Taluk"
        case circle = "Circle"
        case district = "District"
        case division = "Division"
        case region = "Region"
        case state = "State"
        case country = "Country"
    }
}
