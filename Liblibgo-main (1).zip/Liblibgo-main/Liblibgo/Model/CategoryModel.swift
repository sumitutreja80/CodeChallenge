//
//  CategoryModel.swift
//  Liblibgo
//
//  Created by apple on 19/06/22.
//

import Foundation

// MARK: - Category Model
struct CategoryModel: Codable {
    let response: CategoryResponse?
}

// MARK: - Category Response
struct CategoryResponse: Codable {
    let code: Int?
    let message: String?
    let categoryList: [CategoryList]?

    enum CodingKeys: String, CodingKey {
        case code, message
        case categoryList = "category_list"
    }
}

// MARK: - Category List
struct CategoryList: Codable {
    let categoryID, categoryName: String?
    var isSelected: Bool = false

    enum CodingKeys: String, CodingKey {
        case categoryID = "category_id"
        case categoryName = "category_name"
    }
}
