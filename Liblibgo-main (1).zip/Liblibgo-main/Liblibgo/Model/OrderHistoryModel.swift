//
//  OrderHistoryModel.swift
//  Liblibgo
//
//  Created by apple on 12/06/22.
//

import Foundation

// MARK: - Order History Model
struct OrderHistoryModel: Codable {
    let response: OrderHistoryResponse?
}

// MARK: - Order History Response
struct OrderHistoryResponse: Codable {
    let code: Int?
    let message: String?
    let orderList: [OrderList]?

    enum CodingKeys: String, CodingKey {
        case code, message
        case orderList = "order_list"
    }
}

// MARK: - OrderList
struct OrderList: Codable {
    let orderID, orderNo, orderNumber, orderDetailsID, bookID: String?
    let bookName, authorName: String?
    let imageURL: String?
    let orderAmout, libcoins, securityMoney, userName: String?
    let userType, mobile, address, bookPrice: String?
    let rentDuration, orderStatus, orderFor, paymentStatus: String?
    let orderDate: String?
    
    enum CodingKeys: String, CodingKey {
        case orderID = "order_id"
        case orderNo = "order_no"
        case orderNumber = "order_number"
        case orderDetailsID = "order_details_id"
        case bookID = "book_id"
        case bookName = "book_name"
        case authorName = "author_name"
        case imageURL = "image_url"
        case orderAmout = "order_amout"
        case libcoins
        case securityMoney = "security_money"
        case userName = "user_name"
        case userType = "user_type"
        case mobile, address
        case bookPrice = "book_price"
        case rentDuration = "rent_duration"
        case orderStatus = "order_status"
        case orderFor = "order_for"
        case paymentStatus = "payment_status"
        case orderDate = "order_date"
    }
}

// MARK: - Order Detail Model
struct OrderDetailModel: Codable {
    let response: OrderDetailResponse?
}

// MARK: - Order History Response
struct OrderDetailResponse: Codable {
    let code: Int?
    let message: String?
    let data: OrderList?

    enum CodingKeys: String, CodingKey {
        case code, message
        case data = "data"
    }
}
