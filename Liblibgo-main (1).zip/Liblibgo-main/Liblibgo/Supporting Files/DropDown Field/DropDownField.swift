//
//  DropDownField.swift
//  Liblibgo
//
//  Created by apple on 12/06/22.
//

import UIKit
import DropDown

class DropDownField: ViewFromXIB {

    @IBOutlet weak var lblText: UILabel!
    @IBOutlet weak var btnClick: UIButton!
    
    let dropDown = DropDown()
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.dropDown.anchorView = self
        self.dropDown.direction = .bottom
    }
    
    @IBAction func btnClickTap(_ sender: UIButton){
        if let vc = UIApplication.getTopViewController(){
            vc.view.endEditing(true)
        }
        self.layer.borderColor = UIColor.AppThemColor.cgColor
        self.dropDown.show()
    }

}
