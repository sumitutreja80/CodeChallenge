//
//  FPhoneTextField.swift
//  Medstar-Doctor
//
//  Created by admin on 12/04/20.
//  Copyright © 2020 anshul shah. All rights reserved.
//
import UIKit
import PhoneNumberKit

class FPhoneTextField: ViewFromXIB {
    
    @IBOutlet weak var tf: PhoneNumberTextField!
    @IBOutlet weak var lblError: UILabel!
    @IBOutlet weak var vw: UIView!
    @IBOutlet weak var bottomLine: UILabel!
    
    var text: String{
        set{
            tf.text = newValue
            self.tf.updateFlag()
        }get{
            return tf.text ?? ""
        }
    }
    
    var phoneNumber: String?{
        if !self.tf.isValidNumber{
            return nil
        }
        let nationalNumber = self.tf.nationalNumber
        if let isdCode = self.tf.text?.components(separatedBy: " ").first{
            return "\(isdCode) \(nationalNumber)"
        }
        return nil
    }
    
    var phoneNumberWithoutCode: String?{
        if !self.tf.isValidNumber{
            return nil
        }
        let nationalNumber = self.tf.nationalNumber
        if let isdCode = self.tf.text?.components(separatedBy: " ").first{
            return "\(nationalNumber)"
        }
        return nil
    }
    
    override func resignFirstResponder() -> Bool {
        return tf.resignFirstResponder()
    }
    
    var errorMessage: String?{
        didSet{
            self.lblError.text = self.errorMessage ?? ""
            self.lblError.numberOfLines = 0
            self.vw.borderColor = self.errorMessage ?? "" == "" ? UIColor.AppThemColor : .red
            self.bottomLine.backgroundColor = errorMessage == nil ? .gray : .red
            if self.errorMessage ?? "" != ""{
                let lblHeight = (lblError.countLabelLines()) * 10
                self.updateHeightConstrait(height: CGFloat(50 + lblHeight + 3))
            }else{
                self.updateHeightConstrait(height: 50)
            }
        }
    }
    
    
    func setup() {
        self.tf.placeholder = "Phone number"
        self.tf.attributedPlaceholder = NSAttributedString(string: "Phone number", attributes:[NSAttributedString.Key.foregroundColor: UIColor.gray])
        self.tf.fixRadius = 24
        self.tf.font = UIFont.init(name: "Lato-Bold", size: fontSize)
        self.tf.minimumFontSize = 12
        self.tf.withDefaultPickerUI = true
        self.tf.withFlag = true
        self.tf.withPrefix = true
        self.tf.withExamplePlaceholder = true
        if #available(iOS 11.0, *) {
            PhoneNumberKit.CountryCodePicker.commonCountryCodes = ["US", "CA", "MX", "AU", "GB", "DE"]
        }
        self.tf.returnKeyType = .next
        self.errorMessage = nil
        self.vw.borderWidth = 0
        self.lblError.textColor = .red
        self.bottomLine.backgroundColor = .gray
        tf.placeHolderColor = .lightGray
        tf.backgroundColor = .clear
        self.backgroundColor = .clear
        self.vw.borderColor = .clear
        self.vw.layer.cornerRadius = 24
        self.tf.leftView?.frame = CGRect.init(x: 0, y: 0, width: 50, height: 50)
        self.tf.leftView?.layoutIfNeeded()
        self.tf.delegate = self
        self.tf.flagButton.translatesAutoresizingMaskIntoConstraints = false
        self.tf.flagButton.addConstraint(NSLayoutConstraint(item: self.tf.flagButton, attribute: .height, relatedBy: .equal, toItem: nil, attribute: .notAnAttribute, multiplier: 1, constant: 50))
        self.tf.flagButton.addConstraint(NSLayoutConstraint(item: self.tf.flagButton, attribute: .width, relatedBy: .equal, toItem: nil, attribute: .notAnAttribute, multiplier: 1, constant: 50))
    }
    
    func updateHeightConstrait(height: CGFloat){
        
        if let constraint = (self.constraints.filter{$0.firstAttribute == .height}.first) {
            if constraint.constant == height{
            }else{
                constraint.constant = height
                self.layoutIfNeeded()
            }
        }
    }
    
    @IBInspectable var fontSize : CGFloat = 0.0 {
        didSet {
            self.tf.font = UIFont.init(name: "Lato-Bold", size: fontSize)
        }
    }
    
    override func becomeFirstResponder() -> Bool {
        tf.becomeFirstResponder()
    }
    
    func validateWhitelistCharactor() -> Bool{
        return true
    }
    
    var isEmpty: Bool{
        let string = (self.tf.text ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        return string == ""
    }
    
}

extension FPhoneTextField: UITextFieldDelegate{
    func textFieldDidEndEditing(_ textField: UITextField) {
        print(self.text)
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if let view = self.superview?.viewWithTag(self.tag + 1) as? UITextField{
            _ = view.becomeFirstResponder()
        }else if let view = self.superview?.viewWithTag(self.tag + 1) as? FPhoneTextField{
            _ = view.becomeFirstResponder()
        }
        if textField.returnKeyType == .done {
            textField.resignFirstResponder()
        }
        return true
    }
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        self.errorMessage = nil
        return true
    }
}
