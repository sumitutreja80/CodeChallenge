//
//  Constant.swift
//  Liblibgo
//
//  Created by apple on 21/05/22.
//

import UIKit

let MAIN_SCREEN = UIScreen.main
let MainScreenBounds:CGRect = MAIN_SCREEN.bounds
let SCREEN_WIDTH:CGFloat = MAIN_SCREEN.bounds.width
let SCREEN_HEIGHT = MAIN_SCREEN.bounds.height
let SCREEN_SCALE:CGFloat = MAIN_SCREEN.bounds.width/320
let USERDEFAULTS = UserDefaults.standard

let AppName = "Liblibgo"

struct StoryBoards {
    static let Splace = UIStoryboard.init(name: "Splash", bundle: nil)
    static let Main = UIStoryboard.init(name: "Main", bundle: nil)
    static let Authentication = UIStoryboard.init(name: "Authentication", bundle: nil)
    static let MyAccount = UIStoryboard.init(name: "MyAccount", bundle: nil)
    static let Books = UIStoryboard.init(name: "Books", bundle: nil)
    static let MyLibrary = UIStoryboard.init(name: "MyLibrary", bundle: nil)
    static let TrackMyBooks = UIStoryboard.init(name: "TrackMyBooks", bundle: nil)
}

enum APIState {
    case initial
    case loading
    case error
    case data
}

extension Notification.Name {
    static let NewArrivedNotification = Notification.Name("RemoteNotificationObserver")
    static let DeleteAccount = Notification.Name("DeleteAccount")
    static let BlockUser = Notification.Name("BlockUser")
}

struct Messages {
    
    static let SOMETHING_WRONG = "Oops! Something went wrong.\nPlease try again."
    static let NO_DATA = "No Data Available!"
    static let NO_POSTS = "No Posts Available!"
    static let NO_GALLERY = "No Galleries Available!"
    static let NO_NOTIFICATIONS = "No Notifications Available!"
    static let NO_COMMENTS = "No Comments Available!"
    static let NO_USERS = "No Users Available!"
    static let NO_MESSAGES = "No Messages Available!"
    static let NO_INTERNET = "Please check your internet connectivity."
    static let OPTION = "Please select option."
    static let REPORTED = "You have successfully reported."
    static let BOOK_UPLOAD = "Book successfully uploaded."

    //MARK: Button Titles
    static let BTN_OK = "OK"
    static let BTN_DONE = "Done"
    static let BTN_RESEND = "RESEND"
    static let BTN_YES = "YES"
    static let BTN_NO = "NO"
    static let BTN_CANCEL = "Cancel"
    static let BTN_DISMISS = "Dismiss"
    static let BTN_DELETE = "Delete"
    static let BTN_REMOVE = "Remove"
    static let BTN_EDIT = "Edit"
    static let BTN_SETTINGS = "Settings"
    static let BTN_SELECT = "Select"
    static let BTN_CAMERA = "Camera"
    static let BTN_GALLERY = "Gallery"
    static let BTN_ADD = "Add"
    static let BTN_UPDATE = "Update"
    static let BTN_CART = "Go to cart"
    static let BTN_REPORT = "Report"
    static let BTN_COPY_LINK = "Copy Link"
    static let BTN_SHARE = "Share"
    static let BTN_SHARE_PROFILE = "Share this profile"
    static let BTN_FOLLOW = "Follow"
    static let BTN_UNFOLLOW = "Unfollow"
    static let BTN_BLOCK = "Block"
    static let BTN_SAVE = "Save"
    static let BTN_FIND_BRANCH = "Find Branch"
    static let BTN_VIEWS = "Views"
    
    //MARK: Phone
    static let PHONE_INVALID = "Please Enter Valid Phone Number."
    static let Validation_no_OTP = "Please enter a 4 digit verification code."
    static let Validation_invalid_OTP = "Please enter a valid verification code."
    
    // MARK: Settings
    static let LOGOUT = "Are you sure you want to logout?"
    static let DELETE_ACCOUNT = "Are you sure you want to delete account?"
}
