//
//  UploadBookVM.swift
//  Liblibgo
//
//  Created by apple on 24/06/22.
//

import Foundation
import UIKit

class UploadBookVM: NSObject {

    var onErrorHandling : ((ErrorType?) -> Void)?
    var state: APIState = .initial
    
    func addNewBook(param: [String:String], image: UIImage? = nil, completionHandler: @escaping ((GeneralResponse?) -> Void)) {
        self.state = .loading
        Utill.showActivityIndicator()
        ApiManager.sharedInstance.request(url: Endpoints.bookEntry, parameter: param) { (result: Result<GeneralResponceModel, ErrorType>) in
            switch result{
            case .success(let bookDetail):
                self.state = .data
                if image != nil && bookDetail.response?.book_id ?? 0 != 0{
                    self.uploadBookImage(bookId: bookDetail.response?.book_id ?? 0, image: image!, completionHandler: completionHandler)
                }else{
                    Utill.removeActivityIndicator()
                    completionHandler(bookDetail.response)
                }
            case .failure(let error):
                Utill.removeActivityIndicator()
                self.state = .error
                self.onErrorHandling?(error)
            }
        }
    }
    
    func uploadBookImage(bookId: Int, image: UIImage, completionHandler: @escaping ((GeneralResponse?) -> Void)){
        ApiManager.sharedInstance.uploadRequest(url: Endpoints.UploadBookImage, method: .post, parameter: ["book_id": bookId], arrImage: [("image",image)], arrVideo: nil, arrAudio: nil) { (result: Result<GeneralResponceModel, Error>) in
            Utill.removeActivityIndicator()
            switch result{
            case .success(let bookDetail):
                self.state = .data
                completionHandler(bookDetail.response)
            case .failure(_):
                self.state = .error
                self.onErrorHandling?(.defaultError)
            }
        }
    }
    
    func fetchBookInfo(isbn: String, completionHandler: @escaping ((VolumeInfo?) -> Void)){
        
        let bookRequest = "https://www.googleapis.com/books/v1/volumes?q=isbn:" + isbn
        
        if let url = URL(string: bookRequest) {
            let session = URLSession.shared.dataTask(with: url) { (data, response, error) in
                if let data = data {
                    let decoder = JSONDecoder()
                    if let responseData = try? decoder.decode(GoogleBookResponseModel.self, from: data){
                        completionHandler(responseData.items?.last?.volumeInfo)
                    }else{
                        completionHandler(nil)
                    }
                }else{
                    completionHandler(nil)
                }
            }
            session.resume()
        }
    }
    
    func fetchBookMSRP(isbn: String, completionHandler: @escaping ((BookMSRP?) -> Void)){
        
        var request = URLRequest(url: URL(string: "https://api2.isbndb.com/book/1612680011")!,timeoutInterval: Double.infinity)
        request.addValue(Endpoints.AuthAPIKey, forHTTPHeaderField: "Authorization")
        
        request.httpMethod = "GET"
        
        let session = URLSession.shared.dataTask(with: request) { (data, response, error) in
            if let data = data {
                let decoder = JSONDecoder()
                if let responseData = try? decoder.decode(BookMSRPModel.self, from: data){
                    completionHandler(responseData.book)
                }else{
                    completionHandler(nil)
                }
            }else{
                completionHandler(nil)
            }
        }
        session.resume()
    }
    
    func stackBookUpload(param: [String : Any], image: UIImage, completionHandler: @escaping ((GeneralResponse?) -> Void)){
        Utill.showActivityIndicator()
        ApiManager.sharedInstance.uploadRequest(url: Endpoints.BookStackUpload, method: .post, parameter: param, arrImage: [("book_image",image)], arrVideo: nil, arrAudio: nil) { (result: Result<GeneralResponceModel, Error>) in
            Utill.removeActivityIndicator()
            switch result{
            case .success(let bookDetail):
                self.state = .data
                completionHandler(bookDetail.response)
            case .failure(_):
                self.state = .error
                self.onErrorHandling?(.defaultError)
            }
        }
    }
}
