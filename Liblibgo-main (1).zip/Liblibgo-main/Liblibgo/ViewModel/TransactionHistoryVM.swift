//
//  TransactionHistoryVM.swift
//  Liblibgo
//
//  Created by apple on 19/06/22.
//

import Foundation

class TransactionHistoryVM: GenericDataSource<TransactionHistoryList> {
    
    var onErrorHandling : ((ErrorType?) -> Void)?
    var state: APIState = .initial
    
    func fetchTransactionHistory(userId: String) {
        self.state = .loading
        ApiManager.sharedInstance.request(url: Endpoints.TransactionHistory, parameter: ["user_id": userId]) { (result: Result<TransactionHistoryModel, ErrorType>) in
            switch result{
            case .success(let transactionHistory):
                self.state = .data
                self.data.value = transactionHistory.response?.historyList ?? []
            case .failure(let error):
                self.state = .error
                self.onErrorHandling?(error)
            }
        }
    }
}
