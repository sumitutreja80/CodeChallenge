//
//  SearchBooksListVM.swift
//  Liblibgo
//
//  Created by apple on 15/06/22.
//

import Foundation

class SearchBooksListVM: GenericDataSource<BookList> {
    
    var onErrorHandling : ((ErrorType?) -> Void)?
    var state: APIState = .initial
    
    func fetchBooksList(bookName: String = "") {
        self.state = .loading
        ApiManager.sharedInstance.request(url: Endpoints.SearchByBookNameFilter, parameter: ["book_name": bookName, "user_id": AppSettings.currentUser?.userID ?? "", "is_own_library": 0]) { (result: Result<BookListModel, ErrorType>) in
            switch result{
            case .success(let booksList):
                self.state = .data
                self.data.value = booksList.response?.bookList ?? []
            case .failure(let error):
                self.state = .error
                self.onErrorHandling?(error)
            }
        }
    }
}
