//
//  TrackMyBookVM.swift
//  Liblibgo
//
//  Created by apple on 25/06/22.
//

import Foundation

class TrackMyBookVM: GenericDataSource<BookList> {
    
    var onErrorHandling : ((ErrorType?) -> Void)?
    var state: APIState = .initial
    
    func fetchBooksList(userId: String = AppSettings.currentUser?.userID ?? "") {
        self.state = .loading
        ApiManager.sharedInstance.request(url: Endpoints.OwnLibraryBooks, parameter: ["user_id": userId, "is_own_library": 0]) { (result: Result<BookListModel, ErrorType>) in
            switch result{
            case .success(let booksList):
                self.state = .data
                self.data.value = booksList.response?.bookList ?? []
            case .failure(let error):
                self.state = .error
                self.onErrorHandling?(error)
            }
        }
    }
    
    func changeBookStatus(bookId: String, status: String, completionHandler: @escaping ((GeneralResponse?) -> Void)) {
        self.state = .loading
        ApiManager.sharedInstance.request(url: Endpoints.BookActiveInactive, parameter: ["book_id": bookId, "status": status]) { (result: Result<GeneralResponceModel, ErrorType>) in
            switch result{
            case .success(let booksList):
                self.state = .data
                completionHandler(booksList.response)
            case .failure(let error):
                self.state = .error
                self.onErrorHandling?(error)
            }
        }
    }
}
