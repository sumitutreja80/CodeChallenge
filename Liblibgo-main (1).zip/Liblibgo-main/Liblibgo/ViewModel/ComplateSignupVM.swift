//
//  ComplateSignupVM.swift
//  Liblibgo
//
//  Created by apple on 04/07/22.
//

import UIKit

class ComplateSignupVM: NSObject {

    var onErrorHandling : ((ErrorType?) -> Void)?
    var state: APIState = .initial
    
    func getLocation(pincode: String, completionHandler: @escaping ((ComplateSignupModel?) -> Void)) {
        self.state = .loading
        guard let url = URL.init(string: "http://www.postalpincode.in/api/pincode/\(pincode)") else { return  }
        let request = URLRequest(url: url, cachePolicy: .reloadIgnoringLocalAndRemoteCacheData, timeoutInterval: 30)
        URLSession.shared.dataTask(with: request) { (data, response, error) in
            URLCache.shared.removeCachedResponse(for: request)
            guard let data = data else{
                completionHandler(nil)
                return
            }
            let decoder = JSONDecoder()
            do{
                let responseData = try decoder.decode(ComplateSignupModel.self, from: data)
                completionHandler(responseData)
            }catch let DecodingError.dataCorrupted(context) {
                print(context)
                completionHandler(nil)
            } catch let DecodingError.keyNotFound(key, context) {
                print("Key '\(key)' not found:", context.debugDescription)
                print("codingPath:", context.codingPath)
                completionHandler(nil)
            } catch let DecodingError.valueNotFound(value, context) {
                print("Value '\(value)' not found:", context.debugDescription)
                print("codingPath:", context.codingPath)
                completionHandler(nil)
            } catch let DecodingError.typeMismatch(type, context)  {
                print("Type '\(type)' mismatch:", context.debugDescription)
                print("codingPath:", context.codingPath)
                completionHandler(nil)
            }catch _{
                completionHandler(nil)
            }
        }.resume()
    }
}
