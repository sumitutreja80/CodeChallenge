//
//  RedeemLibCoinVM.swift
//  Liblibgo
//
//  Created by apple on 02/07/22.
//

import UIKit

class RedeemLibCoinVM: NSObject {

    var onErrorHandling : ((ErrorType?) -> Void)?
    var state: APIState = .initial
    
    func postRedeemLibcoinsRequest(userId: String, redeemLibcoins: String, transactionId: String, completionHandler: @escaping ((GeneralResponse?) -> Void)) {
        self.state = .loading
        ApiManager.sharedInstance.request(url: Endpoints.PostRedeemLibcoinsRequest, parameter: ["user_id":  userId, "redeem_libcoins": redeemLibcoins, "transaction_id": transactionId]) { (result: Result<GeneralResponceModel, ErrorType>) in
            switch result{
            case .success(let settingList):
                self.state = .data
                completionHandler(settingList.response)
            case .failure(let error):
                self.state = .error
                self.onErrorHandling?(error)
            }
        }
    }
}
