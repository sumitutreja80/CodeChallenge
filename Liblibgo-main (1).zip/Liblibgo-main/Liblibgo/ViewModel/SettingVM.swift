//
//  SettingVM.swift
//  Liblibgo
//
//  Created by apple on 21/06/22.
//

import UIKit

class SettingVM: NSObject {

    var onErrorHandling : ((ErrorType?) -> Void)?
    var state: APIState = .initial
    
    func fetchSetting(userId: String, completionHandler: @escaping ((SettingResponse?) -> Void)) {
        self.state = .loading
        ApiManager.sharedInstance.request(url: Endpoints.NotificationSettingList, parameter: ["user_id": userId]) { (result: Result<SettingModel, ErrorType>) in
            switch result{
            case .success(let settingList):
                self.state = .data
                completionHandler(settingList.response)
            case .failure(let error):
                self.state = .error
                self.onErrorHandling?(error)
            }
        }
    }
    
    func updateSetting(userId: String, notificationType: String, completionHandler: @escaping ((GeneralResponse?) -> Void)) {
        self.state = .loading
        ApiManager.sharedInstance.request(url: Endpoints.ChangeNotificationSettings, parameter: ["user_id": userId, "notification_type":notificationType]) { (result: Result<GeneralResponceModel, ErrorType>) in
            switch result{
            case .success(let settingList):
                self.state = .data
                completionHandler(settingList.response)
            case .failure(let error):
                self.state = .error
                self.onErrorHandling?(error)
            }
        }
    }
}
