//
//  HomeViewModel.swift
//  Liblibgo
//
//  Created by apple on 05/06/22.
//

import Foundation

class HomeBannerListViewModel: GenericDataSource<BannerList> {
    
    var onErrorHandling : ((ErrorType?) -> Void)?
    var state: APIState = .initial
    
    func fetchBannerList() {
        self.state = .loading
        ApiManager.sharedInstance.request(url: Endpoints.BannerList, parameter: [:]) { (result: Result<BannerModel, ErrorType>) in
            switch result{
            case .success(let bannerData):
                self.state = .data
                self.data.value = bannerData.response?.bannerList ?? []
            case .failure(let error):
                self.state = .error
                self.onErrorHandling?(error)
            }
        }
    }
}
