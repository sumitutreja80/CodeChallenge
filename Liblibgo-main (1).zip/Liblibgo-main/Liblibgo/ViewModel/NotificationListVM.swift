//
//  NotificationListVM.swift
//  Liblibgo
//
//  Created by apple on 12/06/22.
//

import Foundation

class NotificationListVM: GenericDataSource<NotificationList> {
    
    var onErrorHandling : ((ErrorType?) -> Void)?
    var state: APIState = .initial
    
    func fetchNotificationList(userId: String) {
        self.state = .loading
        ApiManager.sharedInstance.request(url: Endpoints.GetNotificationList, parameter: ["user_id": userId]) { (result: Result<NotificationModel, ErrorType>) in
            switch result{
            case .success(let notificationData):
                self.state = .data
                self.data.value = notificationData.response?.notifications ?? []
            case .failure(let error):
                self.state = .error
                self.onErrorHandling?(error)
            }
        }
    }
}
