//
//  CartVM.swift
//  Liblibgo
//
//  Created by apple on 06/07/22.
//

import UIKit

class CartVM: NSObject {

    var onErrorHandling : ((ErrorType?) -> Void)?
    var state: APIState = .initial
    
    func updateCartRentDuration(cartId: String, rentDuration: String, completionHandler: @escaping ((GeneralResponse?) -> Void)) {
        self.state = .loading
        Utill.showActivityIndicator()
        ApiManager.sharedInstance.request(url: Endpoints.UpdateCartRentDuration, parameter: ["cart_id": cartId, "rent_duration": rentDuration]) { (result: Result<GeneralResponceModel, ErrorType>) in
            Utill.removeActivityIndicator()
            switch result{
            case .success(let updateCartRent):
                self.state = .data
                completionHandler(updateCartRent.response)
            case .failure(let error):
                self.state = .error
                self.onErrorHandling?(error)
            }
        }
    }
}
