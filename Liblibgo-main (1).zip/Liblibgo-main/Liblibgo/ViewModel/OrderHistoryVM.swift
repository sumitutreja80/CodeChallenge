//
//  OrderHistoryVM.swift
//  Liblibgo
//
//  Created by apple on 12/06/22.
//

import Foundation

class OrderHistoryVM: GenericDataSource<OrderList> {
    
    var onErrorHandling : ((ErrorType?) -> Void)?
    var state: APIState = .initial
    
    func fetchOrderHistory(userId: String, filter: String = "") {
        self.state = .loading
        ApiManager.sharedInstance.request(url: Endpoints.MyOrders, parameter: ["user_id": userId, "filter": filter]) { (result: Result<OrderHistoryModel, ErrorType>) in
            switch result{
            case .success(let orderHistory):
                self.state = .data
                self.data.value = orderHistory.response?.orderList ?? []
            case .failure(let error):
                self.state = .error
                self.onErrorHandling?(error)
            }
        }
    }
    
    func fetchOrderDetail(userId: String, orderId: String) {
        self.state = .loading
        ApiManager.sharedInstance.request(url: Endpoints.OrderDetails, parameter: ["user_id": userId, "order_id": orderId]) { (result: Result<OrderDetailModel, ErrorType>) in
            switch result{
            case .success(let orderHistory):
                self.state = .data
                if let data = orderHistory.response?.data{
                    self.data.value = [data]
                }else{
                    self.data.value = []
                }
            case .failure(let error):
                self.state = .error
                self.onErrorHandling?(error)
            }
        }
    }
}
