//
//  CategoryVM.swift
//  Liblibgo
//
//  Created by apple on 19/06/22.
//

import Foundation

class CategoryVM: GenericDataSource<CategoryList> {
    
    var onErrorHandling : ((ErrorType?) -> Void)?
    var state: APIState = .initial
    
    override init() {
        super.init()
        self.fetchCategory()
    }
    
    func fetchCategory() {
        self.state = .loading
        ApiManager.sharedInstance.request(url: Endpoints.CategoryList, parameter: [:]) { (result: Result<CategoryModel, ErrorType>) in
            switch result{
            case .success(let categoryList):
                self.state = .data
                self.data.value = categoryList.response?.categoryList ?? []
            case .failure(let error):
                self.state = .error
                self.onErrorHandling?(error)
            }
        }
    }
}
