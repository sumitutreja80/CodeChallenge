//
//  LibraryListVM.swift
//  Liblibgo
//
//  Created by apple on 23/06/22.
//

import Foundation

class LibraryListVM: GenericDataSource<LibraryList> {
    
    var onErrorHandling : ((ErrorType?) -> Void)?
    var state: APIState = .initial
    
    func checkApartmentLibraryStatus(userId: String, completionHandler: @escaping ((MyLibraryResponse?) -> Void)){
        Utill.showActivityIndicator()
        ApiManager.sharedInstance.request(url: Endpoints.CheckApartmentLibraryStatus, parameter: ["user_id": userId]) { (result: Result<CheckApartmentLibraryStatusModel, ErrorType>) in
            Utill.removeActivityIndicator()
            guard let res = try? result.get() else { return }
            if res.response?.libraryStatus == "no" && res.response?.myAcceptedCount ?? 0 == 0{
                completionHandler(nil)
            }else if res.response?.libraryStatus == "no" && res.response?.myAcceptedCount ?? 0 >= 1{
                self.fetchMyCommunityJoinedLibraryList()
            }else if res.response?.libraryStatus == "yes" && res.response?.myAcceptedCount ?? 0 >= 1{
                self.fetchMyLibrary(userId: userId, isOwnLibrary: "0", completionHandler: completionHandler)
                self.fetchMyCommunityJoinedLibraryList()
            }else{
                completionHandler(nil)
            }
        }
    }
    
    func fetchMyCommunityJoinedLibraryList() {
        self.state = .loading
        ApiManager.sharedInstance.request(url: Endpoints.MyCommunityJoinedList, parameter: ["user_id": AppSettings.currentUser?.userID ?? ""]) { (result: Result<LibraryModel, ErrorType>) in
            switch result{
            case .success(let libraryList):
                self.state = .data
                self.data.value = libraryList.response?.libraryList ?? []
            case .failure(let error):
                self.state = .error
                self.onErrorHandling?(error)
            }
        }
    }
    
    func fetchMyLibrary(userId: String, isOwnLibrary: String, completionHandler: @escaping ((MyLibraryResponse?) -> Void)) {
        ApiManager.sharedInstance.request(url: Endpoints.GetOwnLibraryProfile, parameter: ["user_id": userId, "is_own_library": isOwnLibrary]) { (result: Result<MyLibraryModel, ErrorType>) in
            switch result{
            case .success(let myLibrary):
                completionHandler(myLibrary.response)
            case .failure(let error):
                self.onErrorHandling?(error)
            }
        }
    }
}
